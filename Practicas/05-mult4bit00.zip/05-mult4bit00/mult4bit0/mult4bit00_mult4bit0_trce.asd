[ActiveSupport TRCE]
; Setup Analysis
Other_0 = 19.870 ns (0.000 ns);
Other_1 = 4.022 ns (0.000 ns);
Failed = 0 (Total 2);
Clock_ports = 0;
Clock_nets = 0;
