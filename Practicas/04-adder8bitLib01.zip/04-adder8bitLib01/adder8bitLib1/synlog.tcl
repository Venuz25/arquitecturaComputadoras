run_tcl -fg adder8bitLib01_adder8bitLib1_synplify.tcl
