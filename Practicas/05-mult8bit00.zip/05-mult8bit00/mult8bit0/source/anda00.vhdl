library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity anda00 is
	port(Aa: in std_logic;
		 Ba: in std_logic;
		 Ya: out std_logic);
end anda00;

architecture anda0 of anda00 is
begin
	Ya <= Aa and Ba;
end anda0;