library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;
library lattice;
use lattice.all;

entity muxram00 is 
	port(
		remu, rwmu: in std_logic;
		inwordWmu: in std_logic_vector(6 downto 0);
		inwordRmu: in std_logic_vector(6 downto 0);
		outwordmu: out std_logic_vector(6 downto 0)
		);
end muxram00;

architecture muxram0 of muxram00 is
signal scontrolmu: std_logic_vector(1 downto 0);
begin
scontrolmu <= (remu)&(rwmu);
	with scontrolmu select
		outwordmu <= inwordWmu when "10",
					 inwordRmu when "11",
					 "1111111" when others;
end muxram0;