library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;
use packageram00.all;
library lattice;
use lattice.all;

entity ram00 is 
	port(
		clk0: inout std_logic;
		cdiv0: in std_logic_vector(5 downto 0);
		re0, rw0: in std_logic;
		inkey0: in std_logic_vector(3 downto 0);
		outcontW0: inout std_logic_vector(5 downto 0);
		outcontR0: inout std_logic_vector(5 downto 0);
		outr0: inout std_logic_vector(3 downto 0);
		outword0: out std_logic_vector(6 downto 0);
		outmux0: out std_logic_vector(6 downto 0);
		outtransist0: out std_logic_vector(3 downto 0);
		outFlag0: inout std_logic
		);
end ram00;

architecture ram0 of ram00 is
signal swordW: std_logic_vector(6 downto 0);
signal swordR: std_logic_vector(6 downto 0);
begin

outtransist0 <="0001";----111110

	RA00: osc00 port map(
						oscout0 => clk0,
						cdiv => cdiv0
						);
	
	RA01: contring00 port map(
								clkr => clk0,
								rer => re0,
								rwr => rw0,
								outr => outr0
								);
	
	RA02: coder00 port map(
							clkc => clk0,
							rec => re0,
							rwc => rw0,
							inkeyc => inkey0,
							incontc => outr0,
							outcontW => outcontW0,
							outcoderc => swordW,
							outFlagc => outFlag0
							);
	
	RA03: memram00 port map(
							clkm => clk0,
							re => re0,
							rwm => rw0,
							inFlagm => outFlag0,
							inwordWm => swordW,
							incontWm => outcontW0,
							incontRm => outcontR0,
							outwordm => swordR
							);
	
	RA04: contRead00 port map(
								clkrd => clk0,
								rerd => re0,
								rwrd => rw0,
								incontWrd => outcontW0,
								outcontRrd => outcontR0
								);
	
	RA05: muxram00 port map(
							remu => re0,
							rwmu => rw0,
							inwordWmu => swordW,
							inwordRmu => swordR,
							outwordmu => outword0
							);
	
end ram0;