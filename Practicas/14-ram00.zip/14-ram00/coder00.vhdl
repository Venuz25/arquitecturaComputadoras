library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
library lattice;
use lattice.all;

entity coder00 is 
	port(
		clkc: in std_logic;
		rwc, rec: in std_logic;
		incontc: in std_logic_vector(3 downto 0);
		inkeyc: in std_logic_vector(3 downto 0);
		outcontW: inout std_logic_vector(5 downto 0);
		outcoderc: out std_logic_vector(6 downto 0);
		outFlagc: out std_logic
		);
end coder00;

architecture coder0 of coder00 is
signal scontrol: std_logic_vector(1 downto 0);
begin
scontrol <= (rec)&(rwc);
	pcoder: process(clkc)
	variable aux0: bit:='0';
	begin
		if (clkc'event and clkc = '1') then
			case scontrol is
				when "00" => --incia W inicializacion
					aux0:='0';
					outcontW <= "000000";
					outcoderc <= "0000000";
					outFlagc <= '0';
				when "01" => --inicia R modo lectura
					outcontW <= "000000";
					outcoderc <= "0000000";
					outFlagc <= '0';
				when "10" => --Write
					case incontc is
						when "1000" =>
							case inkeyc is
-------------------------------------------------------------------------------
								when "0000" =>
									aux0:='0';
									outFlagc <= '0';
								
								when "1000" =>
									if (aux0 = '0') then
										aux0:='1';
										outcoderc <= "0110000";--1
										outcontW <= outcontW + '1';
										outFlagc <= '1';
									else
										outFlagc <= '0';
									end if;
								
								when "0100" =>
									if (aux0 = '0') then
										aux0:='1';
										outcoderc <= "1101101";--2
										outcontW <= outcontW + '1';
										outFlagc <= '1';
									else
										outFlagc <= '0';
									end if;
								
								when "0010" =>
									if (aux0 = '0') then
										aux0:='1';
										outcoderc <= "1111001";--3
										outcontW <= outcontW + '1';
										outFlagc <= '1';
									else
										outFlagc <= '0';
									end if;
									
								when "0001" =>
									if (aux0 = '0') then
										aux0:='1';
										outcoderc <= "1110111";--A
										outcontW <= outcontW + '1';
										outFlagc <= '1';
									else
										outFlagc <= '0';
									end if;
								when others => null;
							end case;
---------------------------------------------------------------------
						when "0100" =>
------------------------------------------------------------------
							case inkeyc is
								when "0000" =>
									aux0:='0';
									outFlagc <= '0';
								
								when "1000" =>
									if (aux0 = '0') then
										aux0:='1';
										outcoderc <= "0110011";--4
										outcontW <= outcontW + '1';
										outFlagc <= '1';
									else
										outFlagc <= '0';
									end if;
								
								when "0100" =>
									if (aux0 = '0') then
										aux0:='1';
										outcoderc <= "1011011";--5
										outcontW <= outcontW + '1';
										outFlagc <= '1';
									else
										outFlagc <= '0';
									end if;
								
								when "0010" =>
									if (aux0 = '0') then
										aux0:='1';
										outcoderc <= "1011111";--6
										outcontW <= outcontW + '1';
										outFlagc <= '1';
									else
										outFlagc <= '0';
									end if;
									
								when "0001" =>
									if (aux0 = '0') then
										aux0:='1';
										outcoderc <= "0011111";--b
										outcontW <= outcontW + '1';
										outFlagc <= '1';
									else
										outFlagc <= '0';
									end if;
								when others => null;
							end case;
-------------------------------------------------------------------------------------------
						when "0010" =>
------------------------------------------------------------------
							case inkeyc is
								when "0000" =>
									aux0:='0';
									outFlagc <= '0';
								
								when "1000" =>
									if (aux0 = '0') then
										aux0:='1';
										outcoderc <= "1110000";--7
										outcontW <= outcontW + '1';
										outFlagc <= '1';
									else
										outFlagc <= '0';
									end if;
								
								when "0100" =>
									if (aux0 = '0') then
										aux0:='1';
										outcoderc <= "1111111";--8
										outcontW <= outcontW + '1';
										outFlagc <= '1';
									else
										outFlagc <= '0';
									end if;
								
								when "0010" =>
									if (aux0 = '0') then
										aux0:='1';
										outcoderc <= "1110011";--9
										outcontW <= outcontW + '1';
										outFlagc <= '1';
									else
										outFlagc <= '0';
									end if;
									
								when "0001" =>
									if (aux0 = '0') then
										aux0:='1';
										outcoderc <= "1001110";--C
										outcontW <= outcontW + '1';
										outFlagc <= '1';
									else
										outFlagc <= '0';
									end if;
								when others => null;
							end case;
------------------------------------------------------------------------------------							
						when "0001" =>
------------------------------------------------------------------------------------
							case inkeyc is
								when "0000" =>
									aux0:='0';
									outFlagc <= '0';
								
								when "1000" =>
									if (aux0 = '0') then
										aux0:='1';
										outcoderc <= "1001111";--*
										outcontW <= outcontW + '1';
										outFlagc <= '1';
									else
										outFlagc <= '0';
									end if;
								
								when "0100" =>
									if (aux0 = '0') then
										aux0:='1';
										outcoderc <= "1111110";--0
										outcontW <= outcontW + '1';
										outFlagc <= '1';
									else
										outFlagc <= '0';
									end if;
								
								when "0010" =>
									if (aux0 = '0') then
										aux0:='1';
										outcoderc <= "1000111";--#
										outcontW <= outcontW + '1';
										outFlagc <= '1';
									else
										outFlagc <= '0';
									end if;
									
								when "0001" =>
									if (aux0 = '0') then
										aux0:='1';
										outcoderc <= "0111101";--d
										outcontW <= outcontW + '1';
										outFlagc <= '1';
									else
										outFlagc <= '0';
									end if;
								when others => null;
							end case;
---------------------------------------------------------------------------------------
						when others => null;
					end case;
				--when "10" => --R
				when others => null;
			end case;
		end if;
	end process pcoder;
end coder0;