library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;
library lattice;
use lattice.all;

package packageram00 is
	component osc00
		port(
		cdiv: in std_logic_vector(5 downto 0);
		oscout0: inout std_logic
		);
	end component;
	
	component contring00
		port(
		clkr: in std_logic;
		rwr, rer: in std_logic;
		outr: out std_logic_vector(3 downto 0)
		);
	end component;
	
	component coder00
		port(
		clkc: in std_logic;
		rwc, rec: in std_logic;
		incontc: in std_logic_vector(3 downto 0);
		inkeyc: in std_logic_vector(3 downto 0);
		outcontW: inout std_logic_vector(5 downto 0);
		outcoderc: out std_logic_vector(6 downto 0);
		outFlagc: out std_logic
		);
	end component;
	
	component memram00
		port(
		clkm: in std_logic;
		re,rwm: in std_logic;
		inFlagm: in std_logic;
		inwordWm: in std_logic_vector(6 downto 0);
		incontWm: in std_logic_vector(5 downto 0);
		incontRm: in std_logic_vector(5 downto 0);
		outwordm: out std_logic_vector(6 downto 0)
		);
	end component;
	
	component contRead00
		port(
		clkrd: in std_logic;
		rerd, rwrd: in std_logic;
		incontWrd: in std_logic_vector(5 downto 0);
		outcontRrd: inout std_logic_vector(5 downto 0)
		);
	end component;
	
	component muxram00
		port(
		remu, rwmu: in std_logic;
		inwordWmu: in std_logic_vector(6 downto 0);
		inwordRmu: in std_logic_vector(6 downto 0);
		outwordmu: out std_logic_vector(6 downto 0)
		);
	end component;
end packageram00;