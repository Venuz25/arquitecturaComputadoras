library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;
library lattice;
use lattice.all;

entity memram00 is 
	port(
		clkm: in std_logic;
		re,rwm: in std_logic;
		inFlagm: in std_logic;
		inwordWm: in std_logic_vector(6 downto 0);
		incontWm: in std_logic_vector(5 downto 0);
		incontRm: in std_logic_vector(5 downto 0);
		outwordm: out std_logic_vector(6 downto 0)
		);
end memram00;

architecture memram0 of memram00 is
signal scontrolm: std_logic_vector(1 downto 0);
type arrayram is array(0 to 63) of std_logic_vector(6 downto 0);
signal sword: arrayram;
begin
scontrolm <= (re)&(rwm);
	pram: process(clkm)
	begin
		if (clkm'event and clkm = '1') then
			case scontrolm is
				when "00" =>
					outwordm <= "0000000";
				when "01" =>
					outwordm <= "0000000";
				when "10" =>
					if(inFlagm = '1') then
						sword(conv_integer(incontWm)) <= inwordWm;
					end if;
				when "11" =>
					outwordm <= sword(conv_integer(incontRm));
				when others => null;
			end case;
		end if;
	end process pram;
end memram0;