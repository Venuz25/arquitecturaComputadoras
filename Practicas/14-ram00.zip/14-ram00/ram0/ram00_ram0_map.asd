[ActiveSupport MAP]
Device = LCMXO2-7000HE;
Package = TQFP144;
Performance = 5;
LUTS_avail = 6864;
LUTS_used = 201;
FF_avail = 6979;
FF_used = 59;
INPUT_LVCMOS25 = 12;
OUTPUT_LVCMOS25 = 36;
IO_avail = 115;
IO_used = 48;
EBR_avail = 26;
EBR_used = 0;
