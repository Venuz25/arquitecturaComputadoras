library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

package packagekey02 is
	component osc00
		port(
			cdiv: in std_logic_vector(5 downto 0);
			oscout0: inout std_logic
		);
	end component;
	
	component contring00
		port(
			clkcr: in std_logic;
			encr: in std_logic;
			outcr: inout std_logic_vector(3 downto 0)
		);
	end component;
	
	component coder00
		port(
			 clkcd: in std_logic;
			 encd: in std_logic;
			 incontcd: in std_logic_vector(3 downto 0);
			 inkeycd: in std_logic_vector(3 downto 0);
			 outcd: out std_logic_vector(3 downto 0);
			 outFlagcd: out std_logic
		);
	end component;
	
	component sshifth00
		port(
			clkh: in std_logic;
			enh, inFlagh: in std_logic;
			incodeh: in std_logic_vector(3 downto 0);
			outh: inout std_logic_vector(31 downto 0)
		);
	end component;
	
	component contring7seg00
		port(
			clkcrs: in std_logic;
			encrs: in std_logic;
			outcrs: out std_logic_vector(3 downto 0)
		);
	end component;
	
	component coder7seg00
		port(
			clkcdr: in std_logic;
			encdr: in std_logic;
			in32cdr: in std_logic_vector(31 downto 0);
			incontcdr: in std_logic_vector(3 downto 0);
			outcdr: out std_logic_vector(6 downto 0)
		);
	end component;

end packagekey02;