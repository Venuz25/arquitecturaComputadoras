library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity contring7seg00 is
	port(
		clkcrs: in std_logic;
		encrs: in std_logic;
		outcrs: out std_logic_vector(3 downto 0)
	);
end contring7seg00;

architecture contring7seg0 of contring7seg00 is
signal sshiftcrs: std_logic_vector(3 downto 0);
begin
	pshiftcrs: process(clkcrs)
	begin
		if(clkcrs'event and clkcrs='1') then
			case encrs is
				when '0' =>
					sshiftcrs <= "1000"; --Catodo
					outcrs <= "0000"; --Catodo
				when '1' =>
					sshiftcrs(0) <= sshiftcrs(3);
					sshiftcrs(3 downto 1) <= sshiftcrs(2 downto 0);
					outcrs <= sshiftcrs;
				when others => null;
			end case;
		end if;
	end process pshiftcrs;
end contring7seg0;