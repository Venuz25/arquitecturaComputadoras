library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;
use packagekey02.all;

entity key02 is
	port(
		clk0: inout std_logic;
		cdiv0: in std_logic_vector(5 downto 0);
		en0: in std_logic;
		inkey0: in std_logic_vector(3 downto 0); -- teclado
		outr0: inout std_logic_vector(3 downto 0); -- va al teclado
		out320: inout std_logic_vector(31 downto 0);
		outr70: inout std_logic_vector(3 downto 0); -- va a transistores
		outDisplay0: out std_logic_vector(6 downto 0);
		outFlag0: inout std_logic
	);
end key02;

architecture key0 of key02 is
signal signalH: std_logic_vector(3 downto 0);
begin
	K00: osc00 port map(
		oscout0 => clk0,
		cdiv => cdiv0
	);
	
	K01: contring00 port map(
		clkcr => clk0,
		encr => en0,
		outcr => outr0
	);
	
	K02: coder00 port map(
		clkcd => clk0,
		encd => en0,
		incontcd => outr0,
		inkeycd => inkey0,
		outcd => signalH,
		outFlagcd => outFlag0
	);
	
	K03: sshifth00 port map(
		clkh => clk0,
		enh => en0,
		inFlagh => outFlag0,
		incodeh => signalH,
		outh => out320
	);
	
	K04: contring7seg00 port map(
		clkcrs => clk0,
		encrs => en0,
		outcrs => outr70
	);
	
	K05: coder7seg00 port map(
		clkcdr => clk0,
		encdr => en0,
		in32cdr => out320,
		incontcdr => outr70,
		outcdr => outDisplay0
	);
end key0;