library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity coder7seg00 is
	port(
		clkcdr: in std_logic;
		encdr: in std_logic;
		in32cdr: in std_logic_vector(31 downto 0);
		incontcdr: in std_logic_vector(3 downto 0);
		outcdr: out std_logic_vector(6 downto 0)
	);
end coder7seg00;

architecture coder7seg0 of coder7seg00 is
signal snibb0, snibb1, snibb2, snibb3: std_logic_vector(3 downto 0);
signal snibb4, snibb5, snibb6, snibb7: std_logic_vector(3 downto 0);
signal sout7seg0, sout7seg1, sout7seg2, sout7seg3: std_logic_vector(6 downto 0);
signal sout7seg4, sout7seg5, sout7seg6, sout7seg7: std_logic_vector(6 downto 0);
begin
	snibb0 <= in32cdr(3 downto 0);
	snibb1 <= in32cdr(7 downto 4);
	snibb2 <= in32cdr(11 downto 8);
	snibb3 <= in32cdr(15 downto 12);
	snibb4 <= in32cdr(19 downto 16);
	snibb5 <= in32cdr(23 downto 20);
	snibb6 <= in32cdr(27 downto 24);
	snibb7 <= in32cdr(31 downto 28);
	
	with snibb0 select
		sout7seg0 <= -- Aguas, es catodo segun
			"1111110" when "0000", -- 0
			"0110000" when "0001", -- 1
			"1101101" when "0010", -- 2
			"1111001" when "0011", -- 3
			"0110011" when "0100", -- 4
			"1011011" when "0101", -- 5
			"1011111" when "0110", -- 6
			"1110000" when "0111", -- 7
			"1111111" when "1000", -- 8
			"1110011" when "1001", -- 9
			"1110111" when "1010", -- A
			"0011111" when "1011", -- b
			"1001110" when "1100", -- C
			"0111101" when "1101", -- d
			"1001111" when "1110", -- E
			"1000111" when "1111", -- F
			"0000000" when others;
			
	with snibb1 select
		sout7seg1<= -- Aguas, es catodo segun
			"1111110" when "0000", -- 0
			"0110000" when "0001", -- 1
			"1101101" when "0010", -- 2
			"1111001" when "0011", -- 3
			"0110011" when "0100", -- 4
			"1011011" when "0101", -- 5
			"1011111" when "0110", -- 6
			"1110000" when "0111", -- 7
			"1111111" when "1000", -- 8
			"1110011" when "1001", -- 9
			"1110111" when "1010", -- A
			"0011111" when "1011", -- b
			"1001110" when "1100", -- C
			"0111101" when "1101", -- d
			"1001111" when "1110", -- E
			"1000111" when "1111", -- F
			"0000000" when others;
			
	with snibb2 select
		sout7seg2 <= -- Aguas, es catodo segun
			"1111110" when "0000", -- 0
			"0110000" when "0001", -- 1
			"1101101" when "0010", -- 2
			"1111001" when "0011", -- 3
			"0110011" when "0100", -- 4
			"1011011" when "0101", -- 5
			"1011111" when "0110", -- 6
			"1110000" when "0111", -- 7
			"1111111" when "1000", -- 8
			"1110011" when "1001", -- 9
			"1110111" when "1010", -- A
			"0011111" when "1011", -- b
			"1001110" when "1100", -- C
			"0111101" when "1101", -- d
			"1001111" when "1110", -- E
			"1000111" when "1111", -- F
			"0000000" when others;
			
	with snibb3 select
		sout7seg3 <= -- Aguas, es catodo segun
			"1111110" when "0000", -- 0
			"0110000" when "0001", -- 1
			"1101101" when "0010", -- 2
			"1111001" when "0011", -- 3
			"0110011" when "0100", -- 4
			"1011011" when "0101", -- 5
			"1011111" when "0110", -- 6
			"1110000" when "0111", -- 7
			"1111111" when "1000", -- 8
			"1110011" when "1001", -- 9
			"1110111" when "1010", -- A
			"0011111" when "1011", -- b
			"1001110" when "1100", -- C
			"0111101" when "1101", -- d
			"1001111" when "1110", -- E
			"1000111" when "1111", -- F
			"0000000" when others;
			
	with snibb4 select
		sout7seg4 <= -- Aguas, es catodo segun
			"1111110" when "0000", -- 0
			"0110000" when "0001", -- 1
			"1101101" when "0010", -- 2
			"1111001" when "0011", -- 3
			"0110011" when "0100", -- 4
			"1011011" when "0101", -- 5
			"1011111" when "0110", -- 6
			"1110000" when "0111", -- 7
			"1111111" when "1000", -- 8
			"1110011" when "1001", -- 9
			"1110111" when "1010", -- A
			"0011111" when "1011", -- b
			"1001110" when "1100", -- C
			"0111101" when "1101", -- d
			"1001111" when "1110", -- E
			"1000111" when "1111", -- F
			"0000000" when others;
			
	with snibb5 select
		sout7seg5 <= -- Aguas, es catodo segun
			"1111110" when "0000", -- 0
			"0110000" when "0001", -- 1
			"1101101" when "0010", -- 2
			"1111001" when "0011", -- 3
			"0110011" when "0100", -- 4
			"1011011" when "0101", -- 5
			"1011111" when "0110", -- 6
			"1110000" when "0111", -- 7
			"1111111" when "1000", -- 8
			"1110011" when "1001", -- 9
			"1110111" when "1010", -- A
			"0011111" when "1011", -- b
			"1001110" when "1100", -- C
			"0111101" when "1101", -- d
			"1001111" when "1110", -- E
			"1000111" when "1111", -- F
			"0000000" when others;
			
	with snibb6 select
		sout7seg6 <= -- Aguas, es catodo segun
			"1111110" when "0000", -- 0
			"0110000" when "0001", -- 1
			"1101101" when "0010", -- 2
			"1111001" when "0011", -- 3
			"0110011" when "0100", -- 4
			"1011011" when "0101", -- 5
			"1011111" when "0110", -- 6
			"1110000" when "0111", -- 7
			"1111111" when "1000", -- 8
			"1110011" when "1001", -- 9
			"1110111" when "1010", -- A
			"0011111" when "1011", -- b
			"1001110" when "1100", -- C
			"0111101" when "1101", -- d
			"1001111" when "1110", -- E
			"1000111" when "1111", -- F
			"0000000" when others;
			
	with snibb7 select
		sout7seg7 <= -- Aguas, es catodo segun
			"1111110" when "0000", -- 0
			"0110000" when "0001", -- 1
			"1101101" when "0010", -- 2
			"1111001" when "0011", -- 3
			"0110011" when "0100", -- 4
			"1011011" when "0101", -- 5
			"1011111" when "0110", -- 6
			"1110000" when "0111", -- 7
			"1111111" when "1000", -- 8
			"1110011" when "1001", -- 9
			"1110111" when "1010", -- A
			"0011111" when "1011", -- b
			"1001110" when "1100", -- C
			"0111101" when "1101", -- d
			"1001111" when "1110", -- E
			"1000111" when "1111", -- F
			"0000000" when others;

	with incontcdr select
		outcdr <=
			sout7seg0 when "0001", -- POSIBLE CAMBIO
			sout7seg1 when "0010",
			sout7seg2 when "0100",
			sout7seg3 when "1000",
			"1111111" when others;
			
end coder7seg0;