library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity sshifth00 is
	port(
		clkh: in std_logic;
		enh, inFlagh: in std_logic;
		incodeh: in std_logic_vector(3 downto 0);
		outh: inout std_logic_vector(31 downto 0)
	);
end sshifth00;

architecture sshifth0 of sshifth00 is
begin
	pshifth: process(clkh)
	begin
		if(clkh'event and clkh='1') then
			case enh is
				when '0' =>
					outh <= (others => '0'); --Puede que se tenga que cambiar a 1
				when '1' =>
					if(inFlagh = '1') then
						outh(3 downto 0) <= incodeh;
						outh(31 downto 4) <= outh(27 downto 0);
					end if;
				when others => null;
			end case;
		end if;
	end process pshifth;
end sshifth0;