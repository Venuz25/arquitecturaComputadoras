library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity coder00 is
	port(
		 clkcd: in std_logic;
		 encd: in std_logic;
		 incontcd: in std_logic_vector(3 downto 0);
		 inkeycd: in std_logic_vector(3 downto 0);
		 outcd: out std_logic_vector(3 downto 0);
		 outFlagcd: out std_logic
	);
end coder00;

architecture coder0 of coder00 is
begin
	pcode: process(clkcd)
	variable aux0: bit:='0';
	variable aux1: bit:='0';
	variable aux2: bit:='0';
	variable aux3: bit:='0';
	begin
		if(clkcd'event and clkcd='1') then
			case encd is
				when '0' =>
					outcd <= "0000";
					aux0:='0';
					aux1:='0';
					aux2:='0';
					aux3:='0';
				when '1' =>
					case incontcd is
						----------------------------------------------------
						when "0001" =>
						------------------------------------------------
							case inkeycd is
								when "0000" =>
									outFlagcd <= '0';
									aux0:='0';
								when "1000" =>
									if(aux0 = '0') then
										aux0:= '1';
										outcd <= "0001"; -- 1
										outFlagcd <= '1';
									else
										outFlagcd <= '0';
									end if;
								when "0100" =>
									if(aux0 = '0') then
										aux0:= '1';
										outcd <= "0010"; -- 2
										outFlagcd <= '1';
									else
										outFlagcd <= '0';
									end if;
								when "0010" =>
									if(aux0 = '0') then
										aux0:= '1';
										outcd <= "0011"; -- 3
										outFlagcd <= '1';
									else
										outFlagcd <= '0';
									end if;
								when "0001" =>
									if(aux0 = '0') then
										aux0:= '1';
										outcd <= "1010"; -- A
										outFlagcd <= '1';
									else
										outFlagcd <= '0';
									end if;
								when others => null;
							end case;
						-------------------------------------------------
						when "0010" =>
						------------------------------------------------
							case inkeycd is
								when "0000" =>
									outFlagcd <= '0';
									aux1:='0';
								when "1000" =>
									if(aux1 = '0') then
										aux1:= '1';
										outcd <= "0100"; -- 4
										outFlagcd <= '1';
									else
										outFlagcd <= '0';
									end if;
								when "0100" =>
									if(aux1 = '0') then
										aux1:= '1';
										outcd <= "0101"; -- 5
										outFlagcd <= '1';
									else
										outFlagcd <= '0';
									end if;
								when "0010" =>
									if(aux1 = '0') then
										aux1:= '1';
										outcd <= "0110"; -- 6
										outFlagcd <= '1';
									else
										outFlagcd <= '0';
									end if;
								when "0001" =>
									if(aux1 = '0') then
										aux1:= '1';
										outcd <= "1011"; -- b
										outFlagcd <= '1';
									else
										outFlagcd <= '0';
									end if;
								when others => null;
							end case;
					-------------------------------------------------
						when "0100" =>
						------------------------------------------------
							case inkeycd is
								when "0000" =>
									outFlagcd <= '0';
									aux2:='0';
								when "1000" =>
									if(aux2 = '0') then
										aux2:= '1';
										outcd <= "0111"; -- 7
										outFlagcd <= '1';
									else
										outFlagcd <= '0';
									end if;
								when "0100" =>
									if(aux2 = '0') then
										aux2:= '1';
										outcd <= "1000"; -- 8
										outFlagcd <= '1';
									else
										outFlagcd <= '0';
									end if;
								when "0010" =>
									if(aux2 = '0') then
										aux2:= '1';
										outcd <= "1001"; -- 9
										outFlagcd <= '1';
									else
										outFlagcd <= '0';
									end if;
								when "0001" =>
									if(aux2 = '0') then
										aux2:= '1';
										outcd <= "1100"; -- C
										outFlagcd <= '1';
									else
										outFlagcd <= '0';
									end if;
								when others => null;
							end case;
					-------------------------------------------------
						when "1000" =>
						------------------------------------------------
							case inkeycd is
								when "0000" =>
									outFlagcd <= '0';
									aux3:='0';
								when "1000" =>
									if(aux3 = '0') then
										aux3:= '1';
										outcd <= "1110"; -- E
										outFlagcd <= '1';
									else
										outFlagcd <= '0';
									end if;
								when "0100" =>
									if(aux3 = '0') then
										aux3:= '1';
										outcd <= "0000"; -- 0
										outFlagcd <= '1';
									else
										outFlagcd <= '0';
									end if;
								when "0010" =>
									if(aux3 = '0') then
										aux3:= '1';
										outcd <= "1111"; -- F
										outFlagcd <= '1';
									else
										outFlagcd <= '0';
									end if;
								when "0001" =>
									if(aux3 = '0') then
										aux3:= '1';
										outcd <= "1101"; -- d
										outFlagcd <= '1';
									else
										outFlagcd <= '0';
									end if;
								when others => null;
							end case;
						-------------------------------------------------
						when others => null;
						-------------------------------------------------
					end case;
				when others => null;
			end case;
		end if;
	end process pcode;
end coder0;