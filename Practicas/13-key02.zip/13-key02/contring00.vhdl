library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity contring00 is
	port(
		clkcr: in std_logic;
		encr: in std_logic;
		outcr: inout std_logic_vector(3 downto 0)
	);
end contring00;

architecture contring0 of contring00 is
signal sshiftcr: std_logic_vector(3 downto 0);
begin
	pshift: process(clkcr)
	begin
		if(clkcr'event and clkcr = '1') then
			case encr is
				when '0' => 
					sshiftcr <= "0001";
					outcr <= "0000";
				when '1' => 
					sshiftcr(3) <= sshiftcr(0);
					sshiftcr(2 downto 0) <= sshiftcr(3 downto 1);
					outcr <= sshiftcr;
				when others => null; 
			end case;
		end if;
	end process pshift;
end contring0;