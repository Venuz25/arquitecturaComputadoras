--
-- Synopsys
-- Vhdl wrapper for top level design, written on Wed Nov  8 10:53:37 2023
--
library ieee;
use ieee.std_logic_1164.all;
library work;
use work.packageword00.all;

entity wrapper_for_topword00 is
   port (
      cdiv00 : in std_logic_vector(4 downto 0);
      enable0 : in std_logic;
      clk00 : in std_logic;
      outtran0 : in std_logic_vector(3 downto 0);
      outbcd70 : out std_logic_vector(6 downto 0)
   );
end wrapper_for_topword00;

architecture topword0 of wrapper_for_topword00 is

component topword00
 port (
   cdiv00 : in std_logic_vector (4 downto 0);
   enable0 : in std_logic;
   clk00 : inout std_logic;
   outtran0 : inout std_logic_vector (3 downto 0);
   outbcd70 : out std_logic_vector (6 downto 0)
 );
end component;

signal tmp_cdiv00 : std_logic_vector (4 downto 0);
signal tmp_enable0 : std_logic;
signal tmp_clk00 : std_logic;
signal tmp_outtran0 : std_logic_vector (3 downto 0);
signal tmp_outbcd70 : std_logic_vector (6 downto 0);

begin

tmp_cdiv00 <= cdiv00;

tmp_enable0 <= enable0;

tmp_clk00 <= clk00;

tmp_outtran0 <= outtran0;

outbcd70 <= tmp_outbcd70;



u1:   topword00 port map (
		cdiv00 => tmp_cdiv00,
		enable0 => tmp_enable0,
		clk00 => tmp_clk00,
		outtran0 => tmp_outtran0,
		outbcd70 => tmp_outbcd70
       );
end topword0;
