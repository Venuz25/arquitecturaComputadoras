[ActiveSupport TRCE]
; Setup Analysis
Fmax_0 = 59.393 MHz (2.080 MHz);
Failed = 0 (Total 1);
Clock_ports = 0;
Clock_nets = 4;
; Hold Analysis
Fmax_0 = 0.379 ns (0.000 ns);
Failed = 0 (Total 1);
Clock_ports = 0;
Clock_nets = 4;
