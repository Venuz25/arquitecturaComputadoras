--
-- Synopsys
-- Vhdl wrapper for top level design, written on Sat Jan 11 17:33:52 2025
--
library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
library work;
use work.packagep00.all;

entity wrapper_for_topconvbcd00 is
   port (
      clk0 : in std_logic;
      cdiv0 : in std_logic_vector(5 downto 0);
      sclk0 : in std_logic;
      reset0 : in std_logic;
      reset1 : in std_logic;
      soutFlagpc : in std_logic;
      sFlagInst : in std_logic;
      sFlag8out : in std_logic;
      sFlag12out : in std_logic;
      sFlag12B : in std_logic;
      soutFlagrom : in std_logic;
      soutFlagIt : in std_logic;
      outpcport : in std_logic_vector(3 downto 0);
      outcodeport : in std_logic_vector(3 downto 0);
      inport8a0 : in std_logic_vector(7 downto 0);
      outport120 : in std_logic_vector(11 downto 0);
      outport8a0 : in std_logic_vector(7 downto 0);
      outTransist0 : in std_logic_vector(3 downto 0);
      outDisplay : out std_logic_vector(6 downto 0)
   );
end wrapper_for_topconvbcd00;

architecture topconvbcd0 of wrapper_for_topconvbcd00 is

component topconvbcd00
 port (
   clk0 : inout std_logic;
   cdiv0 : in std_logic_vector (5 downto 0);
   sclk0 : inout std_logic;
   reset0 : in std_logic;
   reset1 : in std_logic;
   soutFlagpc : inout std_logic;
   sFlagInst : inout std_logic;
   sFlag8out : inout std_logic;
   sFlag12out : inout std_logic;
   sFlag12B : inout std_logic;
   soutFlagrom : inout std_logic;
   soutFlagIt : inout std_logic;
   outpcport : inout std_logic_vector (3 downto 0);
   outcodeport : inout std_logic_vector (3 downto 0);
   inport8a0 : inout std_logic_vector (7 downto 0);
   outport120 : inout std_logic_vector (11 downto 0);
   outport8a0 : inout std_logic_vector (7 downto 0);
   outTransist0 : inout std_logic_vector (3 downto 0);
   outDisplay : out std_logic_vector (6 downto 0)
 );
end component;

signal tmp_clk0 : std_logic;
signal tmp_cdiv0 : std_logic_vector (5 downto 0);
signal tmp_sclk0 : std_logic;
signal tmp_reset0 : std_logic;
signal tmp_reset1 : std_logic;
signal tmp_soutFlagpc : std_logic;
signal tmp_sFlagInst : std_logic;
signal tmp_sFlag8out : std_logic;
signal tmp_sFlag12out : std_logic;
signal tmp_sFlag12B : std_logic;
signal tmp_soutFlagrom : std_logic;
signal tmp_soutFlagIt : std_logic;
signal tmp_outpcport : std_logic_vector (3 downto 0);
signal tmp_outcodeport : std_logic_vector (3 downto 0);
signal tmp_inport8a0 : std_logic_vector (7 downto 0);
signal tmp_outport120 : std_logic_vector (11 downto 0);
signal tmp_outport8a0 : std_logic_vector (7 downto 0);
signal tmp_outTransist0 : std_logic_vector (3 downto 0);
signal tmp_outDisplay : std_logic_vector (6 downto 0);

begin

tmp_clk0 <= clk0;

tmp_cdiv0 <= cdiv0;

tmp_sclk0 <= sclk0;

tmp_reset0 <= reset0;

tmp_reset1 <= reset1;

tmp_soutFlagpc <= soutFlagpc;

tmp_sFlagInst <= sFlagInst;

tmp_sFlag8out <= sFlag8out;

tmp_sFlag12out <= sFlag12out;

tmp_sFlag12B <= sFlag12B;

tmp_soutFlagrom <= soutFlagrom;

tmp_soutFlagIt <= soutFlagIt;

tmp_outpcport <= outpcport;

tmp_outcodeport <= outcodeport;

tmp_inport8a0 <= inport8a0;

tmp_outport120 <= outport120;

tmp_outport8a0 <= outport8a0;

tmp_outTransist0 <= outTransist0;

outDisplay <= tmp_outDisplay;



u1:   topconvbcd00 port map (
		clk0 => tmp_clk0,
		cdiv0 => tmp_cdiv0,
		sclk0 => tmp_sclk0,
		reset0 => tmp_reset0,
		reset1 => tmp_reset1,
		soutFlagpc => tmp_soutFlagpc,
		sFlagInst => tmp_sFlagInst,
		sFlag8out => tmp_sFlag8out,
		sFlag12out => tmp_sFlag12out,
		sFlag12B => tmp_sFlag12B,
		soutFlagrom => tmp_soutFlagrom,
		soutFlagIt => tmp_soutFlagIt,
		outpcport => tmp_outpcport,
		outcodeport => tmp_outcodeport,
		inport8a0 => tmp_inport8a0,
		outport120 => tmp_outport120,
		outport8a0 => tmp_outport8a0,
		outTransist0 => tmp_outTransist0,
		outDisplay => tmp_outDisplay
       );
end topconvbcd0;
