[ActiveSupport MAP]
Device = LCMXO2-7000HE;
Package = TQFP144;
Performance = 5;
LUTS_avail = 6864;
LUTS_used = 260;
FF_avail = 6979;
FF_used = 159;
INPUT_LVCMOS25 = 16;
OUTPUT_LVCMOS25 = 46;
BIDI_LVCMOS25 = 2;
IO_avail = 115;
IO_used = 64;
EBR_avail = 26;
EBR_used = 0;
