run_tcl -fg BCD00_BCD0_synplify.tcl
