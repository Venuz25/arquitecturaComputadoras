--
-- Synopsys
-- Vhdl wrapper for top level design, written on Mon May 26 09:16:16 2025
--
library ieee;
use ieee.std_logic_1164.all;
library work;
use work.packagerom00.all;

entity wrapper_for_toprom00 is
   port (
      clk0 : in std_logic;
      cdiv0 : in std_logic_vector(4 downto 0);
      en0 : in std_logic;
      outcont0 : in std_logic_vector(4 downto 0);
      outword0 : out std_logic_vector(6 downto 0);
      outtransist0 : out std_logic_vector(3 downto 0)
   );
end wrapper_for_toprom00;

architecture toprom0 of wrapper_for_toprom00 is

component toprom00
 port (
   clk0 : inout std_logic;
   cdiv0 : in std_logic_vector (4 downto 0);
   en0 : in std_logic;
   outcont0 : inout std_logic_vector (4 downto 0);
   outword0 : out std_logic_vector (6 downto 0);
   outtransist0 : out std_logic_vector (3 downto 0)
 );
end component;

signal tmp_clk0 : std_logic;
signal tmp_cdiv0 : std_logic_vector (4 downto 0);
signal tmp_en0 : std_logic;
signal tmp_outcont0 : std_logic_vector (4 downto 0);
signal tmp_outword0 : std_logic_vector (6 downto 0);
signal tmp_outtransist0 : std_logic_vector (3 downto 0);

begin

tmp_clk0 <= clk0;

tmp_cdiv0 <= cdiv0;

tmp_en0 <= en0;

tmp_outcont0 <= outcont0;

outword0 <= tmp_outword0;

outtransist0 <= tmp_outtransist0;



u1:   toprom00 port map (
		clk0 => tmp_clk0,
		cdiv0 => tmp_cdiv0,
		en0 => tmp_en0,
		outcont0 => tmp_outcont0,
		outword0 => tmp_outword0,
		outtransist0 => tmp_outtransist0
       );
end toprom0;
