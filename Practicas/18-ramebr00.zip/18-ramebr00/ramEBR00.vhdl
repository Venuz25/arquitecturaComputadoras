library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;
use packageramEBR00.all;

entity ramEBR00 is
	Port(
		clk0: inout std_logic;
		cdiv0: in std_logic_vector(5 downto 0);
		re0, en0, rw0: in std_logic;
		--inData0: in std_logic_vector(15 downto 0);
		Address0: inout std_logic_vector(5 downto 0);
		Q0: out std_logic_vector(15 downto 0)
	);
end ramEBR00;

architecture ramEBR0 of ramEBR00 is
signal sData0: std_logic_vector(15 downto 0);
begin
	sData0 <= "1111000011110000";

	MERB00: osc00 port map(oscout0 => clk0,
													cdiv => cdiv0);
	
	MERB01: contRead00 port map(clkrd => clk0,
																rerd => re0,
																enrd => en0,
																rwrd => rw0,
																outcontrd => Address0);
	
	MERB02: ram_EBR_00 port map(Clock => clk0,
																ClockEn => en0,
																Reset => re0,
																WE => rw0,
																Address => Address0,
																Data => sData0,
																Q => Q0
																);
end ramEBR0;