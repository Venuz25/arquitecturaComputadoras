library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
library lattice;
use lattice.all;

entity contRead00 is
	Port(
		clkrd: in std_logic;
		rerd, enrd, rwrd: in std_logic;
		outcontrd: inout std_logic_vector(5 downto 0)
	);
end contRead00;

architecture contRead0 of contRead00 is
signal scontrolrd: std_logic_vector(2 downto 0);
begin
	scontrolrd <= (rerd) & (enrd) & (rwrd);
	pcont: process(clkrd)
	begin
		if (clkrd'event and clkrd='1') then
			case scontrolrd is
				when "010" =>
					if (outcontrd < "111111") then
						outcontrd <= outcontrd + "000001";
					else
						outcontrd <= outcontrd;
					end if;
				when "011" =>
					if (outcontrd < "111111") then
						outcontrd <= outcontrd + "000001";
					else
						outcontrd <= outcontrd;
					end if;
				when "111" =>
					outcontrd <= "000000";
				when others => null;
			end case;
		end if;
	end process pcont;
end contRead0;