run_tcl -fg adder8bitLib00_adder8bitLib0_synplify.tcl
