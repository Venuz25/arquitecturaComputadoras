[ActiveSupport TRCE]
; Setup Analysis
Other_0 = 12.579 ns (0.000 ns);
Other_1 = 4.360 ns (0.000 ns);
Failed = 0 (Total 2);
Clock_ports = 0;
Clock_nets = 0;
