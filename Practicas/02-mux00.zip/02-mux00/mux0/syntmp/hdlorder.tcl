set_option -top_module work.mux00
project -fileorder "C:/lscc/diamond/3.14/cae_library/synthesis/vhdl/machxo2.vhd" "D:/Archivos/Escuela/Arquitectura\ de\ Computadoras/Practicas/02-mux00/mux00.vhdl" 