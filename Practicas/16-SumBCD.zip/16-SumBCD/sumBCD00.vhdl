library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_signed.all;
library lattice;
use lattice.all;
use packagesumBCD00.all;

entity sumBCD is
	port(
		clk00: inout std_logic;
		error: out std_logic;
		cdiv00: in std_logic_vector(5 downto 0); 
		inA, inB: in std_logic_vector(7 downto 0);
		en0: in std_logic;
		sclk00: inout std_logic ;
		reset00: in std_logic ;
		reset10: in std_logic ;
		soutFlagpc0: inout std_logic ;
		sFlagInst0: inout std_logic ;
		sFlag8out0: inout std_logic;
		sFlag12out0: inout std_logic;
		sFlag12B0: inout std_logic;
		soutFlagrom0: inout std_logic;
		soutFlagIt0: inout std_logic;
		outpcport0: inout std_logic_vector ( 3 downto 0 );
		outcodeport0: inout std_logic_vector ( 3 downto 0 );
		inport8a00: inout std_logic_vector ( 7 downto 0 );
		outport1200: inout std_logic_vector ( 11 downto 0 );
		outport8a00: inout std_logic_vector ( 7 downto 0 ); 
		outTransist00: inout std_logic_vector(3 downto 0);
		outDisplay0: out std_logic_vector(6 downto 0)
	);
end sumBCD;

architecture sumBCD0 of sumBCD is
signal sSum, sConv: std_logic_vector(7 downto 0);
signal ineg: std_logic;
begin
	SBCD00: adder8bit00 port map(
		Ai => inA,
		Bi => inB,
		SL => en0,
		LED => error,
		So => sSum
	);
	
	SBCD01: comp200 port map(
		inAc => sSum,
		outAc => sConv,
		outneg => ineg
	);
	
	SBCD02: topconvbcd00 port map(
		clk0 => clk00,
		cdiv0 => cdiv00,
		sclk0 => sclk00,
		reset0 => reset00,
		reset1 => reset10,
		inneg => ineg,
		soutFlagpc => soutFlagpc0,
		sFlagInst => sFlagInst0,
		sFlag8out => sFlag8out0,
		sFlag12out => sFlag12out0,
		sFlag12B => sFlag12B0,
		soutFlagrom => soutFlagrom0,
		soutFlagIt => soutFlagIt0,
		outpcport => outpcport0,
		outcodeport => outcodeport0,
		inport8a0 => sConv,
		outport120 => outport1200,
		outport8a0 => outport8a00,
		outTransist0 => outTransist00,
		outDisplay => outDisplay0
	);
	
end sumBCD0;