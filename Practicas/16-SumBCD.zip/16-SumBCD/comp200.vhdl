library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
library lattice;
use lattice.all;

entity comp200 is
	port(
		inAc: in std_logic_vector(7 downto 0);
		outAc: out std_logic_vector(7 downto 0);
		outneg: out std_logic
	);
end comp200;

architecture comp20 of comp200 is
begin
	pcomp: process(inAc)
	begin
		if(inAc(7) = '1') then
			outneg <= '1';
			outAc <= not(inAc) + 1;
		else
			outneg <= '0';
			outAc <= inAc;
		end if;
	end process pcomp;
end comp20;
