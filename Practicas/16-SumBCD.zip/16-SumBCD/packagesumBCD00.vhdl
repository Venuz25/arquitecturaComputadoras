library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

package packagesumBCD00 is
	component topconvbcd00 is
		port( 
			clk0: inout std_logic ;
			cdiv0: in std_logic_vector(5 downto 0); 
			sclk0: inout std_logic ;
			reset0: in std_logic ;
			reset1: in std_logic ;
			inneg: in std_logic;
			soutFlagpc: inout std_logic ;
			sFlagInst: inout std_logic ;
			sFlag8out: inout std_logic;
			sFlag12out: inout std_logic;
			sFlag12B: inout std_logic;
			soutFlagrom: inout std_logic;
			soutFlagIt : inout std_logic;
			outpcport: inout std_logic_vector ( 3 downto 0 );
			outcodeport: inout std_logic_vector ( 3 downto 0 );
			inport8a0: inout std_logic_vector ( 7 downto 0 );
			outport120: inout std_logic_vector ( 11 downto 0 );
			outport8a0: inout std_logic_vector ( 7 downto 0 ); 
			outTransist0: inout std_logic_vector(3 downto 0);
			outDisplay: out std_logic_vector(6 downto 0)
		);
	end component;
	
	component comp200 is
		port(
			inAc: in std_logic_vector(7 downto 0);
			outAc: out std_logic_vector(7 downto 0);
			outneg: out std_logic
		);
	end component;
	
	component adder8bit00 is
		port(
			Ai: in std_logic_vector(7 downto 0);
			Bi: in std_logic_vector(7 downto 0);
			SL: in std_logic;
			LED: out std_logic;
			So: out std_logic_vector(7 downto 0)
		);
	end component;
end packagesumBCD00;