--
-- Synopsys
-- Vhdl wrapper for top level design, written on Sun Jun  8 15:41:28 2025
--
library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_signed.all;
library work;
use work.packagesumbcd00.all;

entity wrapper_for_sumBCD is
   port (
      clk00 : in std_logic;
      error : out std_logic;
      cdiv00 : in std_logic_vector(5 downto 0);
      inA : in std_logic_vector(7 downto 0);
      inB : in std_logic_vector(7 downto 0);
      en0 : in std_logic;
      sclk00 : in std_logic;
      reset00 : in std_logic;
      reset10 : in std_logic;
      soutFlagpc0 : in std_logic;
      sFlagInst0 : in std_logic;
      sFlag8out0 : in std_logic;
      sFlag12out0 : in std_logic;
      sFlag12B0 : in std_logic;
      soutFlagrom0 : in std_logic;
      soutFlagIt0 : in std_logic;
      outpcport0 : in std_logic_vector(3 downto 0);
      outcodeport0 : in std_logic_vector(3 downto 0);
      inport8a00 : in std_logic_vector(7 downto 0);
      outport1200 : in std_logic_vector(11 downto 0);
      outport8a00 : in std_logic_vector(7 downto 0);
      outTransist00 : in std_logic_vector(3 downto 0);
      outDisplay0 : out std_logic_vector(6 downto 0)
   );
end wrapper_for_sumBCD;

architecture sumbcd0 of wrapper_for_sumBCD is

component sumBCD
 port (
   clk00 : inout std_logic;
   error : out std_logic;
   cdiv00 : in std_logic_vector (5 downto 0);
   inA : in std_logic_vector (7 downto 0);
   inB : in std_logic_vector (7 downto 0);
   en0 : in std_logic;
   sclk00 : inout std_logic;
   reset00 : in std_logic;
   reset10 : in std_logic;
   soutFlagpc0 : inout std_logic;
   sFlagInst0 : inout std_logic;
   sFlag8out0 : inout std_logic;
   sFlag12out0 : inout std_logic;
   sFlag12B0 : inout std_logic;
   soutFlagrom0 : inout std_logic;
   soutFlagIt0 : inout std_logic;
   outpcport0 : inout std_logic_vector (3 downto 0);
   outcodeport0 : inout std_logic_vector (3 downto 0);
   inport8a00 : inout std_logic_vector (7 downto 0);
   outport1200 : inout std_logic_vector (11 downto 0);
   outport8a00 : inout std_logic_vector (7 downto 0);
   outTransist00 : inout std_logic_vector (3 downto 0);
   outDisplay0 : out std_logic_vector (6 downto 0)
 );
end component;

signal tmp_clk00 : std_logic;
signal tmp_error : std_logic;
signal tmp_cdiv00 : std_logic_vector (5 downto 0);
signal tmp_inA : std_logic_vector (7 downto 0);
signal tmp_inB : std_logic_vector (7 downto 0);
signal tmp_en0 : std_logic;
signal tmp_sclk00 : std_logic;
signal tmp_reset00 : std_logic;
signal tmp_reset10 : std_logic;
signal tmp_soutFlagpc0 : std_logic;
signal tmp_sFlagInst0 : std_logic;
signal tmp_sFlag8out0 : std_logic;
signal tmp_sFlag12out0 : std_logic;
signal tmp_sFlag12B0 : std_logic;
signal tmp_soutFlagrom0 : std_logic;
signal tmp_soutFlagIt0 : std_logic;
signal tmp_outpcport0 : std_logic_vector (3 downto 0);
signal tmp_outcodeport0 : std_logic_vector (3 downto 0);
signal tmp_inport8a00 : std_logic_vector (7 downto 0);
signal tmp_outport1200 : std_logic_vector (11 downto 0);
signal tmp_outport8a00 : std_logic_vector (7 downto 0);
signal tmp_outTransist00 : std_logic_vector (3 downto 0);
signal tmp_outDisplay0 : std_logic_vector (6 downto 0);

begin

tmp_clk00 <= clk00;

error <= tmp_error;

tmp_cdiv00 <= cdiv00;

tmp_inA <= inA;

tmp_inB <= inB;

tmp_en0 <= en0;

tmp_sclk00 <= sclk00;

tmp_reset00 <= reset00;

tmp_reset10 <= reset10;

tmp_soutFlagpc0 <= soutFlagpc0;

tmp_sFlagInst0 <= sFlagInst0;

tmp_sFlag8out0 <= sFlag8out0;

tmp_sFlag12out0 <= sFlag12out0;

tmp_sFlag12B0 <= sFlag12B0;

tmp_soutFlagrom0 <= soutFlagrom0;

tmp_soutFlagIt0 <= soutFlagIt0;

tmp_outpcport0 <= outpcport0;

tmp_outcodeport0 <= outcodeport0;

tmp_inport8a00 <= inport8a00;

tmp_outport1200 <= outport1200;

tmp_outport8a00 <= outport8a00;

tmp_outTransist00 <= outTransist00;

outDisplay0 <= tmp_outDisplay0;



u1:   sumBCD port map (
		clk00 => tmp_clk00,
		error => tmp_error,
		cdiv00 => tmp_cdiv00,
		inA => tmp_inA,
		inB => tmp_inB,
		en0 => tmp_en0,
		sclk00 => tmp_sclk00,
		reset00 => tmp_reset00,
		reset10 => tmp_reset10,
		soutFlagpc0 => tmp_soutFlagpc0,
		sFlagInst0 => tmp_sFlagInst0,
		sFlag8out0 => tmp_sFlag8out0,
		sFlag12out0 => tmp_sFlag12out0,
		sFlag12B0 => tmp_sFlag12B0,
		soutFlagrom0 => tmp_soutFlagrom0,
		soutFlagIt0 => tmp_soutFlagIt0,
		outpcport0 => tmp_outpcport0,
		outcodeport0 => tmp_outcodeport0,
		inport8a00 => tmp_inport8a00,
		outport1200 => tmp_outport1200,
		outport8a00 => tmp_outport8a00,
		outTransist00 => tmp_outTransist00,
		outDisplay0 => tmp_outDisplay0
       );
end sumbcd0;
