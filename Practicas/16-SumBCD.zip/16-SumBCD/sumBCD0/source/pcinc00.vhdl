library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
library lattice;
use lattice.all;
library machxo2;
use machxo2.all;

entity pcinc00 is
port( 
	clkpc: in std_logic ;
	resetpc: in std_logic ;
	incode: in std_logic_vector ( 3 downto 0 );
	outpc: inout std_logic_vector ( 3 downto 0 );
	inFlagAC8bit: in std_logic ;
	inFlagAC12bit: in std_logic ;
	flagiter: in std_logic ;
	outFlagpc: out std_logic  );
end pcinc00;

architecture pcinc0 of pcinc00 is
begin
  pcprocess: process(resetpc, inFlagAC8bit)
    begin
      if (clkpc'event and clkpc = '1') then
         if (resetpc = '0' and flagiter = '1') then
             outpc <= "0000";
             outFlagpc <= '1';

         elsif (resetpc = '0' and flagiter = '1') then
             outpc <= "0000";
             outFlagpc <= '0';

         elsif (resetpc = '1' and flagiter = '1') then
             outpc <= outpc + 0;
             outFlagpc <= '0';

         elsif (resetpc = '1' and flagiter = '0' and incode > "0101") then
             outpc <= "0010";
             outFlagpc <= '1';

         elsif (resetpc = '1' and flagiter = '1' and incode > "0101") then
             outpc <= outpc + 0;
             outFlagpc <= '0';

         elsif (resetpc = '0' and flagiter = '1' and incode > "0101") then
             outpc <= "0000";
             outFlagpc <= '0';

         elsif (resetpc = '1' and flagiter = '0' and incode > "0101") then
             outpc <= "0000";
             outFlagpc <= '1';


         elsif (resetpc = '0' and incode = "0000") then
             outpc <= "0000";
             outFlagpc <= '1';
         elsif (resetpc = '1' and incode = "0000") then
             outpc <= outpc + 1;
             outFlagpc <= '1';
         elsif (resetpc = '0' and flagiter ='0' and incode > "0000") then
             outpc <= "0000";
             outFlagpc <= '1';
         elsif (resetpc = '1' and flagiter = '0' and incode = "0000") then
             outpc <= outpc + 1;
             outFlagpc <= '1';

         elsif (resetpc = '1' and flagiter ='1' and incode > "0010") then
             outpc <= "0000";
             outFlagpc <= '1';
         elsif (resetpc = '1' and flagiter = '1' and incode = "0000") then
             outpc <= "0000";
             outFlagpc <= '1';
         elsif (resetpc = '0' and flagiter = '0' and incode = "0000") then
             outpc <= "0000";
             outFlagpc <= '1';

         --EL SIGUIENTE ES EL M�DULO DE INICIALIZACI�N
         elsif (inFlagAC8bit = '1' and incode = "0000") then
             outpc <= outpc + 1;
             outFlagpc <= '1';
         elsif (inFlagAC8bit = '0' and incode = "0000") then
             outpc <= outpc + 0;
             outFlagpc <= '0';
         --EL SIGUIENTE ES EL M�DULO DE portAB
         elsif (inFlagAC8bit = '1' and incode = "0001") then
             outpc <= outpc + 1;
             outFlagpc <= '1';
         elsif (inFlagAC8bit = '0' and incode = "0001") then
             outpc <= outpc + 0;
             outFlagpc <= '0';
         --EL SIGUIENTE M�DULO ES EL DE SUSTITUCI�N
         elsif (inFlagAC12bit = '1' and incode = "0010") then
             outpc <= outpc + 1;
             outFlagpc <= '1';
         elsif (inFlagAC12bit = '0' and incode = "0010") then
             outpc <= outpc + 0;
             outFlagpc <= '0';

         elsif (flagiter = '1') then
             outpc <= outpc + 0;
             outFlagpc <= '0';


         --EL SIGUIENTE ES EL M�DULO QUE COMPARA Y SUMA
         elsif (inFlagAC12bit = '1' and incode = "0011") then
             outpc <= outpc + 1;
             outFlagpc <= '1';
         elsif (inFlagAC12bit = '0' and incode = "0011") then
             outpc <= outpc + 0;
             outFlagpc <= '0';
         --EL SIGUIENTE ES EL EL M�DULO QUE DESPLAZA EN 8 BITS
         elsif (inFlagAC8bit = '1' and incode = "0100") then
             outpc <= outpc + 1;
             outFlagpc <= '1';
         elsif (inFlagAC8bit = '0' and incode = "0100") then
             outpc <= outpc + 0;
             outFlagpc <= '0';
         --EL SIGUIENTE ES EL EL M�DULO QUE DESPLAZA EN 12 BITS
         elsif (inFlagAC12bit = '1' and incode = "0101") then
             outpc <= outpc + 1;
             outFlagpc <= '1';
         elsif (inFlagAC12bit = '0' and incode = "0101") then
             outpc <= outpc + 0;
             outFlagpc <= '0';

         else
             outpc <= "0010";
             outFlagpc <= '1';
         end if;
      end if;
    end process pcprocess;
end pcinc0;
