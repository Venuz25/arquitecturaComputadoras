library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
library lattice;
use lattice.all;
library machxo2;
use machxo2.all;

entity coderNibbles00 is
port( 
	AC12bit03: in std_logic_vector ( 11 downto 0 );
	outU: out std_logic_vector ( 6 downto 0 );
	outD: out std_logic_vector ( 6 downto 0 );
	outC: out std_logic_vector ( 6 downto 0 ) );
end coderNibbles00;

architecture coderNibbles0 of coderNibbles00 is
signal nibbU, nibbD, nibbC: std_logic_vector(3 downto 0);
begin
  pbuffNibb: process(AC12bit03)
    begin
       nibbU <= AC12bit03(3 downto 0);
       nibbD <= AC12bit03(7 downto 4);
       nibbC <= AC12bit03(11 downto 8);
    end process pbuffNibb;

  pcoderU: process(nibbU)
    begin
       case nibbU is
          when "0000" => 
             outU <= "1111110";
          when "0001" => 
             outU <= "0110000";
          when "0010" => 
             outU <= "1101101";
          when "0011" => 
             outU <= "1111001";
          when "0100" => 
             outU <= "0110011";
          when "0101" => 
             outU <= "1011011";
          when "0110" => 
             outU <= "1011111";
          when "0111" => 
             outU <= "1110000";
          when "1000" => 
             outU <= "1111111";
          when "1001" => 
             outU <= "1111011";
          when others => 
             outU <= "0000000";
       end case;
    end process pcoderU;

  pcoderD: process(nibbD)
    begin
       case nibbD is
          when "0000" => 
             outD <= "1111110";
          when "0001" => 
             outD <= "0110000";
          when "0010" => 
             outD <= "1101101";
          when "0011" => 
             outD <= "1111001";
          when "0100" => 
             outD <= "0110011";
          when "0101" => 
             outD <= "1011011";
          when "0110" => 
             outD <= "1011111";
          when "0111" => 
             outD <= "1110000";
          when "1000" => 
             outD <= "1111111";
          when "1001" => 
             outD <= "1111011";
          when others => 
             outD <= "0000000";
       end case;
    end process pcoderD;

  pcoderC: process(nibbC)
    begin
       case nibbC is
          when "0000" => 
             outC <= "1111110";
          when "0001" => 
             outC <= "0110000";
          when "0010" => 
             outC <= "1101101";
          when "0011" => 
             outC <= "1111001";
          when "0100" => 
             outC <= "0110011";
          when "0101" => 
             outC <= "1011011";
          when "0110" => 
             outC <= "1011111";
          when "0111" => 
             outC <= "1110000";
          when "1000" => 
             outC <= "1111111";
          when "1001" => 
             outC <= "1111011";
          when others => 
             outC <= "0000000";
       end case;
    end process pcoderC;
end coderNibbles0;
