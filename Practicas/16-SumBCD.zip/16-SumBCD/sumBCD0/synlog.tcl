run_tcl -fg sumBCD00_sumBCD0_synplify.tcl
