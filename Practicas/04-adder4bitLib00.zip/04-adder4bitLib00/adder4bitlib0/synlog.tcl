run_tcl -fg adder4bitlib00_adder4bitlib0_synplify.tcl
