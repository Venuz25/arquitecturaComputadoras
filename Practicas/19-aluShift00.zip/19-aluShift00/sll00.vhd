library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
library lattice;
use lattice.all;

entity sll00 is
	port(
		 clksl: in std_logic;
		 opcodesl: in std_logic_vector(7 downto 0);
		 inAsl: std_logic_vector(7 downto 0);
		 inFlagsl: in std_logic; --- enable exterior
		 outsl: out std_logic_vector(7 downto 0);
		 outFlagsl: out std_logic);
end sll00;

architecture sll0 of sll00 is
signal shamt: std_logic_vector(2 downto 0);
signal sopcode: std_logic_vector(4 downto 0);
signal scont: std_logic_vector(2 downto 0);
signal sshift: std_logic_vector(7 downto 0);
begin
	psll: process(clksl)
	variable aux0: bit:='0';
	begin
		if(clksl'event and clksl = '1') then
			if (sopcode = "10000") then
			sshift <= inAsl;
				if (inFlagsl = '1') then
					if (aux0 = '0') then
						aux0:='1';
							if(scont < shamt) then
								scont <= scont + '1';
								sshift(0) <= '0';
								sshift(7 downto 1) <= sshift(6 downto 0);
								outFlagsl <= '0';
							else
								outsl <= sshift;
								outFlagsl <= '1';
							end if;
					else 
						outFlagsl <= '0';
					end if;
				elsif (inFlagsl = '0') then
					outFlagsl <= '0';
				end if;
			else
				outsl <= (others => 'Z');
				outFlagsl <= 'Z';
				aux0:='0';
			end if;
		end if;
	end process psll;
end sll0;