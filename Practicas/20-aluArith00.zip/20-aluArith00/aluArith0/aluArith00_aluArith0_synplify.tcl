#-- Lattice Semiconductor Corporation Ltd.
#-- Synplify OEM project file

#device options
set_option -technology MACHXO2
set_option -part LCMXO2_7000HE
set_option -package TG144C
set_option -speed_grade -5

#compilation/mapping options
set_option -symbolic_fsm_compiler true
set_option -resource_sharing true

#use verilog 2001 standard option
set_option -vlog_std v2001

#map options
set_option -frequency 100
set_option -maxfan 1000
set_option -auto_constrain_io 0
set_option -disable_io_insertion false
set_option -retiming false; set_option -pipe true
set_option -force_gsr false
set_option -compiler_compatible 0
set_option -dup false

set_option -default_enum_encoding default

#simulation options


#timing analysis options



#automatic place and route (vendor) options
set_option -write_apr_constraint 1

#synplifyPro options
set_option -fix_gated_and_generated_clocks 1
set_option -update_models_cp 0
set_option -resolve_multiple_driver 0


set_option -seqshift_no_replicate 0

#-- add_file options
add_file -vhdl {C:/lscc/diamond/3.14/cae_library/synthesis/vhdl/machxo2.vhd}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-osc00-vhdl/div00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-osc00-vhdl/osc00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-osc00-vhdl/oscint00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-osc00-vhdl/packageosc00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/and00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/xor00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/packageha00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/ha00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/or00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/packagefa00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/fa00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/packageadder8bit00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/adder8bit00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/semiAdder8bit00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/shift8bit00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/and8bit00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/packagemult8bit00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/mult8bit00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/bufferAdder00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/bufferSubtract00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/bufferMult00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/sbeq00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/sblt00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/sbgt00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/acArith00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/pc00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/ram_EBR00.vhd}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/packagealuArith00.vhdl}
add_file -vhdl -lib "work" {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/aluArith00.vhdl}

#-- top module name
set_option -top_module aluArith00

#-- set result format/file last
project -result_file {C:/Users/gusta/OneDrive/Documentos/ESCOM/2025-2/Arqui/Tercer Parcial/Practicas/Aux-intentos/03-aluArith00/aluArith0/aluArith00_aluArith0.edi}

#-- error message log file
project -log_file {aluArith00_aluArith0.srf}

#-- set any command lines input by customer


#-- run Synplify with 'arrange HDL file'
project -run hdl_info_gen -fileorder
project -run
