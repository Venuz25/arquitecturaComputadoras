run_tcl -fg aluArith00_aluArith0_synplify.tcl
