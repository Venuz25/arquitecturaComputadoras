--
-- Synopsys
-- Vhdl wrapper for top level design, written on Thu Jun 26 08:57:08 2025
--
library ieee;
use ieee.std_logic_1164.all;
library work;
use work.packagealuarith00.all;

entity wrapper_for_aluArith00 is
   port (
      clk_A : in std_logic;
      cdiv_A : in std_logic_vector(5 downto 0);
      re_A : in std_logic;
      en_A : in std_logic;
      rw_A : in std_logic;
      address_A : in std_logic_vector(2 downto 0);
      inA_A : in std_logic_vector(7 downto 0);
      inB_A : in std_logic_vector(7 downto 0);
      outFlagL_A : in std_logic;
      outFlag_A : in std_logic;
      outCode_A : in std_logic_vector(7 downto 0);
      outOverflow_A : out std_logic;
      out_A : out std_logic_vector(15 downto 0)
   );
end wrapper_for_aluArith00;

architecture aluarith0 of wrapper_for_aluArith00 is

component aluArith00
 port (
   clk_A : inout std_logic;
   cdiv_A : in std_logic_vector (5 downto 0);
   re_A : in std_logic;
   en_A : in std_logic;
   rw_A : in std_logic;
   address_A : inout std_logic_vector (2 downto 0);
   inA_A : in std_logic_vector (7 downto 0);
   inB_A : in std_logic_vector (7 downto 0);
   outFlagL_A : inout std_logic;
   outFlag_A : inout std_logic;
   outCode_A : inout std_logic_vector (7 downto 0);
   outOverflow_A : out std_logic;
   out_A : out std_logic_vector (15 downto 0)
 );
end component;

signal tmp_clk_A : std_logic;
signal tmp_cdiv_A : std_logic_vector (5 downto 0);
signal tmp_re_A : std_logic;
signal tmp_en_A : std_logic;
signal tmp_rw_A : std_logic;
signal tmp_address_A : std_logic_vector (2 downto 0);
signal tmp_inA_A : std_logic_vector (7 downto 0);
signal tmp_inB_A : std_logic_vector (7 downto 0);
signal tmp_outFlagL_A : std_logic;
signal tmp_outFlag_A : std_logic;
signal tmp_outCode_A : std_logic_vector (7 downto 0);
signal tmp_outOverflow_A : std_logic;
signal tmp_out_A : std_logic_vector (15 downto 0);

begin

tmp_clk_A <= clk_A;

tmp_cdiv_A <= cdiv_A;

tmp_re_A <= re_A;

tmp_en_A <= en_A;

tmp_rw_A <= rw_A;

tmp_address_A <= address_A;

tmp_inA_A <= inA_A;

tmp_inB_A <= inB_A;

tmp_outFlagL_A <= outFlagL_A;

tmp_outFlag_A <= outFlag_A;

tmp_outCode_A <= outCode_A;

outOverflow_A <= tmp_outOverflow_A;

out_A <= tmp_out_A;



u1:   aluArith00 port map (
		clk_A => tmp_clk_A,
		cdiv_A => tmp_cdiv_A,
		re_A => tmp_re_A,
		en_A => tmp_en_A,
		rw_A => tmp_rw_A,
		address_A => tmp_address_A,
		inA_A => tmp_inA_A,
		inB_A => tmp_inB_A,
		outFlagL_A => tmp_outFlagL_A,
		outFlag_A => tmp_outFlag_A,
		outCode_A => tmp_outCode_A,
		outOverflow_A => tmp_outOverflow_A,
		out_A => tmp_out_A
       );
end aluarith0;
