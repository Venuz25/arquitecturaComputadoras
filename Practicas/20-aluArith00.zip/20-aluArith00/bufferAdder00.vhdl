library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
library lattice;
use lattice.all;

entity bufferAdder00 is
	port(
		clk_bfa: in std_logic;
		opcode_bfa: in std_logic_vector(7 downto 0);
		ina_bfa: in std_logic_vector(7 downto 0);
		inb_bfa: in std_logic_vector(7 downto 0);
		inFlag_bfa: in std_logic;
		inBitOverflow_bfa: in std_logic;
		inR_bfa: in std_logic_vector(7 downto 0);
		outSL_bfa: out std_logic;
		outA_bfa: out std_logic_vector(7 downto 0);
		outB_bfa: out std_logic_vector(7 downto 0);
		out_bfa: out std_logic_vector(15 downto 0);
		outBitOverflow_bfa: out std_logic;
		outFlag_bfa: out std_logic
	);
end bufferAdder00;

architecture bufferAdder0 of bufferAdder00 is
begin
	pbfaer00: process(clk_bfa)
		variable aux_bfa: bit := '0';
	begin
		if (clk_bfa'event and clk_bfa = '1') then
			if (opcode_bfa = "00001000") then
				if (inFlag_bfa = '1') then
					if(aux_bfa = '0') then
						aux_bfa := '1';
						outSL_bfa <= '0';
						outA_bfa <= ina_bfa;
						outB_bfa <= inb_bfa;
						outBitOverflow_bfa <= inBitOverflow_bfa;
						if (inR_bfa(7) = '1') then
							out_bfa <= ("00000000")& inR_bfa(7) & (not(inR_bfa(6 downto 0)) + 1);
						else
							out_bfa <= ("00000000") & inR_bfa;
						end if;
						outFlag_bfa <= '1';
					end if;
				elsif (inFlag_bfa = '0') then
					outFlag_bfa <= '0';
				end if;
			else
				outSL_bfa <= 'Z';
				outA_bfa <= (others => 'Z');
				outB_bfa <= (others => 'Z');
				out_bfa <= (others => 'Z');
				outBitOverflow_bfa <= 'Z';
				outFlag_bfa <= 'Z';
				aux_bfa := '0';
			end if;
		end if;
	end process pbfaer00;
end bufferAdder0;