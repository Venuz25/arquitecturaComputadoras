library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

use packageadder8bit00.all;

entity semiAdder8bit00 is
	port(
		A_semi: in std_logic_vector(7 downto 0);
		B_semi: in std_logic_vector(7 downto 0);
		Cin_semi: in std_logic;
		Cout_semi: out std_logic;
		R_semi: out std_logic_vector(7 downto 0)
	);
end semiAdder8bit00;

architecture semiAdder8bit0 of semiAdder8bit00 is
	signal Cint_semi: std_logic_vector(6 downto 0);
begin
	AS00: fa00 port map(
		A_fa => A_semi(0),
		B_fa => B_semi(0),
		Cin_fa => Cin_semi,
		Cout_fa => Cint_semi(0),
		R_fa => R_semi(0)
	);
	
	AS01: fa00 port map(
		A_fa => A_semi(1),
		B_fa => B_semi(1),
		Cin_fa => Cint_semi(0),
		Cout_fa => Cint_semi(1),
		R_fa => R_semi(1)
	);
	
	AS02: fa00 port map(
		A_fa => A_semi(2),
		B_fa => B_semi(2),
		Cin_fa => Cint_semi(1),
		Cout_fa => Cint_semi(2),
		R_fa => R_semi(2)
	);
	
	AS03: fa00 port map(
		A_fa => A_semi(3),
		B_fa => B_semi(3),
		Cin_fa => Cint_semi(2),
		Cout_fa => Cint_semi(3),
		R_fa => R_semi(3)
	);
	
	AS04: fa00 port map(
		A_fa => A_semi(4),
		B_fa => B_semi(4),
		Cin_fa => Cint_semi(3),
		Cout_fa => Cint_semi(4),
		R_fa => R_semi(4)
	);
	
	AS05: fa00 port map(
		A_fa => A_semi(5),
		B_fa => B_semi(5),
		Cin_fa => Cint_semi(4),
		Cout_fa => Cint_semi(5),
		R_fa => R_semi(5)
	);
	
	AS06: fa00 port map(
		A_fa => A_semi(6),
		B_fa => B_semi(6),
		Cin_fa => Cint_semi(5),
		Cout_fa => Cint_semi(6),
		R_fa => R_semi(6)
	);
	
	AS07: fa00 port map(
		A_fa => A_semi(7),
		B_fa => B_semi(7),
		Cin_fa => Cint_semi(6),
		Cout_fa => Cout_semi,
		R_fa => R_semi(7)
	);
	
end semiAdder8bit0;