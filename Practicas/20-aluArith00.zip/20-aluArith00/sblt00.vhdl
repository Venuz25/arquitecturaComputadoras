library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity sblt00 is
	port(
		clk_sblt: in std_logic;
		inFlag_sblt: in std_logic;
		opCode_sblt: in std_logic_vector(7 downto 0);
		inA_sblt: in std_logic_vector(7 downto 0);
		inB_sblt: in std_logic_vector(7 downto 0);
		outR_sblt: out std_logic_vector(15 downto 0);
		outFlag_sblt: out std_logic
	);
end sblt00;

architecture sblt0 of sblt00 is
begin
	pSblt: process(clk_sblt, inFlag_sblt, opCode_sblt)
		variable aux_sblt: bit := '0';
	begin
		if (clk_sblt'event and clk_sblt = '1') then
			if (opCode_sblt = "00001100") then
				if (inFlag_sblt = '1') then
					if (aux_sblt = '0' ) then
						aux_sblt := '1';
						if(inA_sblt < inB_sblt) then
							outR_sblt <= (others => '1');
						else
							outR_sblt <= (others => '0');
						end if;
						outFlag_sblt <= '1';
					else
						outFlag_sblt <= '0';
					end if;
				elsif (inFlag_sblt = '0') then
					outFlag_sblt <= '0';
				end if;
			else
				outR_sblt <= (others => 'Z');
				outFlag_sblt <= 'Z';
				aux_sblt := '0';
			end if;
		end if;
	end process pSblt;
end sblt0;