library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

use packagealuArith00.all;

entity aluArith00 is
	port(
		clk_A: inout std_logic;
		cdiv_A: in std_logic_vector(5 downto 0);
		re_A: in std_logic;
		en_A: in std_logic;
		rw_A: in std_logic;
		address_A: inout std_logic_vector(2 downto 0);
		inA_A: in std_logic_vector(7 downto 0);
		inB_A: in std_logic_vector(7 downto 0);
		outFlagL_A: inout std_logic; -- Sale del acumulador
		outFlag_A: inout std_logic;
		outCode_A: inout std_logic_vector(7 downto 0); -- Salida de la ram
		outOverflow_A: out std_logic;
		out_A: out std_logic_vector(15 downto 0) -- Datos de resultados
	);
end aluArith00;

architecture aluArith0 of aluArith00 is
	signal srS_A: std_logic_vector(7 downto 0);
	signal srM_A: std_logic_vector(15 downto 0);
	signal srC_A: std_logic;
	signal srO_A: std_logic;
	
	signal srd: std_logic_vector(15 downto 0);
	
	signal sdata_A: std_logic_vector(7 downto 0);
	
	-- Se�ales para el adder y substractor
	signal sA: std_logic_vector(7 downto 0);
	signal sB: std_logic_vector(7 downto 0);
	signal sR: std_logic_vector(7 downto 0);
	signal sSL: std_logic;
	signal sOverflow: std_logic;
	
	-- Se�ales para el restador
	signal sA_s: std_logic_vector(7 downto 0);
	signal sB_s: std_logic_vector(7 downto 0);
	signal sR_s: std_logic_vector(7 downto 0);
	signal sSL_s: std_logic;
	signal sOverflow_s: std_logic;
	
	
	-- Se�aler para el mult
	signal sAmult: std_logic_vector(7 downto 0);
	signal sBmult: std_logic_vector(7 downto 0);
	signal sRmult: std_logic_vector(15 downto 0);
begin
	sdata_A <= (others => '0');
	
	
	PAA00: osc00 port map(
		cdiv => cdiv_A,
		oscout0 => clk_A
	);
	
	PAA02: adder8bit00 port map(
		A_add => sA,
		B_add => sB,
		SL_add => sSL,
		R_add => sR,
		OverFlow_add => sOverflow
	);
	
	PAA01: bufferAdder00 port map(
		clk_bfa => clk_A,
		opcode_bfa => outCode_A,
		ina_bfa => inA_A,
		inb_bfa => inB_A,
		inFlag_bfa => en_A,
		inBitOverflow_bfa => sOverflow,
		inR_bfa  => sR,
		outSL_bfa => sSL,
		outA_bfa => sA,
		outB_bfa => sB,
		out_bfa => srd,
		outBitOverflow_bfa => srO_A,
		outFlag_bfa => outFlag_A
	);
	
	PAA03: bufferSubtract00 port map(
		clk_bfs => clk_A,
		opcode_bfs => outCode_A,
		ina_bfs => inA_A,
		inb_bfs => inB_A,
		inFlag_bfs => en_A,
		inBitOverflow_bfs => sOverflow_s,
		inR_bfs  => sR_s,
		outSL_bfs => sSL_s,
		outA_bfs => sA_s,
		outB_bfs => sB_s,
		out_bfs => srd,
		outBitOverflow_bfs => srO_A,
		outFlag_bfs => outFlag_A
	);
	
	PAA04: adder8bit00 port map(
		A_add => sA_s,
		B_add => sB_s,
		SL_add => sSL_s,
		R_add => sR_s,
		OverFlow_add => sOverflow_s
	);
	
	PAA05: bufferMult00 port map(
		clk_bfm => clk_A,
		opcode_bfm => outCode_A,
		ina_bfm => inA_A,
		inb_bfm => inB_A,
		inFlag_bfm => en_A,
		inR_bfm => sRmult,
		outA_bfm => sAmult,
		outB_bfm => sBmult,
		out_bfm => srd,
		outFlag_bfm => outFlag_A
	);
	
	PAA06: mult8bit00 port map(
		A_mult => sAmult,
		B_mult => sBmult,
		R_mult => sRmult
	);
	
	PAA07: sbeq00 port map(
		clk_sbeq => clk_A,
		inFlag_sbeq => en_A,
		opCode_sbeq => outCode_A,
		inA_sbeq => inA_A,
		inB_sbeq => inB_A,
		outR_sbeq => srd,
		outFlag_sbeq => outFlag_A
	);
	
	PAA08: sblt00 port map(
		clk_sblt => clk_A,
		inFlag_sblt => en_A,
		opCode_sblt => outCode_A,
		inA_sblt => inA_A,
		inB_sblt => inB_A,
		outR_sblt => srd,
		outFlag_sblt => outFlag_A
	);
	
	PAA09: sbgt00 port map(
		clk_sbgt => clk_A,
		inFlag_sbgt => en_A,
		opCode_sbgt => outCode_A,
		inA_sbgt => inA_A,
		inB_sbgt => inB_A,
		outR_sbgt => srd,
		outFlag_sbgt => outFlag_A
	);
	
	PAA10: acArith00 port map(
		clk_aca => clk_A,
		inFlag_aca => outFlag_A,
		opcode_aca => outCode_A,
		en_aca => en_A,
		inData_aca => srd,
		inOverflow_aca => srO_A,
		outFlag_aca => outFlagL_A,
		outOverflow_Aca => outOverflow_A,
		outData_aca => out_A
	);
	
	PAA11: pc00 port map(
		clk_pc => clk_A,
		re_pc => re_A,
		en_pc => en_A,
		rw_pc => rw_A,
		inFlag_pc => outFlagL_A,
		out_pc => address_A
	);
	
	PAA12: ram_EBR00 port map(
		Clock => clk_A,
		ClockEn => en_A,
		Reset => re_A,
		WE => rw_A,
		Address => address_A,
		Data => sdata_A,
		Q => outCode_A
	);
end aluArith0;