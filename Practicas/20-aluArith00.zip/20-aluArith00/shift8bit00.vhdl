library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity shift8bit00 is
	port(
		A_shift: in std_logic_vector(7 downto 0);
		C_shift: in std_logic;
		R_shift: out std_logic_vector(7 downto 0)
	);
end shift8bit00;

architecture shift8bit0 of shift8bit00 is
begin
	R_shift(0) <= A_shift(1);
	R_shift(1) <= A_shift(2);
	R_shift(2) <= A_shift(3);
	R_shift(3) <= A_shift(4);
	R_shift(4) <= A_shift(5);
	R_shift(5) <= A_shift(6);
	R_shift(6) <= A_shift(7);
	R_shift(7) <= C_shift;
end shift8bit0;