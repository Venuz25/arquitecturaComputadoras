library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
library lattice;
use lattice.all;

entity bufferSubtract00 is
	port(
		clk_bfs: in std_logic;
		opcode_bfs: in std_logic_vector(7 downto 0);
		ina_bfs: in std_logic_vector(7 downto 0);
		inb_bfs: in std_logic_vector(7 downto 0);
		inFlag_bfs: in std_logic;
		inBitOverflow_bfs: in std_logic;
		inR_bfs: in std_logic_vector(7 downto 0);
		outSL_bfs: out std_logic;
		outA_bfs: out std_logic_vector(7 downto 0);
		outB_bfs: out std_logic_vector(7 downto 0);
		out_bfs: out std_logic_vector(15 downto 0);
		outBitOverflow_bfs: out std_logic;
		outFlag_bfs: out std_logic
	);
end bufferSubtract00;

architecture bufferSubtract0 of bufferSubtract00 is
	signal auxR_bfs: std_logic_vector(7 downto 0);
begin
	pbfser00: process(clk_bfs)
		variable aux_bfs: bit := '0';
	begin
		if (clk_bfs'event and clk_bfs = '1') then
			if (opcode_bfs = "00001001") then
				if (inFlag_bfs = '1') then
					if(aux_bfs = '0') then
						aux_bfs := '1';
						outSL_bfs <= '1';
						outA_bfs <= ina_bfs;
						outB_bfs <= inb_bfs;
						outBitOverflow_bfs <= inBitOverflow_bfs;
						if (inR_bfs(7) = '1') then
							out_bfs <= ("00000000")& inR_bfs(7) & (not(inR_bfs(6 downto 0)) + 1);
						else
							out_bfs <= ("00000000") & inR_bfs;
						end if;
						outFlag_bfs <= '1';
					end if;
				elsif (inFlag_bfs = '0') then
					outFlag_bfs <= '0';
				end if;
			else
				outSL_bfs <= 'Z';
				outA_bfs <= (others => 'Z');
				outB_bfs <= (others => 'Z');
				out_bfs <= (others => 'Z');
				outBitOverflow_bfs <= 'Z';
				outFlag_bfs <= 'Z';
				aux_bfs := '0';
			end if;
		end if;
	end process pbfser00;
end bufferSubtract0;