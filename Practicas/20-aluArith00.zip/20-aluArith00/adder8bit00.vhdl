library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

use packageadder8bit00.all;

entity adder8bit00 is
	port(
		A_add: in std_logic_vector(7 downto 0);
		B_add: in std_logic_vector(7 downto 0);
		SL_add: in std_logic;
		R_add: out std_logic_vector(7 downto 0);
		OverFlow_add: out std_logic
	);
end adder8bit00;

architecture adder8bit0 of adder8bit00 is
	signal SA_add: std_logic_vector(7 downto 0);
	signal SB_add: std_logic_vector(7 downto 0);
	signal SC_add: std_logic_vector(7 downto 0);
	signal Sx_add: std_logic;
begin
	-- XORs dfe la arquitectura interna
	SB_add(0) <= SL_add xor B_add(0);
	SB_add(1) <= SL_add xor B_add(1);
	SB_add(2) <= SL_add xor B_add(2);
	SB_add(3) <= SL_add xor B_add(3);
	SB_add(4) <= SL_add xor B_add(4);
	SB_add(5) <= SL_add xor B_add(5);
	SB_add(6) <= SL_add xor B_add(6);
	SB_add(7) <= SL_add xor B_add(7);
	
	-- Full adders de la arquitectura interna
	A00: fa00 port map(
		A_fa => A_add(0),
		B_fa => SB_add(0),
		Cin_fa => SL_add,
		Cout_fa => SC_add(0),
		R_fa => SA_add(0)
	);
	
	A01: fa00 port map(
		A_fa => A_add(1),
		B_fa => SB_add(1),
		Cin_fa => SC_add(0),
		Cout_fa => SC_add(1),
		R_fa => SA_add(1)
	);
	
	A02: fa00 port map(
		A_fa => A_add(2),
		B_fa => SB_add(2),
		Cin_fa => SC_add(1),
		Cout_fa => SC_add(2),
		R_fa => SA_add(2)
	);
	
	A03: fa00 port map(
		A_fa => A_add(3),
		B_fa => SB_add(3),
		Cin_fa => SC_add(2),
		Cout_fa => SC_add(3),
		R_fa => SA_add(3)
	);
	
	A04: fa00 port map(
		A_fa => A_add(4),
		B_fa => SB_add(4),
		Cin_fa => SC_add(3),
		Cout_fa => SC_add(4),
		R_fa => SA_add(4)
	);
	
	A05: fa00 port map(
		A_fa => A_add(5),
		B_fa => SB_add(5),
		Cin_fa => SC_add(4),
		Cout_fa => SC_add(5),
		R_fa => SA_add(5)
	);
	
	A06: fa00 port map(
		A_fa => A_add(6),
		B_fa => SB_add(6),
		Cin_fa => SC_add(5),
		Cout_fa => SC_add(6),
		R_fa => SA_add(6)
	);
	
	A07: fa00 port map(
		A_fa => A_add(7),
		B_fa => SB_add(7),
		Cin_fa => SC_add(6),
		Cout_fa => SC_add(7),
		R_fa => SA_add(7)
	);
	
	-- Ands de la arquitectura
	R_add(0) <= Sx_add and SA_add(0);
	R_add(1) <= Sx_add and SA_add(1);
	R_add(2) <= Sx_add and SA_add(2);
	R_add(3) <= Sx_add and SA_add(3);
	R_add(4) <= Sx_add and SA_add(4);
	R_add(5) <= Sx_add and SA_add(5);
	R_add(6) <= Sx_add and SA_add(6);
	R_add(7) <= Sx_add and SA_add(7);
	
	-- Xnor y xor de comprobacion
	Sx_add <= SC_add(7) xnor SC_add(6);
	OverFlow_add <= SC_add(7) xor SC_add(6);
	
end adder8bit0;