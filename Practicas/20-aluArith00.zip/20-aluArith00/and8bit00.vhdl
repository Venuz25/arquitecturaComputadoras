library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity and8bit00 is
	port(
		A_mand: in std_logic_vector(7 downto 0);
		B_mand: in std_logic;
		R_mand: out std_logic_vector(7 downto 0)
	);
end and8bit00;

architecture and8bit0 of and8bit00 is
begin
	R_mand(0) <= A_mand(0) and B_mand;
	R_mand(1) <= A_mand(1) and B_mand;
	R_mand(2) <= A_mand(2) and B_mand;
	R_mand(3) <= A_mand(3) and B_mand;
	R_mand(4) <= A_mand(4) and B_mand;
	R_mand(5) <= A_mand(5) and B_mand;
	R_mand(6) <= A_mand(6) and B_mand;
	R_mand(7) <= A_mand(7) and B_mand;
end and8bit0;