library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity sbeq00 is
	port(
		clk_sbeq: in std_logic;
		inFlag_sbeq: in std_logic;
		opCode_sbeq: in std_logic_vector(7 downto 0);
		inA_sbeq: in std_logic_vector(7 downto 0);
		inB_sbeq: in std_logic_vector(7 downto 0);
		outR_sbeq: out std_logic_vector(15 downto 0);
		outFlag_sbeq: out std_logic
	);
end sbeq00;

architecture sbeq0 of sbeq00 is
begin
	pSbeq: process(clk_sbeq, inFlag_sbeq, opCode_sbeq)
		variable aux_sbeq: bit := '0';
	begin
		if (clk_sbeq'event and clk_sbeq = '1') then
			if (opCode_sbeq = "00001011") then
				if (inFlag_sbeq = '1') then
					if (aux_sbeq = '0' ) then
						aux_sbeq := '1';
						if(inA_sbeq = inB_sbeq) then
							outR_sbeq <= (others => '1');
						else
							outR_sbeq <= (others => '0');
						end if;
						outFlag_sbeq <= '1';
					else
						outFlag_sbeq <= '0';
					end if;
				elsif (inFlag_sbeq = '0') then
					outFlag_sbeq <= '0';
				end if;
			else
				outR_sbeq <= (others => 'Z');
				outFlag_sbeq <= 'Z';
				aux_sbeq := '0';
			end if;
		end if;
	end process pSbeq;
end sbeq0;