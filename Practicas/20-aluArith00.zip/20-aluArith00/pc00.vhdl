library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
library lattice;
use lattice.all;

entity pc00 is
	port(
		clk_pc: in std_logic;
		re_pc: in std_logic;
		en_pc: in std_logic;
		rw_pc: in std_logic;
		inFlag_pc: in std_logic;
		out_pc: inout std_logic_vector(2 downto 0)
	);
end pc00;

architecture pc0 of pc00 is
	signal scontrol_pc: std_logic_vector(3 downto 0);
begin
	scontrol_pc <= (inFlag_pc) &(re_pc) & (en_pc) & (rw_pc);
	ppc: process(clk_pc, en_pc, rw_pc)
		variable aux0_pc: bit := '0'; 
	begin
		if (clk_pc'event and  clk_pc = '1') then
			case scontrol_pc is
				when "0000" =>
					out_pc <= "000";
					aux0_pc := '0';
				------------------------------------------
				when "1010" =>
					if (out_pc <= "111") then
						if (aux0_pc = '0') then
							out_pc <= out_pc;
							aux0_pc := '1';
						else
							out_pc <= out_pc + '1';
							aux0_pc := '1';
						end if;
					end if;
				------------------------------------------
				when "1011" =>
					out_pc <= out_pc;
					aux0_pc := '0';
				------------------------------------------
				when "0111" =>
					out_pc <= "000";
					aux0_pc := '0';
				------------------------------------------
				when "1110" =>
					out_pc <= "000";
					aux0_pc := '0';
				------------------------------------------
				when others => null;
			end case;
		end if;
	end process ppc;
end pc0;