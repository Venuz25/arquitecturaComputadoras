library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

package packagealuArith00 is
	component osc00
		port(
			cdiv: in std_logic_vector(5 downto 0);
			oscout0: inout std_logic
		);
	end component;
	
	component adder8bit00
		port(
			A_add: in std_logic_vector(7 downto 0);
			B_add: in std_logic_vector(7 downto 0);
			SL_add: in std_logic;
			R_add: out std_logic_vector(7 downto 0);
			OverFlow_add: out std_logic
		);
	end component;
	
	component mult8bit00
		port(
			A_mult: in std_logic_vector(7 downto 0);
			B_mult: in std_logic_vector(7 downto 0);
			R_mult: out std_logic_vector(15 downto 0)
		);
	end component;
	
	component bufferAdder00
		port(
			clk_bfa: in std_logic;
			opcode_bfa: in std_logic_vector(7 downto 0);
			ina_bfa: in std_logic_vector(7 downto 0);
			inb_bfa: in std_logic_vector(7 downto 0);
			inFlag_bfa: in std_logic;
			inBitOverflow_bfa: in std_logic;
			inR_bfa: in std_logic_vector(7 downto 0);
			outSL_bfa: out std_logic;
			outA_bfa: out std_logic_vector(7 downto 0);
			outB_bfa: out std_logic_vector(7 downto 0);
			out_bfa: out std_logic_vector(15 downto 0);
			outBitOverflow_bfa: out std_logic;
			outFlag_bfa: out std_logic
		);
	end component;
	
	component bufferSubtract00
		port(
			clk_bfs: in std_logic;
			opcode_bfs: in std_logic_vector(7 downto 0);
			ina_bfs: in std_logic_vector(7 downto 0);
			inb_bfs: in std_logic_vector(7 downto 0);
			inFlag_bfs: in std_logic;
			inBitOverflow_bfs: in std_logic;
			inR_bfs: in std_logic_vector(7 downto 0);
			outSL_bfs: out std_logic;
			outA_bfs: out std_logic_vector(7 downto 0);
			outB_bfs: out std_logic_vector(7 downto 0);
			out_bfs: out std_logic_vector(15 downto 0);
			outBitOverflow_bfs: out std_logic;
			outFlag_bfs: out std_logic
		);
	end component;
	
	component bufferMult00
		port(
			clk_bfm: in std_logic;
			opcode_bfm: in std_logic_vector(7 downto 0);
			ina_bfm: in std_logic_vector(7 downto 0);
			inb_bfm: in std_logic_vector(7 downto 0);
			inFlag_bfm: in std_logic;
			inR_bfm: in std_logic_vector(15 downto 0);
			outA_bfm: out std_logic_vector(7 downto 0);
			outB_bfm: out std_logic_vector(7 downto 0);
			out_bfm: out std_logic_vector(15 downto 0);
			outFlag_bfm: out std_logic
		);
	end component;
	
	component sbeq00
		port(
			clk_sbeq: in std_logic;
			inFlag_sbeq: in std_logic;
			opCode_sbeq: in std_logic_vector(7 downto 0);
			inA_sbeq: in std_logic_vector(7 downto 0);
			inB_sbeq: in std_logic_vector(7 downto 0);
			outR_sbeq: out std_logic_vector(15 downto 0);
			outFlag_sbeq: out std_logic
		);
	end component;
	
	component sblt00
		port(
			clk_sblt: in std_logic;
			inFlag_sblt: in std_logic;
			opCode_sblt: in std_logic_vector(7 downto 0);
			inA_sblt: in std_logic_vector(7 downto 0);
			inB_sblt: in std_logic_vector(7 downto 0);
			outR_sblt: out std_logic_vector(15 downto 0);
			outFlag_sblt: out std_logic
		);
	end component;
	
	component sbgt00
		port(
			clk_sbgt: in std_logic;
			inFlag_sbgt: in std_logic;
			opCode_sbgt: in std_logic_vector(7 downto 0);
			inA_sbgt: in std_logic_vector(7 downto 0);
			inB_sbgt: in std_logic_vector(7 downto 0);
			outR_sbgt: out std_logic_vector(15 downto 0);
			outFlag_sbgt: out std_logic
		);
	end component;
	
	component acArith00
		port(
			clk_aca: in std_logic;
			inFlag_aca: in std_logic;
			opcode_aca: in std_logic_vector(7 downto 0);
			en_aca: in std_logic;
			inData_aca: in std_logic_vector(15 downto 0);
			inOverflow_aca: in std_logic;
			outFlag_aca: out std_logic;
			outOverflow_aca: out std_logic;
			outData_aca: out std_logic_vector(15 downto 0)
		);
	end component;
	
	component pc00
		port(
			clk_pc: in std_logic;
			re_pc: in std_logic;
			en_pc: in std_logic;
			rw_pc: in std_logic;
			inFlag_pc: in std_logic;
			out_pc: inout std_logic_vector(2 downto 0)
		);
	end component;
	
	component ram_EBR00
		port(
			Clock: in std_logic;
			ClockEn: in std_logic;
			Reset: in std_logic;
			WE: in std_logic;
			Address: in std_logic_vector(2 downto 0);
			Data: in std_logic_vector(7 downto 0);
			Q: out std_logic_vector(7 downto 0)
		);
	end component;
end packagealuArith00;