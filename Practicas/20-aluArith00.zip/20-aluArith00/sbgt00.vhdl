library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity sbgt00 is
	port(
		clk_sbgt: in std_logic;
		inFlag_sbgt: in std_logic;
		opCode_sbgt: in std_logic_vector(7 downto 0);
		inA_sbgt: in std_logic_vector(7 downto 0);
		inB_sbgt: in std_logic_vector(7 downto 0);
		outR_sbgt: out std_logic_vector(15 downto 0);
		outFlag_sbgt: out std_logic
	);
end sbgt00;

architecture sbgt0 of sbgt00 is
begin
	pSbgt: process(clk_sbgt, inFlag_sbgt, opCode_sbgt)
		variable aux_sbgt: bit := '0';
	begin
		if (clk_sbgt'event and clk_sbgt = '1') then
			if (opCode_sbgt = "00001101") then
				if (inFlag_sbgt = '1') then
					if (aux_sbgt = '0' ) then
						aux_sbgt := '1';
						if(inA_sbgt > inB_sbgt) then
							outR_sbgt <= (others => '1');
						else
							outR_sbgt <= (others => '0');
						end if;
						outFlag_sbgt <= '1';
					else
						outFlag_sbgt <= '0';
					end if;
				elsif (inFlag_sbgt = '0') then
					outFlag_sbgt <= '0';
				end if;
			else
				outR_sbgt <= (others => 'Z');
				outFlag_sbgt <= 'Z';
				aux_sbgt := '0';
			end if;
		end if;
	end process pSbgt;
end sbgt0;