library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity bufferMult00 is
	port(
		clk_bfm: in std_logic;
		opcode_bfm: in std_logic_vector(7 downto 0);
		ina_bfm: in std_logic_vector(7 downto 0);
		inb_bfm: in std_logic_vector(7 downto 0);
		inFlag_bfm: in std_logic;
		inR_bfm: in std_logic_vector(15 downto 0);
		outA_bfm: out std_logic_vector(7 downto 0);
		outB_bfm: out std_logic_vector(7 downto 0);
		out_bfm: out std_logic_vector(15 downto 0);
		outFlag_bfm: out std_logic
	);
end bufferMult00;

architecture bufferMult0 of bufferMult00 is
begin
	pbfmer00: process(clk_bfm)
		variable aux_bfm: bit := '0';
	begin
		if (clk_bfm'event and clk_bfm = '1') then
			if (opcode_bfm = "00001010") then
				if (inFlag_bfm = '1') then
					if(aux_bfm = '0')then
						aux_bfm := '1';
						outA_bfm <= ina_bfm;
						outB_bfm <= inb_bfm;
						out_bfm <= inR_bfm;
						outFlag_bfm <= '1';
					else
						outFlag_bfm <= '0';
					end if;
				elsif (inFlag_bfm = '0') then
					outFlag_bfm <= '0';
				end if;
			else
				outA_bfm <= (others => 'Z');
				outB_bfm <= (others => 'Z');
				out_bfm <= (others => 'Z');
				outFlag_bfm <= 'Z';
				aux_bfm := '0';
			end if;
		end if;
	end process pbfmer00;
end bufferMult0;