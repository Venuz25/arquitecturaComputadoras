library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

package packagemult8bit00 is
	component semiAdder8bit00
		port(
			A_semi: in std_logic_vector(7 downto 0);
			B_semi: in std_logic_vector(7 downto 0);
			Cin_semi: in std_logic;
			Cout_semi: out std_logic;
			R_semi: out std_logic_vector(7 downto 0)
		);
	end component;
	
	component shift8bit00
		port(
			A_shift: in std_logic_vector(7 downto 0);
			C_shift: in std_logic;
			R_shift: out std_logic_vector(7 downto 0)
		);
	end component;
	
	component and8bit00
		port(
			A_mand: in std_logic_vector(7 downto 0);
			B_mand: in std_logic;
			R_mand: out std_logic_vector(7 downto 0)
		);
	end component;
end packagemult8bit00;