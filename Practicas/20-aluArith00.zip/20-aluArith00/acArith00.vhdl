library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity acArith00 is
	port(
		clk_aca: in std_logic;
		inFlag_aca: in std_logic;
		opcode_aca: in std_logic_vector(7 downto 0);
		en_aca: in std_logic;
		inData_aca: in std_logic_vector(15 downto 0);
		inOverflow_aca: in std_logic;
		outFlag_aca: out std_logic;
		outOverflow_aca: out std_logic;
		outData_aca: out std_logic_vector(15 downto 0)
	);
end acArith00;

architecture acArith0 of acArith00 is
	signal scontrol_aca: std_logic_vector(1 downto 0);
begin
	scontrol_aca <= (en_aca) & (inFlag_aca);
	pacarith: process (clk_aca, opcode_aca, scontrol_aca)
		variable aux_aca: bit := '0';
	begin
		if ( clk_aca'event and clk_aca = '1' ) then
			case scontrol_aca is
				when "00" =>
					outData_aca <= (others => '0');
					outFlag_aca <= '0';
					aux_aca := '0';
				when "01" =>
					outData_aca <= (others => '0');
					outFlag_aca <= '0';
					aux_aca := '0';
				when "10" => 
					if ( aux_aca = '0' ) then
						outFlag_aca <= '1';
						aux_aca := '1';
					end if;
				when "11" =>
					if ( aux_aca = '1' ) then
						outData_aca <= inData_aca;
						outFlag_aca <= '1';
						aux_aca := '1';
					end if;
				when others => null;
			end case;
		end if;
	end process pacarith;
end acArith0;