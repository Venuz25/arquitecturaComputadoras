library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

use packagemult8bit00.all;

entity mult8bit00 is
	port(
		A_mult: in std_logic_vector(7 downto 0);
		B_mult: in std_logic_vector(7 downto 0);
		R_mult: out std_logic_vector(15 downto 0)
	);
end mult8bit00;

architecture mult8bit0 of mult8bit00 is
	signal IntAnd0, IntAnd1, IntAnd2, IntAnd3, IntAnd4, IntAnd5, IntAnd6, IntAnd7 : std_logic_vector(7 downto 0);
	signal IntSum0,IntSum1, IntSum2, IntSum3, IntSum4, IntSum5, IntSum6, IntSum7 : std_logic_vector(7 downto 0);
	signal IntC: std_logic_vector(7 downto 0);
	signal IntGC1, IntGC2, IntGC3, IntGC4, IntGC5, IntGC6, IntGC7: std_logic_vector(7 downto 0);
begin
	-- ############################################################### Primer linea del multiplicador ################################################################
	-- Parte de ANDs
	R_mult(0) <= A_mult(0) and B_mult(0);
	IntSum0(0) <= A_mult(1) and B_mult(0);
	IntSum0(1) <= A_mult(2) and B_mult(0);
	IntSum0(2) <= A_mult(3) and B_mult(0);
	IntSum0(3) <= A_mult(4) and B_mult(0);
	IntSum0(4) <= A_mult(5) and B_mult(0);
	IntSum0(5) <= A_mult(6) and B_mult(0);
	IntSum0(6) <= A_mult(7) and B_mult(0);
	IntSum0(7) <= '0';

	
	-- ############################################################### Segunda linea del multiplicador ###############################################################
	
	M8100: and8bit00 port map(
		A_mand => A_mult,
		B_mand => B_mult(1),
		R_mand => IntAnd1
	);
	
	M8101: SemiAdder8bit00 port map(
		A_semi => IntSum0,
		B_semi => IntAnd1,
		Cin_semi => '0',
		Cout_semi => IntC(0),
		R_semi => IntSum1
	);
	
	R_mult(1) <= IntSum1(0);
	
	M8102: shift8bit00 port map(
		A_shift => IntSum1,
		C_shift => IntC(0),
		R_shift => IntGC1
	);
	

	-- ############################################################### Tercer linea del multiplicador ################################################################
	
	M8200: and8bit00 port map(
		A_mand => A_mult,
		B_mand => B_mult(2),
		R_mand => IntAnd2
	);
	
	M8201: SemiAdder8bit00 port map(
		A_semi => IntGC1,
		B_semi => IntAnd2,
		Cin_semi => '0',
		Cout_semi => IntC(1),
		R_semi => IntSum2
	);
	
	R_mult(2) <= IntSum2(0);
	
	M8202: shift8bit00 port map(
		A_shift => IntSum2,
		C_shift => IntC(1),
		R_shift => IntGC2
	);
	
	-- ############################################################### Cuarta linea del multiplicador ################################################################
		
	M8300: and8bit00 port map(
		A_mand => A_mult,
		B_mand => B_mult(3),
		R_mand => IntAnd3
	);
	
	M8301: SemiAdder8bit00 port map(
		A_semi => IntGC2,
		B_semi => IntAnd3,
		Cin_semi => '0',
		Cout_semi => IntC(2),
		R_semi => IntSum3
	);
	
	R_mult(3) <= IntSum3(0);
	
	M8302: shift8bit00 port map(
		A_shift => IntSum3,
		C_shift => IntC(2),
		R_shift => IntGC3
	);

	
	-- ############################################################### Quinta linea del multiplicador ################################################################
	
	M8400: and8bit00 port map(
		A_mand => A_mult,
		B_mand => B_mult(4),
		R_mand => IntAnd4
	);
	
	M8401: SemiAdder8bit00 port map(
		A_semi => IntGC3,
		B_semi => IntAnd4,
		Cin_semi => '0',
		Cout_semi => IntC(3),
		R_semi => IntSum4
	);
	
	R_mult(4) <= IntSum4(0);
	
	M8402: shift8bit00 port map(
		A_shift => IntSum4,
		C_shift => IntC(3),
		R_shift => IntGC4
	);
	
	-- ############################################################### Sexta linea del multiplicador #################################################################
	
	M8500: and8bit00 port map(
		A_mand => A_mult,
		B_mand => B_mult(5),
		R_mand => IntAnd5
	);
	
	M8501: SemiAdder8bit00 port map(
		A_semi => IntGC4,
		B_semi => IntAnd5,
		Cin_semi => '0',
		Cout_semi => IntC(4),
		R_semi => IntSum5
	);
	
	R_mult(5) <= IntSum5(0);
	
	M8502: shift8bit00 port map(
		A_shift => IntSum5,
		C_shift => IntC(4),
		R_shift => IntGC5
	);
	
	-- ############################################################### Septima linea del multiplicador ###############################################################
	M8600: and8bit00 port map(
		A_mand => A_mult,
		B_mand => B_mult(6),
		R_mand => IntAnd6
	);
	
	M8601: SemiAdder8bit00 port map(
		A_semi => IntGC5,
		B_semi => IntAnd6,
		Cin_semi => '0',
		Cout_semi => IntC(5),
		R_semi => IntSum6
	);
	
	R_mult(6) <= IntSum6(0);
	
	M8602: shift8bit00 port map(
		A_shift => IntSum6,
		C_shift => IntC(5),
		R_shift => IntGC6
	);

	
	-- ############################################################### Octava linea del multiplicador ################################################################
	
	M8700: and8bit00 port map(
		A_mand => A_mult,
		B_mand => B_mult(7),
		R_mand => IntAnd7
	);
	
	M8701: SemiAdder8bit00 port map(
		A_semi => IntGC6,
		B_semi => IntAnd7,
		Cin_semi => '0',
		Cout_semi => IntC(6),
		R_semi => IntSum7
	);
	
	R_mult(7) <= IntSum7(0);
	
	M8702: shift8bit00 port map(
		A_shift => IntSum7,
		C_shift => IntC(6),
		R_shift => IntGC7
	);

	R_mult(8) <= IntGC7(0);
	R_mult(9) <= IntGC7(1);
	R_mult(10) <= IntGC7(2);
	R_mult(11) <= IntGC7(3);
	R_mult(12) <= IntGC7(4);
	R_mult(13) <= IntGC7(5);
	R_mult(14) <= IntGC7(6);
	R_mult(15) <= IntGC7(7);
	
	
end mult8bit0;