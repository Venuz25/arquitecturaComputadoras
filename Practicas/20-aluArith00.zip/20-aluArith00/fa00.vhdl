library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

use packagefa00.all;

entity fa00 is
	port(
		A_fa: in std_logic;
		B_fa: in std_logic;
		Cin_fa: in std_logic;
		Cout_fa: out std_logic;
		R_fa: out std_logic
	);
end fa00;

architecture fa0 of fa00 is
	signal sRint1_fa: std_logic;
	signal sCint1_fa: std_logic;
	signal sCint2_fa: std_logic;
begin
	FA00: ha00 port map(
		A_ha => A_fa,
		B_ha => B_fa,
		R_ha => sRint1_fa,
		C_ha => sCint1_fa
	);
	
	FA01: ha00 port map(
		A_ha => Cin_fa,
		B_ha => sRint1_fa,
		R_ha => R_fa,
		C_ha => sCint2_fa
	);
	
	FA02: or00 port map(
		A_or => sCint2_fa,
		B_or => sCint1_fa,
		R_or => Cout_fa
	);
	
end fa0;