library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

package packageadder8bit00 is
	component fa00
		port(
			A_fa: in std_logic;
			B_fa: in std_logic;
			Cin_fa: in std_logic;
			Cout_fa: out std_logic;
			R_fa: out std_logic
		);
	end component;
end packageadder8bit00;