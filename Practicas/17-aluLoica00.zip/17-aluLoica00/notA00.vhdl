library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity notA00 is
	port(
		 clknota: in std_logic;
		 opcodenota: in std_logic_vector(7 downto 0);
		 inAnota, inBnota: std_logic_vector(7 downto 0);
		 inFlagnota: in std_logic;
		 outnota: out std_logic_vector(7 downto 0);
		 outFlagnota: out std_logic);
end notA00;

architecture notA0 of notA00 is
begin
	pnota: process(clknota)
	variable auxnota: bit:='0';
	begin
		if(clknota'event and clknota = '1') then
			if (opcodenota = "00000111") then
				if (inFlagnota = '1') then
					if (auxnota = '0') then
						auxnota:='1';
						outnota <= not(inAnota);
						outFlagnota <= '1';
					else 
						outFlagnota <= '0';
					end if;
				elsif (inFlagnota = '0') then
					outFlagnota <= '0';
				end if;
			else
				outnota <= (others => 'Z');
				outFlagnota <= 'Z';
				auxnota:='0';
			end if;
		end if;
	end process pnota;
end notA0;