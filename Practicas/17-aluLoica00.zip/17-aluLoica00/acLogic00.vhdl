library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity acLogic00 is
	port(
		 clkac: in std_logic;
		 inFlagac: in std_logic;
		 enac: in std_logic;
		 inDataac: in std_logic_vector(7 downto 0);
		 outac: out std_logic_vector(7 downto 0);
		 outFlagac: out std_logic); --- va al pc
end acLogic00;

architecture acLogic0 of acLogic00 is
signal scontrolac: std_logic_vector(1 downto 0);
begin
scontrolac <= (enac)&(inFlagac);
	pac: process(clkac)
	variable auxac: bit:='0';
	begin
		if (clkac'event and clkac = '1')then
			case scontrolac is
				when "00" =>
					outac <= "00000000";
					outFlagac <= '0';
					auxac:='0';
				when "01" =>
					outac <= "00000000";
					outFlagac <= '0';
					auxac:='0';
				when "10" =>
					if (auxac = '0') then
						outFlagac <= '1';
						auxac:='1';
					end if;
				when "11" =>
					if (auxac = '1') then
						outac <= inDataac;
						outFlagac <= '1';
						auxac:='1';
					end if;
				when others => null;
			end case;
		end if;
	end process pac;
end acLogic0;