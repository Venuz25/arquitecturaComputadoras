library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

package packageBLA00 is

	component osc00
		port(cdiv: in std_logic_vector(5 downto 0);
		 oscout0: inout std_logic);
	end component;
	
	component and00
		port(
		 clka: in std_logic;
		 opcodea: in std_logic_vector(7 downto 0);
		 inAa, inBa: std_logic_vector(7 downto 0);
		 inFlaga: in std_logic;
		 outa: out std_logic_vector(7 downto 0);
		 outFlaga: out std_logic);
	end component;	
	
	component or00
		port(
		 clko: in std_logic;
		 opcodeo: in std_logic_vector(7 downto 0);
		 inAo, inBo: std_logic_vector(7 downto 0);
		 inFlago: in std_logic;
		 outo: out std_logic_vector(7 downto 0);
		 outFlago: out std_logic);
	end component;
	
	component xor00
		port(
		 clkx: in std_logic;
		 opcodex: in std_logic_vector(7 downto 0);
		 inAx, inBx: std_logic_vector(7 downto 0);
		 inFlagx: in std_logic;
		 outx: out std_logic_vector(7 downto 0);
		 outFlagx: out std_logic);
	end component;
		
	component nand00
		port(
		 clkna: in std_logic;
		 opcodena: in std_logic_vector(7 downto 0);
		 inAna, inBna: std_logic_vector(7 downto 0);
		 inFlagna: in std_logic;
		 outna: out std_logic_vector(7 downto 0);
		 outFlagna: out std_logic);
	end component;
	
	
	component nor00
		port(
		 clkno: in std_logic;
		 opcodeno: in std_logic_vector(7 downto 0);
		 inAno, inBno: std_logic_vector(7 downto 0);
		 inFlagno: in std_logic;
		 outno: out std_logic_vector(7 downto 0);
		 outFlagno: out std_logic);
	end component;
	
	
	component xnor00
		port(
		 clknx: in std_logic;
		 opcodenx: in std_logic_vector(7 downto 0);
		 inAnx, inBnx: std_logic_vector(7 downto 0);
		 inFlagnx: in std_logic;
		 outnx: out std_logic_vector(7 downto 0);
		 outFlagnx: out std_logic);
	end component;
	
	component notA00
		port(
		 clknota: in std_logic;
		 opcodenota: in std_logic_vector(7 downto 0);
		 inAnota, inBnota: std_logic_vector(7 downto 0);
		 inFlagnota: in std_logic;
		 outnota: out std_logic_vector(7 downto 0);
		 outFlagnota: out std_logic);
	end component;
	
	component pc00
		port(
		 clkpc: in std_logic;
		 repc, enpc, rwpc: in std_logic;
		 inFlagpc: std_logic;
		 outpc: inout std_logic_vector(3 downto 0));
	end component;
	
	component ram_EBR_00
		port(
			 Clock: in std_logic;
			 ClockEn: in std_logic;
			 Reset: in std_logic;
			 WE: in std_logic;
			 Address: in std_logic_vector(3 downto 0);
			 Data: in std_logic_vector(7 downto 0);
			 Q: out std_logic_vector(7 downto 0));
	end component;
	
	component acLogic00
		port(
		 clkac: in std_logic;
		 inFlagac: in std_logic;
		 enac: in std_logic;
		 inDataac: in std_logic_vector(7 downto 0);
		 outac: out std_logic_vector(7 downto 0);
		 outFlagac: out std_logic);
	end component;
	
end packageBLA00;