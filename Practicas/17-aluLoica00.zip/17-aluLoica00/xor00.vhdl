library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity xor00 is
	port(
		 clkx: in std_logic;
		 opcodex: in std_logic_vector(7 downto 0);
		 inAx, inBx: std_logic_vector(7 downto 0);
		 inFlagx: in std_logic;
		 outx: out std_logic_vector(7 downto 0);
		 outFlagx: out std_logic);
end xor00;

architecture xor0 of xor00 is
begin
	pxor: process(clkx)
	variable auxxor: bit:='0';
	begin
		if(clkx'event and clkx = '1') then
			if (opcodex = "00000011") then
				if (inFlagx = '1') then
					if (auxxor = '0') then
						auxxor:='1';
						outx <= inAx xor inBx;
						outFlagx <= '1';
					else 
						outFlagx <= '0';
					end if;
				elsif (inFlagx = '0') then
					outFlagx <= '0';
				end if;
			else
				outx <= (others => 'Z');
				outFlagx <= 'Z';
				auxxor:='0';
			end if;
		end if;
	end process pxor;
end xor0;