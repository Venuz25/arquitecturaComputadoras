// Verilog netlist produced by program LSE :  version Diamond (64-bit) 3.14.0.75.2
// Netlist written on Thu Jun 19 10:12:52 2025
//
// Verilog Description of module aluBL00
//

module aluBL00 (clk0, cdiv0, re0, en0, rw0, inA0, inB0, out0, 
            outCode0, Address0, outFlagL0, outFlag0);   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(7[8:15])
    output clk0 /* synthesis .original_dir=IN_OUT */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(9[4:8])
    input [5:0]cdiv0;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(10[4:9])
    input re0;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(11[4:7])
    input en0;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(11[9:12])
    input rw0;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(11[14:17])
    input [7:0]inA0;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(12[4:8])
    input [7:0]inB0;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(12[10:14])
    output [7:0]out0;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(13[4:8])
    output [7:0]outCode0;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(14[4:12])
    output [3:0]Address0;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(15[4:12])
    inout outFlagL0;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(16[4:13])
    output outFlag0 /* synthesis .original_dir=IN_OUT */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(17[4:12])
    
    wire clk0_c /* synthesis is_clock=1, SET_AS_NETWORK=clk0_c */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(9[4:8])
    
    wire GND_net, cdiv0_c_5, cdiv0_c_4, cdiv0_c_3, cdiv0_c_2, cdiv0_c_1, 
        cdiv0_c_0, re0_c, en0_c, rw0_c, inA0_c_7, inA0_c_6, inA0_c_5, 
        inA0_c_4, inA0_c_3, inA0_c_2, inA0_c_1, inA0_c_0, inB0_c_7, 
        inB0_c_6, inB0_c_5, inB0_c_4, inB0_c_3, inB0_c_2, inB0_c_1, 
        inB0_c_0, out0_c_7, out0_c_6, out0_c_5, out0_c_4, out0_c_3, 
        out0_c_2, out0_c_1, out0_c_0, outCode0_c_7, outCode0_c_6, 
        outCode0_c_5, outCode0_c_4, outCode0_c_3, outCode0_c_2, outCode0_c_1, 
        outCode0_c_0, Address0_c_3, Address0_c_2, Address0_c_1, Address0_c_0, 
        outFlag0_c;
    wire [7:0]srd;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(21[8:11])
    
    wire VCC_net;
    wire [7:0]outa_7__N_216;
    
    wire outFlaga_N_256, outa_3__N_225, outFlaga_N_257, outo_7__N_287;
    wire [7:0]outo_7__N_267;
    
    wire outFlago_N_307, outo_7__N_268, outFlago_N_308, outx_7__N_338;
    wire [7:0]outx_7__N_318;
    
    wire outFlagx_N_358, outx_7__N_319, outFlagx_N_359, \pnand.auxna , 
        outna_7__N_389;
    wire [7:0]outna_7__N_369;
    
    wire outFlagna_N_409, outna_7__N_387, outna_7__N_370, outFlagna_N_410, 
        \pnor.auxno , outno_7__N_440;
    wire [7:0]outno_7__N_420;
    
    wire outFlagno_N_460, outno_7__N_438, outno_7__N_421, outFlagno_N_461, 
        \pxnor.auxnx , outnx_7__N_491;
    wire [7:0]outnx_7__N_471;
    
    wire outFlagnx_N_511, outnx_7__N_489, outnx_7__N_472, outFlagnx_N_512, 
        \pnota.auxnota , outnota_7__N_542, outnota_7__N_540, n2829, 
        clk0_c_enable_2, n2434, n2824, n10, n2822, n2821, n2818, 
        clk0_c_enable_15, n2450, n2815, n2933, n2814, n2813, n2812, 
        n2837, n2833, n2832, n2831, outFlagL0_out;
    
    VHI i5 (.Z(VCC_net));
    IB inB0_pad_0 (.I(inB0[0]), .O(inB0_c_0));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(12[10:14])
    IB inB0_pad_1 (.I(inB0[1]), .O(inB0_c_1));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(12[10:14])
    IB inB0_pad_2 (.I(inB0[2]), .O(inB0_c_2));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(12[10:14])
    IB inB0_pad_3 (.I(inB0[3]), .O(inB0_c_3));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(12[10:14])
    IB inB0_pad_4 (.I(inB0[4]), .O(inB0_c_4));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(12[10:14])
    IB inB0_pad_5 (.I(inB0[5]), .O(inB0_c_5));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(12[10:14])
    IB inB0_pad_6 (.I(inB0[6]), .O(inB0_c_6));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(12[10:14])
    IB inB0_pad_7 (.I(inB0[7]), .O(inB0_c_7));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(12[10:14])
    IB inA0_pad_0 (.I(inA0[0]), .O(inA0_c_0));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(12[4:8])
    IB inA0_pad_1 (.I(inA0[1]), .O(inA0_c_1));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(12[4:8])
    IB inA0_pad_2 (.I(inA0[2]), .O(inA0_c_2));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(12[4:8])
    IB inA0_pad_3 (.I(inA0[3]), .O(inA0_c_3));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(12[4:8])
    IB inA0_pad_4 (.I(inA0[4]), .O(inA0_c_4));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(12[4:8])
    IB inA0_pad_5 (.I(inA0[5]), .O(inA0_c_5));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(12[4:8])
    IB inA0_pad_6 (.I(inA0[6]), .O(inA0_c_6));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(12[4:8])
    IB inA0_pad_7 (.I(inA0[7]), .O(inA0_c_7));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(12[4:8])
    IB rw0_pad (.I(rw0), .O(rw0_c));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(11[14:17])
    IB en0_pad (.I(en0), .O(en0_c));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(11[9:12])
    IB re0_pad (.I(re0), .O(re0_c));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(11[4:7])
    IB cdiv0_pad_0 (.I(cdiv0[0]), .O(cdiv0_c_0));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(10[4:9])
    IB cdiv0_pad_1 (.I(cdiv0[1]), .O(cdiv0_c_1));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(10[4:9])
    IB cdiv0_pad_2 (.I(cdiv0[2]), .O(cdiv0_c_2));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(10[4:9])
    IB cdiv0_pad_3 (.I(cdiv0[3]), .O(cdiv0_c_3));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(10[4:9])
    IB cdiv0_pad_4 (.I(cdiv0[4]), .O(cdiv0_c_4));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(10[4:9])
    IB cdiv0_pad_5 (.I(cdiv0[5]), .O(cdiv0_c_5));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(10[4:9])
    OB outFlag0_pad (.I(outFlag0_c), .O(outFlag0));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(17[4:12])
    OB Address0_pad_0 (.I(Address0_c_0), .O(Address0[0]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(15[4:12])
    OB Address0_pad_1 (.I(Address0_c_1), .O(Address0[1]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(15[4:12])
    OB Address0_pad_2 (.I(Address0_c_2), .O(Address0[2]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(15[4:12])
    OB Address0_pad_3 (.I(Address0_c_3), .O(Address0[3]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(15[4:12])
    OB outCode0_pad_0 (.I(outCode0_c_0), .O(outCode0[0]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(14[4:12])
    OB outCode0_pad_1 (.I(outCode0_c_1), .O(outCode0[1]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(14[4:12])
    OB outCode0_pad_2 (.I(outCode0_c_2), .O(outCode0[2]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(14[4:12])
    OB outCode0_pad_3 (.I(outCode0_c_3), .O(outCode0[3]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(14[4:12])
    OB outCode0_pad_4 (.I(outCode0_c_4), .O(outCode0[4]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(14[4:12])
    OB outCode0_pad_5 (.I(outCode0_c_5), .O(outCode0[5]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(14[4:12])
    OB outCode0_pad_6 (.I(outCode0_c_6), .O(outCode0[6]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(14[4:12])
    OB outCode0_pad_7 (.I(outCode0_c_7), .O(outCode0[7]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(14[4:12])
    OB out0_pad_0 (.I(out0_c_0), .O(out0[0]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(13[4:8])
    OB out0_pad_1 (.I(out0_c_1), .O(out0[1]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(13[4:8])
    OB out0_pad_2 (.I(out0_c_2), .O(out0[2]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(13[4:8])
    OB out0_pad_3 (.I(out0_c_3), .O(out0[3]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(13[4:8])
    OB out0_pad_4 (.I(out0_c_4), .O(out0[4]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(13[4:8])
    OB out0_pad_5 (.I(out0_c_5), .O(out0[5]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(13[4:8])
    OB out0_pad_6 (.I(out0_c_6), .O(out0[6]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(13[4:8])
    OB out0_pad_7 (.I(out0_c_7), .O(out0[7]));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(13[4:8])
    OB clk0_pad (.I(clk0_c), .O(clk0));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(9[4:8])
    BB outFlagL0_pad (.I(n2434), .T(n2450), .B(outFlagL0), .O(outFlagL0_out));
    pc00 AL08 (.Address0_c_1(Address0_c_1), .Address0_c_2(Address0_c_2), 
         .Address0_c_3(Address0_c_3), .Address0_c_0(Address0_c_0), .clk0_c(clk0_c), 
         .clk0_c_enable_15(clk0_c_enable_15), .en0_c(en0_c), .re0_c(re0_c), 
         .rw0_c(rw0_c), .outFlag0_c(outFlag0_c), .n2831(n2831));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(90[8:12])
    acLogic00 AL10 (.out0_c_0(out0_c_0), .clk0_c(clk0_c), .n2833(n2833), 
            .srd({srd}), .clk0_c_enable_2(clk0_c_enable_2), .n2933(n2933), 
            .outFlag0_c(outFlag0_c), .outFlagL0_out(outFlagL0_out), .out0_c_7(out0_c_7), 
            .out0_c_6(out0_c_6), .out0_c_5(out0_c_5), .out0_c_4(out0_c_4), 
            .out0_c_3(out0_c_3), .out0_c_2(out0_c_2), .out0_c_1(out0_c_1));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(105[8:17])
    notA00 AL07 (.outno_7__N_420({outno_7__N_420}), .outno_7__N_421(outno_7__N_421), 
           .srd({srd}), .outo_7__N_267({outo_7__N_267}), .outna_7__N_369({outna_7__N_369}), 
           .outo_7__N_268(outo_7__N_268), .outna_7__N_370(outna_7__N_370), 
           .outx_7__N_318({outx_7__N_318}), .outx_7__N_319(outx_7__N_319), 
           .clk0_c(clk0_c), .outnota_7__N_542(outnota_7__N_542), .inA0_c_2(inA0_c_2), 
           .outnota_7__N_540(outnota_7__N_540), .inA0_c_1(inA0_c_1), .outa_7__N_216({outa_7__N_216}), 
           .outnx_7__N_471({outnx_7__N_471}), .outa_3__N_225(outa_3__N_225), 
           .outnx_7__N_472(outnx_7__N_472), .outFlagL0_out(outFlagL0_out), 
           .clk0_c_enable_2(clk0_c_enable_2), .n2833(n2833), .\pnota.auxnota (\pnota.auxnota ), 
           .en0_c(en0_c), .n2813(n2813), .n2933(n2933), .inA0_c_0(inA0_c_0), 
           .outFlagx_N_359(outFlagx_N_359), .outFlagna_N_410(outFlagna_N_410), 
           .outFlaga_N_257(outFlaga_N_257), .outFlagno_N_461(outFlagno_N_461), 
           .outFlagnx_N_512(outFlagnx_N_512), .outFlago_N_308(outFlago_N_308), 
           .n2450(n2450), .outFlagno_N_460(outFlagno_N_460), .outFlagnx_N_511(outFlagnx_N_511), 
           .outFlagna_N_409(outFlagna_N_409), .outFlago_N_307(outFlago_N_307), 
           .inA0_c_7(inA0_c_7), .outFlaga_N_256(outFlaga_N_256), .outFlagx_N_358(outFlagx_N_358), 
           .n2434(n2434), .inA0_c_6(inA0_c_6), .inA0_c_5(inA0_c_5), .inA0_c_4(inA0_c_4), 
           .inA0_c_3(inA0_c_3));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(82[8:14])
    ram_EBR_00 AL09 (.clk0_c(clk0_c), .en0_c(en0_c), .re0_c(re0_c), .rw0_c(rw0_c), 
            .Address0_c_3(Address0_c_3), .Address0_c_2(Address0_c_2), .Address0_c_1(Address0_c_1), 
            .Address0_c_0(Address0_c_0), .GND_net(GND_net), .outCode0_c_7(outCode0_c_7), 
            .outCode0_c_6(outCode0_c_6), .outCode0_c_5(outCode0_c_5), .outCode0_c_4(outCode0_c_4), 
            .outCode0_c_3(outCode0_c_3), .outCode0_c_2(outCode0_c_2), .outCode0_c_1(outCode0_c_1), 
            .outCode0_c_0(outCode0_c_0), .VCC_net(VCC_net)) /* synthesis NGD_DRC_MASK=1 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(97[8:18])
    GSR GSR_INST (.GSR(VCC_net));
    and00 AL01 (.outFlaga_N_257(outFlaga_N_257), .clk0_c(clk0_c), .outCode0_c_0(outCode0_c_0), 
          .n2837(n2837), .outCode0_c_1(outCode0_c_1), .outna_7__N_389(outna_7__N_389), 
          .n2822(n2822), .en0_c(en0_c), .srd({srd}), .inA0_c_6(inA0_c_6), 
          .inB0_c_6(inB0_c_6), .n2824(n2824), .n2814(n2814), .inA0_c_5(inA0_c_5), 
          .inB0_c_5(inB0_c_5), .inA0_c_4(inA0_c_4), .inB0_c_4(inB0_c_4), 
          .inA0_c_3(inA0_c_3), .inB0_c_3(inB0_c_3), .inA0_c_2(inA0_c_2), 
          .inB0_c_2(inB0_c_2), .outnx_7__N_491(outnx_7__N_491), .n10(n10), 
          .n2815(n2815), .outo_7__N_287(outo_7__N_287), .inA0_c_1(inA0_c_1), 
          .inB0_c_1(inB0_c_1), .n2833(n2833), .inA0_c_0(inA0_c_0), .inB0_c_0(inB0_c_0), 
          .rw0_c(rw0_c), .n2831(n2831), .outa_7__N_216({outa_7__N_216}), 
          .outFlag0_c(outFlag0_c), .re0_c(re0_c), .clk0_c_enable_15(clk0_c_enable_15), 
          .outx_7__N_338(outx_7__N_338), .n2813(n2813), .outnota_7__N_542(outnota_7__N_542), 
          .outno_7__N_440(outno_7__N_440), .n2821(n2821), .n2829(n2829), 
          .\pnor.auxno (\pnor.auxno ), .outno_7__N_438(outno_7__N_438), 
          .n2832(n2832), .inA0_c_7(inA0_c_7), .inB0_c_7(inB0_c_7), .outCode0_c_2(outCode0_c_2), 
          .outCode0_c_3(outCode0_c_3), .outCode0_c_4(outCode0_c_4), .outCode0_c_6(outCode0_c_6), 
          .outCode0_c_5(outCode0_c_5), .outCode0_c_7(outCode0_c_7), .outFlaga_N_256(outFlaga_N_256), 
          .n2933(n2933), .outa_3__N_225(outa_3__N_225), .n2812(n2812), 
          .n2818(n2818));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(29[8:13])
    xor00 AL03 (.outx_7__N_318({outx_7__N_318}), .clk0_c(clk0_c), .outFlagx_N_359(outFlagx_N_359), 
          .outx_7__N_338(outx_7__N_338), .n10(n10), .n2818(n2818), .en0_c(en0_c), 
          .n2837(n2837), .\pnota.auxnota (\pnota.auxnota ), .outnota_7__N_540(outnota_7__N_540), 
          .n2812(n2812), .n2933(n2933), .srd({srd}), .inA0_c_0(inA0_c_0), 
          .inB0_c_0(inB0_c_0), .inA0_c_7(inA0_c_7), .inB0_c_7(inB0_c_7), 
          .inA0_c_6(inA0_c_6), .inB0_c_6(inB0_c_6), .inA0_c_5(inA0_c_5), 
          .inB0_c_5(inB0_c_5), .inA0_c_4(inA0_c_4), .inB0_c_4(inB0_c_4), 
          .inA0_c_3(inA0_c_3), .inB0_c_3(inB0_c_3), .inA0_c_2(inA0_c_2), 
          .inB0_c_2(inB0_c_2), .inA0_c_1(inA0_c_1), .inB0_c_1(inB0_c_1), 
          .outFlagx_N_358(outFlagx_N_358), .n2833(n2833), .outx_7__N_319(outx_7__N_319));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(47[8:13])
    nor00 AL05 (.srd({srd}), .inA0_c_3(inA0_c_3), .outno_7__N_438(outno_7__N_438), 
          .inB0_c_3(inB0_c_3), .outno_7__N_420({outno_7__N_420}), .clk0_c(clk0_c), 
          .outFlagno_N_461(outFlagno_N_461), .outno_7__N_440(outno_7__N_440), 
          .outFlagno_N_460(outFlagno_N_460), .n2833(n2833), .\pnor.auxno (\pnor.auxno ), 
          .en0_c(en0_c), .n2821(n2821), .n2933(n2933), .inA0_c_4(inA0_c_4), 
          .inB0_c_4(inB0_c_4), .inA0_c_6(inA0_c_6), .inB0_c_6(inB0_c_6), 
          .inA0_c_0(inA0_c_0), .inB0_c_0(inB0_c_0), .inA0_c_1(inA0_c_1), 
          .inB0_c_1(inB0_c_1), .inA0_c_2(inA0_c_2), .inB0_c_2(inB0_c_2), 
          .inA0_c_7(inA0_c_7), .inB0_c_7(inB0_c_7), .outno_7__N_421(outno_7__N_421), 
          .inA0_c_5(inA0_c_5), .inB0_c_5(inB0_c_5));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(65[8:13])
    nand00 AL04 (.outna_7__N_369({outna_7__N_369}), .clk0_c(clk0_c), .outFlagna_N_410(outFlagna_N_410), 
           .outna_7__N_389(outna_7__N_389), .outCode0_c_2(outCode0_c_2), 
           .outCode0_c_3(outCode0_c_3), .n2837(n2837), .outCode0_c_1(outCode0_c_1), 
           .n2829(n2829), .srd({srd}), .inA0_c_7(inA0_c_7), .outna_7__N_387(outna_7__N_387), 
           .inB0_c_7(inB0_c_7), .inA0_c_6(inA0_c_6), .inB0_c_6(inB0_c_6), 
           .inA0_c_5(inA0_c_5), .inB0_c_5(inB0_c_5), .inA0_c_4(inA0_c_4), 
           .inB0_c_4(inB0_c_4), .inA0_c_3(inA0_c_3), .inB0_c_3(inB0_c_3), 
           .outFlagna_N_409(outFlagna_N_409), .n2833(n2833), .\pnand.auxna (\pnand.auxna ), 
           .en0_c(en0_c), .n2822(n2822), .n2933(n2933), .inA0_c_2(inA0_c_2), 
           .inB0_c_2(inB0_c_2), .inA0_c_1(inA0_c_1), .inB0_c_1(inB0_c_1), 
           .inA0_c_0(inA0_c_0), .inB0_c_0(inB0_c_0), .outna_7__N_370(outna_7__N_370));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(56[8:14])
    osc00 AL00 (.GND_net(GND_net), .cdiv0_c_2(cdiv0_c_2), .clk0_c(clk0_c), 
          .cdiv0_c_5(cdiv0_c_5), .cdiv0_c_4(cdiv0_c_4), .cdiv0_c_0(cdiv0_c_0), 
          .cdiv0_c_3(cdiv0_c_3), .cdiv0_c_1(cdiv0_c_1));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(26[8:13])
    xnor00 AL06 (.outnx_7__N_471({outnx_7__N_471}), .clk0_c(clk0_c), .outFlagnx_N_512(outFlagnx_N_512), 
           .outnx_7__N_491(outnx_7__N_491), .srd({srd}), .inA0_c_7(inA0_c_7), 
           .outnx_7__N_489(outnx_7__N_489), .inB0_c_7(inB0_c_7), .inA0_c_6(inA0_c_6), 
           .inB0_c_6(inB0_c_6), .inA0_c_5(inA0_c_5), .inB0_c_5(inB0_c_5), 
           .inA0_c_4(inA0_c_4), .inB0_c_4(inB0_c_4), .inA0_c_3(inA0_c_3), 
           .inB0_c_3(inB0_c_3), .inA0_c_2(inA0_c_2), .inB0_c_2(inB0_c_2), 
           .inA0_c_1(inA0_c_1), .inB0_c_1(inB0_c_1), .outFlagnx_N_511(outFlagnx_N_511), 
           .n2833(n2833), .\pxnor.auxnx (\pxnor.auxnx ), .en0_c(en0_c), 
           .n2814(n2814), .n2933(n2933), .inA0_c_0(inA0_c_0), .inB0_c_0(inB0_c_0), 
           .outnx_7__N_472(outnx_7__N_472));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(73[8:14])
    or00 AL02 (.outo_7__N_267({outo_7__N_267}), .clk0_c(clk0_c), .outFlago_N_308(outFlago_N_308), 
         .outo_7__N_287(outo_7__N_287), .n2837(n2837), .n2824(n2824), 
         .\pxnor.auxnx (\pxnor.auxnx ), .en0_c(en0_c), .outnx_7__N_489(outnx_7__N_489), 
         .srd({srd}), .inA0_c_7(inA0_c_7), .inB0_c_7(inB0_c_7), .inA0_c_0(inA0_c_0), 
         .inB0_c_0(inB0_c_0), .inA0_c_6(inA0_c_6), .inB0_c_6(inB0_c_6), 
         .inA0_c_5(inA0_c_5), .inB0_c_5(inB0_c_5), .inA0_c_4(inA0_c_4), 
         .inB0_c_4(inB0_c_4), .inA0_c_3(inA0_c_3), .inB0_c_3(inB0_c_3), 
         .n2832(n2832), .n2829(n2829), .\pnand.auxna (\pnand.auxna ), 
         .outna_7__N_387(outna_7__N_387), .inA0_c_2(inA0_c_2), .inB0_c_2(inB0_c_2), 
         .inA0_c_1(inA0_c_1), .inB0_c_1(inB0_c_1), .n10(n10), .outFlago_N_307(outFlago_N_307), 
         .n2833(n2833), .n2815(n2815), .n2933(n2933), .outo_7__N_268(outo_7__N_268));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(38[8:12])
    VLO i1 (.Z(GND_net));
    LUT4 m1_lut (.Z(n2933)) /* synthesis lut_function=1, syn_instantiated=1 */ ;
    defparam m1_lut.init = 16'hffff;
    TSALL TSALL_INST (.TSALL(GND_net));
    PUR PUR_INST (.PUR(VCC_net));
    defparam PUR_INST.RST_PULSE = 1;
    
endmodule
//
// Verilog Description of module pc00
//

module pc00 (Address0_c_1, Address0_c_2, Address0_c_3, Address0_c_0, 
            clk0_c, clk0_c_enable_15, en0_c, re0_c, rw0_c, outFlag0_c, 
            n2831);
    output Address0_c_1;
    output Address0_c_2;
    output Address0_c_3;
    output Address0_c_0;
    input clk0_c;
    input clk0_c_enable_15;
    input en0_c;
    input re0_c;
    input rw0_c;
    input outFlag0_c;
    input n2831;
    
    wire clk0_c /* synthesis is_clock=1, SET_AS_NETWORK=clk0_c */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(9[4:8])
    
    wire n2817, n2653;
    wire [3:0]outpc_3__N_573;
    
    wire n2810, n2830, \ppc.auxpc , clk0_c_enable_4, \ppc.auxpc_N_581 , 
        n25, n1429, n9, n2415, n35;
    
    LUT4 i1_3_lut_4_lut (.A(Address0_c_1), .B(n2817), .C(n2653), .D(Address0_c_2), 
         .Z(outpc_3__N_573[2])) /* synthesis lut_function=(!(A (B ((D)+!C)+!B !(C (D)))+!A !(C (D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/pc00.vhdl(30[6] 38[13])
    defparam i1_3_lut_4_lut.init = 16'h7080;
    LUT4 i1_4_lut (.A(Address0_c_3), .B(n2653), .C(Address0_c_2), .D(n2810), 
         .Z(outpc_3__N_573[3])) /* synthesis lut_function=(!(A ((C (D))+!B)+!A !(B (C (D))))) */ ;
    defparam i1_4_lut.init = 16'h4888;
    LUT4 i385_2_lut_rep_17_3_lut (.A(Address0_c_0), .B(n2830), .C(Address0_c_1), 
         .Z(n2810)) /* synthesis lut_function=(A (B (C))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/pc00.vhdl(30[6] 38[13])
    defparam i385_2_lut_rep_17_3_lut.init = 16'h8080;
    LUT4 i1_3_lut_4_lut_adj_114 (.A(Address0_c_0), .B(n2830), .C(n2653), 
         .D(Address0_c_1), .Z(outpc_3__N_573[1])) /* synthesis lut_function=(!(A (B ((D)+!C)+!B !(C (D)))+!A !(C (D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/pc00.vhdl(30[6] 38[13])
    defparam i1_3_lut_4_lut_adj_114.init = 16'h7080;
    FD1P3AX \ppc.auxpc_18  (.D(\ppc.auxpc_N_581 ), .SP(clk0_c_enable_4), 
            .CK(clk0_c), .Q(\ppc.auxpc )) /* synthesis lse_init_val=0, LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=12, LSE_LLINE=90, LSE_RLINE=90 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/pc00.vhdl(23[3] 51[10])
    defparam \ppc.auxpc_18 .GSR = "ENABLED";
    FD1P3AX outpc_i1 (.D(outpc_3__N_573[0]), .SP(clk0_c_enable_15), .CK(clk0_c), 
            .Q(Address0_c_0)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=12, LSE_LLINE=90, LSE_RLINE=90 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/pc00.vhdl(23[3] 51[10])
    defparam outpc_i1.GSR = "ENABLED";
    LUT4 i49_4_lut (.A(n25), .B(en0_c), .C(re0_c), .D(n1429), .Z(clk0_c_enable_4)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C))+!A (B (C (D)))) */ ;
    defparam i49_4_lut.init = 16'hca0a;
    LUT4 i910_2_lut (.A(rw0_c), .B(outFlag0_c), .Z(n1429)) /* synthesis lut_function=(!(A (B)+!A !(B))) */ ;
    defparam i910_2_lut.init = 16'h6666;
    LUT4 i2201_3_lut (.A(outFlag0_c), .B(rw0_c), .C(re0_c), .Z(\ppc.auxpc_N_581 )) /* synthesis lut_function=(!((B+(C))+!A)) */ ;
    defparam i2201_3_lut.init = 16'h0202;
    LUT4 i1421_2_lut (.A(rw0_c), .B(outFlag0_c), .Z(n9)) /* synthesis lut_function=(!(A+(B))) */ ;
    defparam i1421_2_lut.init = 16'h1111;
    LUT4 i1_4_lut_adj_115 (.A(outFlag0_c), .B(rw0_c), .C(Address0_c_3), 
         .D(n2415), .Z(n35)) /* synthesis lut_function=(A (B+!(C+(D)))) */ ;
    defparam i1_4_lut_adj_115.init = 16'h888a;
    LUT4 i1_4_lut_adj_116 (.A(Address0_c_0), .B(n2653), .C(n2831), .D(n2830), 
         .Z(outpc_3__N_573[0])) /* synthesis lut_function=(!(A ((C+(D))+!B)+!A ((C+!(D))+!B))) */ ;
    defparam i1_4_lut_adj_116.init = 16'h0408;
    LUT4 i1_2_lut (.A(outFlag0_c), .B(re0_c), .Z(n2653)) /* synthesis lut_function=(!((B)+!A)) */ ;
    defparam i1_2_lut.init = 16'h2222;
    LUT4 i2_3_lut_rep_37 (.A(Address0_c_3), .B(\ppc.auxpc ), .C(n2415), 
         .Z(n2830)) /* synthesis lut_function=(!(A+((C)+!B))) */ ;
    defparam i2_3_lut_rep_37.init = 16'h0404;
    LUT4 i377_2_lut_rep_24_4_lut (.A(Address0_c_3), .B(\ppc.auxpc ), .C(n2415), 
         .D(Address0_c_0), .Z(n2817)) /* synthesis lut_function=(!(A+((C+!(D))+!B))) */ ;
    defparam i377_2_lut_rep_24_4_lut.init = 16'h0400;
    LUT4 i2_3_lut (.A(Address0_c_0), .B(Address0_c_2), .C(Address0_c_1), 
         .Z(n2415)) /* synthesis lut_function=(A (B (C))) */ ;
    defparam i2_3_lut.init = 16'h8080;
    FD1P3AX outpc_i4 (.D(outpc_3__N_573[3]), .SP(clk0_c_enable_15), .CK(clk0_c), 
            .Q(Address0_c_3)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=12, LSE_LLINE=90, LSE_RLINE=90 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/pc00.vhdl(23[3] 51[10])
    defparam outpc_i4.GSR = "ENABLED";
    FD1P3AX outpc_i3 (.D(outpc_3__N_573[2]), .SP(clk0_c_enable_15), .CK(clk0_c), 
            .Q(Address0_c_2)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=12, LSE_LLINE=90, LSE_RLINE=90 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/pc00.vhdl(23[3] 51[10])
    defparam outpc_i3.GSR = "ENABLED";
    FD1P3AX outpc_i2 (.D(outpc_3__N_573[1]), .SP(clk0_c_enable_15), .CK(clk0_c), 
            .Q(Address0_c_1)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=12, LSE_LLINE=90, LSE_RLINE=90 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/pc00.vhdl(23[3] 51[10])
    defparam outpc_i2.GSR = "ENABLED";
    PFUMX i50 (.BLUT(n9), .ALUT(n35), .C0(en0_c), .Z(n25));
    
endmodule
//
// Verilog Description of module acLogic00
//

module acLogic00 (out0_c_0, clk0_c, n2833, srd, clk0_c_enable_2, n2933, 
            outFlag0_c, outFlagL0_out, out0_c_7, out0_c_6, out0_c_5, 
            out0_c_4, out0_c_3, out0_c_2, out0_c_1);
    output out0_c_0;
    input clk0_c;
    input n2833;
    input [7:0]srd;
    input clk0_c_enable_2;
    input n2933;
    output outFlag0_c;
    input outFlagL0_out;
    output out0_c_7;
    output out0_c_6;
    output out0_c_5;
    output out0_c_4;
    output out0_c_3;
    output out0_c_2;
    output out0_c_1;
    
    wire clk0_c /* synthesis is_clock=1, SET_AS_NETWORK=clk0_c */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(9[4:8])
    
    wire clk0_c_enable_12, \pac.auxac , clk0_c_enable_3;
    
    FD1P3IX outac_i1 (.D(srd[0]), .SP(clk0_c_enable_12), .CD(n2833), .CK(clk0_c), 
            .Q(out0_c_0)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=17, LSE_LLINE=105, LSE_RLINE=105 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/aclogic00.vhdl(23[3] 46[10])
    defparam outac_i1.GSR = "ENABLED";
    FD1P3IX \pac.auxac_18  (.D(n2933), .SP(clk0_c_enable_2), .CD(n2833), 
            .CK(clk0_c), .Q(\pac.auxac )) /* synthesis lse_init_val=0, LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=17, LSE_LLINE=105, LSE_RLINE=105 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/aclogic00.vhdl(23[3] 46[10])
    defparam \pac.auxac_18 .GSR = "ENABLED";
    FD1P3IX outFlagac_17 (.D(n2933), .SP(clk0_c_enable_3), .CD(n2833), 
            .CK(clk0_c), .Q(outFlag0_c)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=17, LSE_LLINE=105, LSE_RLINE=105 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/aclogic00.vhdl(23[3] 46[10])
    defparam outFlagac_17.GSR = "ENABLED";
    LUT4 i582_2_lut (.A(\pac.auxac ), .B(outFlagL0_out), .Z(clk0_c_enable_3)) /* synthesis lut_function=(A (B)+!A !(B)) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/aclogic00.vhdl(24[4] 45[13])
    defparam i582_2_lut.init = 16'h9999;
    FD1P3IX outac_i8 (.D(srd[7]), .SP(clk0_c_enable_12), .CD(n2833), .CK(clk0_c), 
            .Q(out0_c_7)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=17, LSE_LLINE=105, LSE_RLINE=105 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/aclogic00.vhdl(23[3] 46[10])
    defparam outac_i8.GSR = "ENABLED";
    FD1P3IX outac_i7 (.D(srd[6]), .SP(clk0_c_enable_12), .CD(n2833), .CK(clk0_c), 
            .Q(out0_c_6)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=17, LSE_LLINE=105, LSE_RLINE=105 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/aclogic00.vhdl(23[3] 46[10])
    defparam outac_i7.GSR = "ENABLED";
    FD1P3IX outac_i6 (.D(srd[5]), .SP(clk0_c_enable_12), .CD(n2833), .CK(clk0_c), 
            .Q(out0_c_5)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=17, LSE_LLINE=105, LSE_RLINE=105 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/aclogic00.vhdl(23[3] 46[10])
    defparam outac_i6.GSR = "ENABLED";
    FD1P3IX outac_i5 (.D(srd[4]), .SP(clk0_c_enable_12), .CD(n2833), .CK(clk0_c), 
            .Q(out0_c_4)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=17, LSE_LLINE=105, LSE_RLINE=105 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/aclogic00.vhdl(23[3] 46[10])
    defparam outac_i5.GSR = "ENABLED";
    FD1P3IX outac_i4 (.D(srd[3]), .SP(clk0_c_enable_12), .CD(n2833), .CK(clk0_c), 
            .Q(out0_c_3)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=17, LSE_LLINE=105, LSE_RLINE=105 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/aclogic00.vhdl(23[3] 46[10])
    defparam outac_i4.GSR = "ENABLED";
    FD1P3IX outac_i3 (.D(srd[2]), .SP(clk0_c_enable_12), .CD(n2833), .CK(clk0_c), 
            .Q(out0_c_2)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=17, LSE_LLINE=105, LSE_RLINE=105 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/aclogic00.vhdl(23[3] 46[10])
    defparam outac_i3.GSR = "ENABLED";
    FD1P3IX outac_i2 (.D(srd[1]), .SP(clk0_c_enable_12), .CD(n2833), .CK(clk0_c), 
            .Q(out0_c_1)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=17, LSE_LLINE=105, LSE_RLINE=105 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/aclogic00.vhdl(23[3] 46[10])
    defparam outac_i2.GSR = "ENABLED";
    LUT4 i574_2_lut (.A(\pac.auxac ), .B(outFlagL0_out), .Z(clk0_c_enable_12)) /* synthesis lut_function=(A (B)) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/aclogic00.vhdl(24[4] 45[13])
    defparam i574_2_lut.init = 16'h8888;
    
endmodule
//
// Verilog Description of module notA00
//

module notA00 (outno_7__N_420, outno_7__N_421, srd, outo_7__N_267, outna_7__N_369, 
            outo_7__N_268, outna_7__N_370, outx_7__N_318, outx_7__N_319, 
            clk0_c, outnota_7__N_542, inA0_c_2, outnota_7__N_540, inA0_c_1, 
            outa_7__N_216, outnx_7__N_471, outa_3__N_225, outnx_7__N_472, 
            outFlagL0_out, clk0_c_enable_2, n2833, \pnota.auxnota , 
            en0_c, n2813, n2933, inA0_c_0, outFlagx_N_359, outFlagna_N_410, 
            outFlaga_N_257, outFlagno_N_461, outFlagnx_N_512, outFlago_N_308, 
            n2450, outFlagno_N_460, outFlagnx_N_511, outFlagna_N_409, 
            outFlago_N_307, inA0_c_7, outFlaga_N_256, outFlagx_N_358, 
            n2434, inA0_c_6, inA0_c_5, inA0_c_4, inA0_c_3);
    input [7:0]outno_7__N_420;
    input outno_7__N_421;
    output [7:0]srd;
    input [7:0]outo_7__N_267;
    input [7:0]outna_7__N_369;
    input outo_7__N_268;
    input outna_7__N_370;
    input [7:0]outx_7__N_318;
    input outx_7__N_319;
    input clk0_c;
    input outnota_7__N_542;
    input inA0_c_2;
    input outnota_7__N_540;
    input inA0_c_1;
    input [7:0]outa_7__N_216;
    input [7:0]outnx_7__N_471;
    input outa_3__N_225;
    input outnx_7__N_472;
    input outFlagL0_out;
    output clk0_c_enable_2;
    input n2833;
    output \pnota.auxnota ;
    input en0_c;
    input n2813;
    input n2933;
    input inA0_c_0;
    input outFlagx_N_359;
    input outFlagna_N_410;
    input outFlaga_N_257;
    input outFlagno_N_461;
    input outFlagnx_N_512;
    input outFlago_N_308;
    output n2450;
    input outFlagno_N_460;
    input outFlagnx_N_511;
    input outFlagna_N_409;
    input outFlago_N_307;
    input inA0_c_7;
    input outFlaga_N_256;
    input outFlagx_N_358;
    output n2434;
    input inA0_c_6;
    input inA0_c_5;
    input inA0_c_4;
    input inA0_c_3;
    
    wire clk0_c /* synthesis is_clock=1, SET_AS_NETWORK=clk0_c */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(9[4:8])
    
    wire n12, n8, n10, n5;
    wire [7:0]outnota_7__N_522;
    
    wire outnota_7__N_560, outFlagnota_N_563, n10_adj_605, n5_adj_606, 
        outnota_7__N_523, outnota_7__N_556, outnota_7__N_558, n12_adj_607, 
        n10_adj_608, n5_adj_609, n12_adj_610, n8_adj_611, n12_adj_612, 
        n8_adj_613, n12_adj_614, n8_adj_615, n10_adj_616, n5_adj_617, 
        n10_adj_618, n5_adj_619, n5_adj_620, n8_adj_621, outnota_7__N_538, 
        n10_adj_622, outnota_7__N_548, outFlagnota_N_562, \pnota.auxnota_N_545 , 
        outnota_7__N_550, outnota_7__N_552, outnota_7__N_554, n12_adj_623, 
        n8_adj_624, n10_adj_625, n5_adj_626, n12_adj_627, n8_adj_628, 
        n5_adj_629, n12_adj_630, n8_adj_631, n10_adj_632, n12_adj_633, 
        n5_adj_634, n10_adj_635, n8_adj_636, n12_adj_637;
    
    LUT4 i6_4_lut (.A(outno_7__N_420[3]), .B(n12), .C(n8), .D(outno_7__N_421), 
         .Z(srd[3])) /* synthesis lut_function=(A (B+(C+(D)))+!A (B+(C))) */ ;
    defparam i6_4_lut.init = 16'hfefc;
    LUT4 i3_4_lut (.A(outo_7__N_267[6]), .B(outna_7__N_369[6]), .C(outo_7__N_268), 
         .D(outna_7__N_370), .Z(n10)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;
    defparam i3_4_lut.init = 16'heca0;
    LUT4 Select_437_i5_2_lut (.A(outx_7__N_318[6]), .B(outx_7__N_319), .Z(n5)) /* synthesis lut_function=(A (B)) */ ;
    defparam Select_437_i5_2_lut.init = 16'h8888;
    FD1S3AX outnota_i0 (.D(outnota_7__N_560), .CK(clk0_c), .Q(outnota_7__N_522[0])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=82, LSE_RLINE=82 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam outnota_i0.GSR = "ENABLED";
    FD1S3AX i160_175 (.D(outnota_7__N_542), .CK(clk0_c), .Q(outFlagnota_N_563)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=82, LSE_RLINE=82 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam i160_175.GSR = "ENABLED";
    LUT4 i5_4_lut (.A(outnota_7__N_522[3]), .B(n10_adj_605), .C(n5_adj_606), 
         .D(outnota_7__N_523), .Z(n12)) /* synthesis lut_function=(A (B+(C+(D)))+!A (B+(C))) */ ;
    defparam i5_4_lut.init = 16'hfefc;
    LUT4 outnota_2__I_0_3_lut (.A(srd[2]), .B(inA0_c_2), .C(outnota_7__N_540), 
         .Z(outnota_7__N_556)) /* synthesis lut_function=(!(A (B (C))+!A (B+!(C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam outnota_2__I_0_3_lut.init = 16'h3a3a;
    LUT4 outnota_1__I_0_3_lut (.A(srd[1]), .B(inA0_c_1), .C(outnota_7__N_540), 
         .Z(outnota_7__N_558)) /* synthesis lut_function=(!(A (B (C))+!A (B+!(C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam outnota_1__I_0_3_lut.init = 16'h3a3a;
    LUT4 i1_4_lut (.A(outa_7__N_216[3]), .B(outnx_7__N_471[3]), .C(outa_3__N_225), 
         .D(outnx_7__N_472), .Z(n8)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;
    defparam i1_4_lut.init = 16'heca0;
    LUT4 i917_1_lut (.A(outFlagL0_out), .Z(clk0_c_enable_2)) /* synthesis lut_function=(!(A)) */ ;
    defparam i917_1_lut.init = 16'h5555;
    LUT4 i5_4_lut_adj_81 (.A(outnota_7__N_522[6]), .B(n10), .C(n5), .D(outnota_7__N_523), 
         .Z(n12_adj_607)) /* synthesis lut_function=(A (B+(C+(D)))+!A (B+(C))) */ ;
    defparam i5_4_lut_adj_81.init = 16'hfefc;
    LUT4 i5_4_lut_adj_82 (.A(outnota_7__N_522[5]), .B(n10_adj_608), .C(n5_adj_609), 
         .D(outnota_7__N_523), .Z(n12_adj_610)) /* synthesis lut_function=(A (B+(C+(D)))+!A (B+(C))) */ ;
    defparam i5_4_lut_adj_82.init = 16'hfefc;
    LUT4 i3_4_lut_adj_83 (.A(outo_7__N_267[3]), .B(outna_7__N_369[3]), .C(outo_7__N_268), 
         .D(outna_7__N_370), .Z(n10_adj_605)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;
    defparam i3_4_lut_adj_83.init = 16'heca0;
    LUT4 Select_440_i5_2_lut (.A(outx_7__N_318[3]), .B(outx_7__N_319), .Z(n5_adj_606)) /* synthesis lut_function=(A (B)) */ ;
    defparam Select_440_i5_2_lut.init = 16'h8888;
    LUT4 i1_4_lut_adj_84 (.A(outa_7__N_216[5]), .B(outnx_7__N_471[5]), .C(outa_3__N_225), 
         .D(outnx_7__N_472), .Z(n8_adj_611)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;
    defparam i1_4_lut_adj_84.init = 16'heca0;
    LUT4 i6_4_lut_adj_85 (.A(outno_7__N_420[0]), .B(n12_adj_612), .C(n8_adj_613), 
         .D(outno_7__N_421), .Z(srd[0])) /* synthesis lut_function=(A (B+(C+(D)))+!A (B+(C))) */ ;
    defparam i6_4_lut_adj_85.init = 16'hfefc;
    LUT4 i6_4_lut_adj_86 (.A(outno_7__N_420[7]), .B(n12_adj_614), .C(n8_adj_615), 
         .D(outno_7__N_421), .Z(srd[7])) /* synthesis lut_function=(A (B+(C+(D)))+!A (B+(C))) */ ;
    defparam i6_4_lut_adj_86.init = 16'hfefc;
    LUT4 i5_4_lut_adj_87 (.A(outnota_7__N_522[0]), .B(n10_adj_616), .C(n5_adj_617), 
         .D(outnota_7__N_523), .Z(n12_adj_612)) /* synthesis lut_function=(A (B+(C+(D)))+!A (B+(C))) */ ;
    defparam i5_4_lut_adj_87.init = 16'hfefc;
    LUT4 i1_4_lut_adj_88 (.A(outa_7__N_216[0]), .B(outnx_7__N_471[0]), .C(outa_3__N_225), 
         .D(outnx_7__N_472), .Z(n8_adj_613)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;
    defparam i1_4_lut_adj_88.init = 16'heca0;
    LUT4 i3_4_lut_adj_89 (.A(outo_7__N_267[5]), .B(outna_7__N_369[5]), .C(outo_7__N_268), 
         .D(outna_7__N_370), .Z(n10_adj_608)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;
    defparam i3_4_lut_adj_89.init = 16'heca0;
    LUT4 i5_4_lut_adj_90 (.A(outnota_7__N_522[7]), .B(n10_adj_618), .C(n5_adj_619), 
         .D(outnota_7__N_523), .Z(n12_adj_614)) /* synthesis lut_function=(A (B+(C+(D)))+!A (B+(C))) */ ;
    defparam i5_4_lut_adj_90.init = 16'hfefc;
    LUT4 i1_4_lut_adj_91 (.A(outa_7__N_216[7]), .B(outnx_7__N_471[7]), .C(outa_3__N_225), 
         .D(outnx_7__N_472), .Z(n8_adj_615)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;
    defparam i1_4_lut_adj_91.init = 16'heca0;
    LUT4 i3_4_lut_adj_92 (.A(outo_7__N_267[7]), .B(outna_7__N_369[7]), .C(outo_7__N_268), 
         .D(outna_7__N_370), .Z(n10_adj_618)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;
    defparam i3_4_lut_adj_92.init = 16'heca0;
    LUT4 Select_436_i5_2_lut (.A(outx_7__N_318[7]), .B(outx_7__N_319), .Z(n5_adj_619)) /* synthesis lut_function=(A (B)) */ ;
    defparam Select_436_i5_2_lut.init = 16'h8888;
    LUT4 Select_438_i5_2_lut (.A(outx_7__N_318[5]), .B(outx_7__N_319), .Z(n5_adj_609)) /* synthesis lut_function=(A (B)) */ ;
    defparam Select_438_i5_2_lut.init = 16'h8888;
    LUT4 Select_441_i5_2_lut (.A(outx_7__N_318[2]), .B(outx_7__N_319), .Z(n5_adj_620)) /* synthesis lut_function=(A (B)) */ ;
    defparam Select_441_i5_2_lut.init = 16'h8888;
    LUT4 i3_4_lut_adj_93 (.A(outo_7__N_267[0]), .B(outna_7__N_369[0]), .C(outo_7__N_268), 
         .D(outna_7__N_370), .Z(n10_adj_616)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;
    defparam i3_4_lut_adj_93.init = 16'heca0;
    LUT4 i1_4_lut_adj_94 (.A(outa_7__N_216[6]), .B(outnx_7__N_471[6]), .C(outa_3__N_225), 
         .D(outnx_7__N_472), .Z(n8_adj_621)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;
    defparam i1_4_lut_adj_94.init = 16'heca0;
    FD1S3AX outnota_i7 (.D(outnota_7__N_538), .CK(clk0_c), .Q(outnota_7__N_522[7])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=82, LSE_RLINE=82 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam outnota_i7.GSR = "ENABLED";
    LUT4 i3_4_lut_adj_95 (.A(outo_7__N_267[4]), .B(outna_7__N_369[4]), .C(outo_7__N_268), 
         .D(outna_7__N_370), .Z(n10_adj_622)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;
    defparam i3_4_lut_adj_95.init = 16'heca0;
    FD1S3AX outnota_i6 (.D(outnota_7__N_548), .CK(clk0_c), .Q(outnota_7__N_522[6])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=82, LSE_RLINE=82 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam outnota_i6.GSR = "ENABLED";
    FD1S3IX outFlagnota_166 (.D(\pnota.auxnota_N_545 ), .CK(clk0_c), .CD(n2833), 
            .Q(outFlagnota_N_562)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=82, LSE_RLINE=82 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam outFlagnota_166.GSR = "ENABLED";
    FD1S3AX outnota_i5 (.D(outnota_7__N_550), .CK(clk0_c), .Q(outnota_7__N_522[5])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=82, LSE_RLINE=82 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam outnota_i5.GSR = "ENABLED";
    FD1S3AX outnota_i4 (.D(outnota_7__N_552), .CK(clk0_c), .Q(outnota_7__N_522[4])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=82, LSE_RLINE=82 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam outnota_i4.GSR = "ENABLED";
    FD1S3AX outnota_i3 (.D(outnota_7__N_554), .CK(clk0_c), .Q(outnota_7__N_522[3])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=82, LSE_RLINE=82 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam outnota_i3.GSR = "ENABLED";
    LUT4 Select_443_i5_2_lut (.A(outx_7__N_318[0]), .B(outx_7__N_319), .Z(n5_adj_617)) /* synthesis lut_function=(A (B)) */ ;
    defparam Select_443_i5_2_lut.init = 16'h8888;
    FD1S3AX outnota_i2 (.D(outnota_7__N_556), .CK(clk0_c), .Q(outnota_7__N_522[2])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=82, LSE_RLINE=82 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam outnota_i2.GSR = "ENABLED";
    FD1S3AX outnota_i1 (.D(outnota_7__N_558), .CK(clk0_c), .Q(outnota_7__N_522[1])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=82, LSE_RLINE=82 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam outnota_i1.GSR = "ENABLED";
    FD1P3IX \pnota.auxnota_164  (.D(n2933), .SP(en0_c), .CD(n2813), .CK(clk0_c), 
            .Q(\pnota.auxnota )) /* synthesis lse_init_val=0, LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=82, LSE_RLINE=82 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam \pnota.auxnota_164 .GSR = "ENABLED";
    LUT4 i6_4_lut_adj_96 (.A(outno_7__N_420[1]), .B(n12_adj_623), .C(n8_adj_624), 
         .D(outno_7__N_421), .Z(srd[1])) /* synthesis lut_function=(A (B+(C+(D)))+!A (B+(C))) */ ;
    defparam i6_4_lut_adj_96.init = 16'hfefc;
    LUT4 i5_4_lut_adj_97 (.A(outnota_7__N_522[1]), .B(n10_adj_625), .C(n5_adj_626), 
         .D(outnota_7__N_523), .Z(n12_adj_623)) /* synthesis lut_function=(A (B+(C+(D)))+!A (B+(C))) */ ;
    defparam i5_4_lut_adj_97.init = 16'hfefc;
    LUT4 i1_4_lut_adj_98 (.A(outa_7__N_216[1]), .B(outnx_7__N_471[1]), .C(outa_3__N_225), 
         .D(outnx_7__N_472), .Z(n8_adj_624)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;
    defparam i1_4_lut_adj_98.init = 16'heca0;
    LUT4 i3_4_lut_adj_99 (.A(outo_7__N_267[1]), .B(outna_7__N_369[1]), .C(outo_7__N_268), 
         .D(outna_7__N_370), .Z(n10_adj_625)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;
    defparam i3_4_lut_adj_99.init = 16'heca0;
    LUT4 Select_442_i5_2_lut (.A(outx_7__N_318[1]), .B(outx_7__N_319), .Z(n5_adj_626)) /* synthesis lut_function=(A (B)) */ ;
    defparam Select_442_i5_2_lut.init = 16'h8888;
    LUT4 i6_4_lut_adj_100 (.A(outno_7__N_420[4]), .B(n12_adj_627), .C(n8_adj_628), 
         .D(outno_7__N_421), .Z(srd[4])) /* synthesis lut_function=(A (B+(C+(D)))+!A (B+(C))) */ ;
    defparam i6_4_lut_adj_100.init = 16'hfefc;
    LUT4 i5_4_lut_adj_101 (.A(outnota_7__N_522[4]), .B(n10_adj_622), .C(n5_adj_629), 
         .D(outnota_7__N_523), .Z(n12_adj_627)) /* synthesis lut_function=(A (B+(C+(D)))+!A (B+(C))) */ ;
    defparam i5_4_lut_adj_101.init = 16'hfefc;
    LUT4 outnota_0__I_0_3_lut (.A(srd[0]), .B(inA0_c_0), .C(outnota_7__N_540), 
         .Z(outnota_7__N_560)) /* synthesis lut_function=(!(A (B (C))+!A (B+!(C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam outnota_0__I_0_3_lut.init = 16'h3a3a;
    LUT4 i6_4_lut_adj_102 (.A(outno_7__N_420[2]), .B(n12_adj_630), .C(n8_adj_631), 
         .D(outno_7__N_421), .Z(srd[2])) /* synthesis lut_function=(A (B+(C+(D)))+!A (B+(C))) */ ;
    defparam i6_4_lut_adj_102.init = 16'hfefc;
    LUT4 i6_4_lut_adj_103 (.A(outno_7__N_420[6]), .B(n12_adj_607), .C(n8_adj_621), 
         .D(outno_7__N_421), .Z(srd[6])) /* synthesis lut_function=(A (B+(C+(D)))+!A (B+(C))) */ ;
    defparam i6_4_lut_adj_103.init = 16'hfefc;
    LUT4 i5_4_lut_adj_104 (.A(outnota_7__N_522[2]), .B(n10_adj_632), .C(n5_adj_620), 
         .D(outnota_7__N_523), .Z(n12_adj_630)) /* synthesis lut_function=(A (B+(C+(D)))+!A (B+(C))) */ ;
    defparam i5_4_lut_adj_104.init = 16'hfefc;
    LUT4 i1_4_lut_adj_105 (.A(outa_7__N_216[4]), .B(outnx_7__N_471[4]), 
         .C(outa_3__N_225), .D(outnx_7__N_472), .Z(n8_adj_628)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;
    defparam i1_4_lut_adj_105.init = 16'heca0;
    LUT4 i5_4_lut_adj_106 (.A(outFlagnota_N_563), .B(outFlagx_N_359), .C(outFlagna_N_410), 
         .D(outFlaga_N_257), .Z(n12_adj_633)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i5_4_lut_adj_106.init = 16'hfffe;
    LUT4 i2198_4_lut (.A(outFlagno_N_461), .B(n12_adj_633), .C(outFlagnx_N_512), 
         .D(outFlago_N_308), .Z(n2450)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;
    defparam i2198_4_lut.init = 16'h0001;
    LUT4 Select_428_i5_2_lut (.A(outFlagno_N_460), .B(outFlagno_N_461), 
         .Z(n5_adj_634)) /* synthesis lut_function=(A (B)) */ ;
    defparam Select_428_i5_2_lut.init = 16'h8888;
    LUT4 i3_4_lut_adj_107 (.A(outFlagnx_N_511), .B(outFlagna_N_409), .C(outFlagnx_N_512), 
         .D(outFlagna_N_410), .Z(n10_adj_635)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;
    defparam i3_4_lut_adj_107.init = 16'heca0;
    LUT4 i1_4_lut_adj_108 (.A(outFlagnota_N_562), .B(outFlago_N_307), .C(outFlagnota_N_563), 
         .D(outFlago_N_308), .Z(n8_adj_636)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;
    defparam i1_4_lut_adj_108.init = 16'heca0;
    LUT4 outnota_7__I_0_3_lut (.A(srd[7]), .B(inA0_c_7), .C(outnota_7__N_540), 
         .Z(outnota_7__N_538)) /* synthesis lut_function=(!(A (B (C))+!A (B+!(C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam outnota_7__I_0_3_lut.init = 16'h3a3a;
    LUT4 i5_4_lut_adj_109 (.A(outFlaga_N_256), .B(n10_adj_635), .C(n5_adj_634), 
         .D(outFlaga_N_257), .Z(n12_adj_637)) /* synthesis lut_function=(A (B+(C+(D)))+!A (B+(C))) */ ;
    defparam i5_4_lut_adj_109.init = 16'hfefc;
    LUT4 i6_4_lut_adj_110 (.A(outFlagx_N_358), .B(n12_adj_637), .C(n8_adj_636), 
         .D(outFlagx_N_359), .Z(n2434)) /* synthesis lut_function=(A (B+(C+(D)))+!A (B+(C))) */ ;
    defparam i6_4_lut_adj_110.init = 16'hfefc;
    LUT4 outnota_6__I_0_3_lut (.A(srd[6]), .B(inA0_c_6), .C(outnota_7__N_540), 
         .Z(outnota_7__N_548)) /* synthesis lut_function=(!(A (B (C))+!A (B+!(C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam outnota_6__I_0_3_lut.init = 16'h3a3a;
    LUT4 Select_439_i5_2_lut (.A(outx_7__N_318[4]), .B(outx_7__N_319), .Z(n5_adj_629)) /* synthesis lut_function=(A (B)) */ ;
    defparam Select_439_i5_2_lut.init = 16'h8888;
    FD1P3AX i32_167 (.D(outnota_7__N_542), .SP(outnota_7__N_540), .CK(clk0_c), 
            .Q(outnota_7__N_523)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=82, LSE_RLINE=82 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam i32_167.GSR = "ENABLED";
    LUT4 i6_4_lut_adj_111 (.A(outno_7__N_420[5]), .B(n12_adj_610), .C(n8_adj_611), 
         .D(outno_7__N_421), .Z(srd[5])) /* synthesis lut_function=(A (B+(C+(D)))+!A (B+(C))) */ ;
    defparam i6_4_lut_adj_111.init = 16'hfefc;
    LUT4 \pnota.auxnota_I_0_1_lut  (.A(\pnota.auxnota ), .Z(\pnota.auxnota_N_545 )) /* synthesis lut_function=(!(A)) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(24[10:23])
    defparam \pnota.auxnota_I_0_1_lut .init = 16'h5555;
    LUT4 outnota_5__I_0_3_lut (.A(srd[5]), .B(inA0_c_5), .C(outnota_7__N_540), 
         .Z(outnota_7__N_550)) /* synthesis lut_function=(!(A (B (C))+!A (B+!(C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam outnota_5__I_0_3_lut.init = 16'h3a3a;
    LUT4 outnota_4__I_0_3_lut (.A(srd[4]), .B(inA0_c_4), .C(outnota_7__N_540), 
         .Z(outnota_7__N_552)) /* synthesis lut_function=(!(A (B (C))+!A (B+!(C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam outnota_4__I_0_3_lut.init = 16'h3a3a;
    LUT4 i1_4_lut_adj_112 (.A(outa_7__N_216[2]), .B(outnx_7__N_471[2]), 
         .C(outa_3__N_225), .D(outnx_7__N_472), .Z(n8_adj_631)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;
    defparam i1_4_lut_adj_112.init = 16'heca0;
    LUT4 i3_4_lut_adj_113 (.A(outo_7__N_267[2]), .B(outna_7__N_369[2]), 
         .C(outo_7__N_268), .D(outna_7__N_370), .Z(n10_adj_632)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (D))) */ ;
    defparam i3_4_lut_adj_113.init = 16'heca0;
    LUT4 outnota_3__I_0_3_lut (.A(srd[3]), .B(inA0_c_3), .C(outnota_7__N_540), 
         .Z(outnota_7__N_554)) /* synthesis lut_function=(!(A (B (C))+!A (B+!(C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nota00.vhdl(21[3] 39[10])
    defparam outnota_3__I_0_3_lut.init = 16'h3a3a;
    
endmodule
//
// Verilog Description of module ram_EBR_00
//

module ram_EBR_00 (clk0_c, en0_c, re0_c, rw0_c, Address0_c_3, Address0_c_2, 
            Address0_c_1, Address0_c_0, GND_net, outCode0_c_7, outCode0_c_6, 
            outCode0_c_5, outCode0_c_4, outCode0_c_3, outCode0_c_2, 
            outCode0_c_1, outCode0_c_0, VCC_net) /* synthesis NGD_DRC_MASK=1 */ ;
    input clk0_c;
    input en0_c;
    input re0_c;
    input rw0_c;
    input Address0_c_3;
    input Address0_c_2;
    input Address0_c_1;
    input Address0_c_0;
    input GND_net;
    output outCode0_c_7;
    output outCode0_c_6;
    output outCode0_c_5;
    output outCode0_c_4;
    output outCode0_c_3;
    output outCode0_c_2;
    output outCode0_c_1;
    output outCode0_c_0;
    input VCC_net;
    
    wire clk0_c /* synthesis is_clock=1, SET_AS_NETWORK=clk0_c */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(9[4:8])
    
    DP8KC ram_EBR_00_0_0_0 (.DIA0(GND_net), .DIA1(GND_net), .DIA2(GND_net), 
          .DIA3(GND_net), .DIA4(GND_net), .DIA5(GND_net), .DIA6(GND_net), 
          .DIA7(GND_net), .DIA8(GND_net), .ADA0(VCC_net), .ADA1(GND_net), 
          .ADA2(GND_net), .ADA3(Address0_c_0), .ADA4(Address0_c_1), .ADA5(Address0_c_2), 
          .ADA6(Address0_c_3), .ADA7(GND_net), .ADA8(GND_net), .ADA9(GND_net), 
          .ADA10(GND_net), .ADA11(GND_net), .ADA12(GND_net), .CEA(en0_c), 
          .OCEA(en0_c), .CLKA(clk0_c), .WEA(rw0_c), .CSA0(GND_net), 
          .CSA1(GND_net), .CSA2(GND_net), .RSTA(re0_c), .DIB0(GND_net), 
          .DIB1(GND_net), .DIB2(GND_net), .DIB3(GND_net), .DIB4(GND_net), 
          .DIB5(GND_net), .DIB6(GND_net), .DIB7(GND_net), .DIB8(GND_net), 
          .ADB0(GND_net), .ADB1(GND_net), .ADB2(GND_net), .ADB3(GND_net), 
          .ADB4(GND_net), .ADB5(GND_net), .ADB6(GND_net), .ADB7(GND_net), 
          .ADB8(GND_net), .ADB9(GND_net), .ADB10(GND_net), .ADB11(GND_net), 
          .ADB12(GND_net), .CEB(VCC_net), .OCEB(VCC_net), .CLKB(GND_net), 
          .WEB(GND_net), .CSB0(GND_net), .CSB1(GND_net), .CSB2(GND_net), 
          .RSTB(GND_net), .DOA0(outCode0_c_0), .DOA1(outCode0_c_1), .DOA2(outCode0_c_2), 
          .DOA3(outCode0_c_3), .DOA4(outCode0_c_4), .DOA5(outCode0_c_5), 
          .DOA6(outCode0_c_6), .DOA7(outCode0_c_7)) /* synthesis MEM_LPC_FILE="ram_EBR_00.lpc", MEM_INIT_FILE="program00.mem", syn_instantiated=1, LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=18, LSE_LLINE=97, LSE_RLINE=97 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(97[8:18])
    defparam ram_EBR_00_0_0_0.DATA_WIDTH_A = 9;
    defparam ram_EBR_00_0_0_0.DATA_WIDTH_B = 9;
    defparam ram_EBR_00_0_0_0.REGMODE_A = "OUTREG";
    defparam ram_EBR_00_0_0_0.REGMODE_B = "NOREG";
    defparam ram_EBR_00_0_0_0.CSDECODE_A = "0b000";
    defparam ram_EBR_00_0_0_0.CSDECODE_B = "0b111";
    defparam ram_EBR_00_0_0_0.WRITEMODE_A = "NORMAL";
    defparam ram_EBR_00_0_0_0.WRITEMODE_B = "NORMAL";
    defparam ram_EBR_00_0_0_0.GSR = "ENABLED";
    defparam ram_EBR_00_0_0_0.RESETMODE = "SYNC";
    defparam ram_EBR_00_0_0_0.ASYNC_RESET_RELEASE = "SYNC";
    defparam ram_EBR_00_0_0_0.INIT_DATA = "STATIC";
    defparam ram_EBR_00_0_0_0.INITVAL_00 = "0x000000000000000000000000000000000000000001E0E01A0C0160A0120800E0600A040060200200";
    defparam ram_EBR_00_0_0_0.INITVAL_01 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_02 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_03 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_04 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_05 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_06 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_07 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_08 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_09 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_0A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_0B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_0C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_0D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_0E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_0F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_10 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_11 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_12 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_13 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_14 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_15 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_16 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_17 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_18 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_19 = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_1A = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_1B = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_1C = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_1D = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_1E = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    defparam ram_EBR_00_0_0_0.INITVAL_1F = "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000";
    
endmodule
//
// Verilog Description of module and00
//

module and00 (outFlaga_N_257, clk0_c, outCode0_c_0, n2837, outCode0_c_1, 
            outna_7__N_389, n2822, en0_c, srd, inA0_c_6, inB0_c_6, 
            n2824, n2814, inA0_c_5, inB0_c_5, inA0_c_4, inB0_c_4, 
            inA0_c_3, inB0_c_3, inA0_c_2, inB0_c_2, outnx_7__N_491, 
            n10, n2815, outo_7__N_287, inA0_c_1, inB0_c_1, n2833, 
            inA0_c_0, inB0_c_0, rw0_c, n2831, outa_7__N_216, outFlag0_c, 
            re0_c, clk0_c_enable_15, outx_7__N_338, n2813, outnota_7__N_542, 
            outno_7__N_440, n2821, n2829, \pnor.auxno , outno_7__N_438, 
            n2832, inA0_c_7, inB0_c_7, outCode0_c_2, outCode0_c_3, 
            outCode0_c_4, outCode0_c_6, outCode0_c_5, outCode0_c_7, 
            outFlaga_N_256, n2933, outa_3__N_225, n2812, n2818);
    output outFlaga_N_257;
    input clk0_c;
    input outCode0_c_0;
    input n2837;
    input outCode0_c_1;
    output outna_7__N_389;
    output n2822;
    input en0_c;
    input [7:0]srd;
    input inA0_c_6;
    input inB0_c_6;
    output n2824;
    output n2814;
    input inA0_c_5;
    input inB0_c_5;
    input inA0_c_4;
    input inB0_c_4;
    input inA0_c_3;
    input inB0_c_3;
    input inA0_c_2;
    input inB0_c_2;
    output outnx_7__N_491;
    output n10;
    output n2815;
    output outo_7__N_287;
    input inA0_c_1;
    input inB0_c_1;
    output n2833;
    input inA0_c_0;
    input inB0_c_0;
    input rw0_c;
    output n2831;
    output [7:0]outa_7__N_216;
    input outFlag0_c;
    input re0_c;
    output clk0_c_enable_15;
    output outx_7__N_338;
    output n2813;
    output outnota_7__N_542;
    output outno_7__N_440;
    output n2821;
    input n2829;
    input \pnor.auxno ;
    output outno_7__N_438;
    output n2832;
    input inA0_c_7;
    input inB0_c_7;
    input outCode0_c_2;
    input outCode0_c_3;
    input outCode0_c_4;
    input outCode0_c_6;
    input outCode0_c_5;
    input outCode0_c_7;
    output outFlaga_N_256;
    input n2933;
    output outa_3__N_225;
    output n2812;
    output n2818;
    
    wire clk0_c /* synthesis is_clock=1, SET_AS_NETWORK=clk0_c */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(9[4:8])
    
    wire outa_7__N_236, n2634, n2823, \pand.auxa , outa_7__N_234, 
        outa_7__N_242, outa_7__N_244, outa_7__N_246, outa_7__N_248, 
        outa_7__N_250, outa_7__N_252, outa_7__N_254, outa_7__N_232, 
        \pand.auxa_N_239 , n2828;
    
    FD1S3AX i160_175 (.D(outa_7__N_236), .CK(clk0_c), .Q(outFlaga_N_257)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=29, LSE_RLINE=29 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam i160_175.GSR = "ENABLED";
    LUT4 opcodena_7__I_0_i16_1_lut_2_lut_3_lut_4_lut (.A(outCode0_c_0), .B(n2634), 
         .C(n2837), .D(outCode0_c_1), .Z(outna_7__N_389)) /* synthesis lut_function=(!(A+(B+(C+(D))))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam opcodena_7__I_0_i16_1_lut_2_lut_3_lut_4_lut.init = 16'h0001;
    LUT4 i1_2_lut_rep_29_3_lut_4_lut (.A(outCode0_c_0), .B(n2634), .C(n2837), 
         .D(outCode0_c_1), .Z(n2822)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam i1_2_lut_rep_29_3_lut_4_lut.init = 16'hfffe;
    LUT4 outa_7__I_8_3_lut (.A(n2823), .B(en0_c), .C(\pand.auxa ), .Z(outa_7__N_234)) /* synthesis lut_function=(A+!((C)+!B)) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[4] 38[11])
    defparam outa_7__I_8_3_lut.init = 16'haeae;
    LUT4 outa_6__I_0_4_lut (.A(srd[6]), .B(inA0_c_6), .C(outa_7__N_234), 
         .D(inB0_c_6), .Z(outa_7__N_242)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C))+!A (B (C (D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam outa_6__I_0_4_lut.init = 16'hca0a;
    LUT4 i1_2_lut_rep_31_3_lut (.A(outCode0_c_0), .B(n2634), .C(outCode0_c_1), 
         .Z(n2824)) /* synthesis lut_function=(A+(B+!(C))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam i1_2_lut_rep_31_3_lut.init = 16'hefef;
    LUT4 i1_2_lut_rep_21_3_lut_4_lut (.A(outCode0_c_0), .B(n2634), .C(n2837), 
         .D(outCode0_c_1), .Z(n2814)) /* synthesis lut_function=(A+(B+(C+!(D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam i1_2_lut_rep_21_3_lut_4_lut.init = 16'hfeff;
    LUT4 outa_5__I_0_4_lut (.A(srd[5]), .B(inA0_c_5), .C(outa_7__N_234), 
         .D(inB0_c_5), .Z(outa_7__N_244)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C))+!A (B (C (D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam outa_5__I_0_4_lut.init = 16'hca0a;
    LUT4 outa_4__I_0_4_lut (.A(srd[4]), .B(inA0_c_4), .C(outa_7__N_234), 
         .D(inB0_c_4), .Z(outa_7__N_246)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C))+!A (B (C (D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam outa_4__I_0_4_lut.init = 16'hca0a;
    LUT4 outa_3__I_0_4_lut (.A(srd[3]), .B(inA0_c_3), .C(outa_7__N_234), 
         .D(inB0_c_3), .Z(outa_7__N_248)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C))+!A (B (C (D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam outa_3__I_0_4_lut.init = 16'hca0a;
    LUT4 outa_2__I_0_4_lut (.A(srd[2]), .B(inA0_c_2), .C(outa_7__N_234), 
         .D(inB0_c_2), .Z(outa_7__N_250)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C))+!A (B (C (D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam outa_2__I_0_4_lut.init = 16'hca0a;
    LUT4 opcodenx_7__I_0_i16_1_lut_2_lut_3_lut_4_lut (.A(outCode0_c_0), .B(n2634), 
         .C(n2837), .D(outCode0_c_1), .Z(outnx_7__N_491)) /* synthesis lut_function=(!(A+(B+(C+!(D))))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam opcodenx_7__I_0_i16_1_lut_2_lut_3_lut_4_lut.init = 16'h0100;
    LUT4 i1_2_lut_rep_22_3_lut_4_lut (.A(outCode0_c_0), .B(n2634), .C(n10), 
         .D(outCode0_c_1), .Z(n2815)) /* synthesis lut_function=(A+(B+(C+!(D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam i1_2_lut_rep_22_3_lut_4_lut.init = 16'hfeff;
    LUT4 opcodeo_7__I_0_i16_1_lut_2_lut_3_lut_4_lut (.A(outCode0_c_0), .B(n2634), 
         .C(n10), .D(outCode0_c_1), .Z(outo_7__N_287)) /* synthesis lut_function=(!(A+(B+(C+!(D))))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam opcodeo_7__I_0_i16_1_lut_2_lut_3_lut_4_lut.init = 16'h0100;
    LUT4 outa_1__I_0_4_lut (.A(srd[1]), .B(inA0_c_1), .C(outa_7__N_234), 
         .D(inB0_c_1), .Z(outa_7__N_252)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C))+!A (B (C (D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam outa_1__I_0_4_lut.init = 16'hca0a;
    LUT4 i254_1_lut_rep_40 (.A(en0_c), .Z(n2833)) /* synthesis lut_function=(!(A)) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(11[9:12])
    defparam i254_1_lut_rep_40.init = 16'h5555;
    LUT4 outa_0__I_0_4_lut (.A(srd[0]), .B(inA0_c_0), .C(outa_7__N_234), 
         .D(inB0_c_0), .Z(outa_7__N_254)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C))+!A (B (C (D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam outa_0__I_0_4_lut.init = 16'hca0a;
    LUT4 i594_2_lut_rep_38_2_lut (.A(en0_c), .B(rw0_c), .Z(n2831)) /* synthesis lut_function=((B)+!A) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(11[9:12])
    defparam i594_2_lut_rep_38_2_lut.init = 16'hdddd;
    FD1S3AX outa_i7 (.D(outa_7__N_232), .CK(clk0_c), .Q(outa_7__N_216[7])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=29, LSE_RLINE=29 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam outa_i7.GSR = "ENABLED";
    FD1S3AX outa_i6 (.D(outa_7__N_242), .CK(clk0_c), .Q(outa_7__N_216[6])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=29, LSE_RLINE=29 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam outa_i6.GSR = "ENABLED";
    FD1S3AX outa_i5 (.D(outa_7__N_244), .CK(clk0_c), .Q(outa_7__N_216[5])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=29, LSE_RLINE=29 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam outa_i5.GSR = "ENABLED";
    FD1S3AX outa_i4 (.D(outa_7__N_246), .CK(clk0_c), .Q(outa_7__N_216[4])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=29, LSE_RLINE=29 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam outa_i4.GSR = "ENABLED";
    FD1S3AX outa_i3 (.D(outa_7__N_248), .CK(clk0_c), .Q(outa_7__N_216[3])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=29, LSE_RLINE=29 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam outa_i3.GSR = "ENABLED";
    FD1S3AX outa_i2 (.D(outa_7__N_250), .CK(clk0_c), .Q(outa_7__N_216[2])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=29, LSE_RLINE=29 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam outa_i2.GSR = "ENABLED";
    FD1S3AX outa_i1 (.D(outa_7__N_252), .CK(clk0_c), .Q(outa_7__N_216[1])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=29, LSE_RLINE=29 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam outa_i1.GSR = "ENABLED";
    FD1S3AX outa_i0 (.D(outa_7__N_254), .CK(clk0_c), .Q(outa_7__N_216[0])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=29, LSE_RLINE=29 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam outa_i0.GSR = "ENABLED";
    LUT4 \pand.auxa_I_0_1_lut  (.A(\pand.auxa ), .Z(\pand.auxa_N_239 )) /* synthesis lut_function=(!(A)) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(24[10:20])
    defparam \pand.auxa_I_0_1_lut .init = 16'h5555;
    LUT4 i2195_2_lut_2_lut_3_lut_4_lut_4_lut_4_lut (.A(en0_c), .B(outFlag0_c), 
         .C(rw0_c), .D(re0_c), .Z(clk0_c_enable_15)) /* synthesis lut_function=(!(A (B (C)+!B !(C (D)))+!A (B+(C+(D))))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(11[9:12])
    defparam i2195_2_lut_2_lut_3_lut_4_lut_4_lut_4_lut.init = 16'h2809;
    LUT4 opcodex_7__I_0_i16_1_lut_2_lut_3_lut_4_lut (.A(outCode0_c_0), .B(n2634), 
         .C(n10), .D(outCode0_c_1), .Z(outx_7__N_338)) /* synthesis lut_function=(!((B+(C+!(D)))+!A)) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam opcodex_7__I_0_i16_1_lut_2_lut_3_lut_4_lut.init = 16'h0200;
    LUT4 i1_2_lut_rep_20_3_lut_4_lut (.A(outCode0_c_0), .B(n2634), .C(n2837), 
         .D(outCode0_c_1), .Z(n2813)) /* synthesis lut_function=((B+(C+!(D)))+!A) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam i1_2_lut_rep_20_3_lut_4_lut.init = 16'hfdff;
    LUT4 opcodenota_7__I_0_i16_1_lut_2_lut_3_lut_4_lut (.A(outCode0_c_0), 
         .B(n2634), .C(n2837), .D(outCode0_c_1), .Z(outnota_7__N_542)) /* synthesis lut_function=(!((B+(C+!(D)))+!A)) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam opcodenota_7__I_0_i16_1_lut_2_lut_3_lut_4_lut.init = 16'h0200;
    LUT4 i2_3_lut_rep_30_4_lut (.A(outCode0_c_0), .B(n2634), .C(outCode0_c_1), 
         .D(n10), .Z(n2823)) /* synthesis lut_function=((B+(C+(D)))+!A) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam i2_3_lut_rep_30_4_lut.init = 16'hfffd;
    LUT4 opcodea_7__I_0_i16_1_lut_3_lut_4_lut (.A(outCode0_c_0), .B(n2634), 
         .C(outCode0_c_1), .D(n10), .Z(outa_7__N_236)) /* synthesis lut_function=(!((B+(C+(D)))+!A)) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam opcodea_7__I_0_i16_1_lut_3_lut_4_lut.init = 16'h0002;
    LUT4 opcodeno_7__I_0_i16_1_lut_2_lut_3_lut_4_lut (.A(outCode0_c_1), .B(n2837), 
         .C(n2634), .D(outCode0_c_0), .Z(outno_7__N_440)) /* synthesis lut_function=(!(A+(B+(C+!(D))))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam opcodeno_7__I_0_i16_1_lut_2_lut_3_lut_4_lut.init = 16'h0100;
    LUT4 i1_2_lut_rep_28_3_lut_4_lut (.A(outCode0_c_1), .B(n2837), .C(n2634), 
         .D(outCode0_c_0), .Z(n2821)) /* synthesis lut_function=(A+(B+(C+!(D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam i1_2_lut_rep_28_3_lut_4_lut.init = 16'hfeff;
    LUT4 outno_7__I_44_3_lut_4_lut (.A(n2828), .B(n2829), .C(\pnor.auxno ), 
         .D(en0_c), .Z(outno_7__N_438)) /* synthesis lut_function=(A+(B+!(C+!(D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam outno_7__I_44_3_lut_4_lut.init = 16'hefee;
    LUT4 i1_2_lut_rep_39 (.A(outCode0_c_0), .B(n2634), .Z(n2832)) /* synthesis lut_function=(A+(B)) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam i1_2_lut_rep_39.init = 16'heeee;
    LUT4 outa_7__I_0_4_lut (.A(srd[7]), .B(inA0_c_7), .C(outa_7__N_234), 
         .D(inB0_c_7), .Z(outa_7__N_232)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C))+!A (B (C (D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam outa_7__I_0_4_lut.init = 16'hca0a;
    LUT4 opcodea_7__I_0_i10_2_lut (.A(outCode0_c_2), .B(outCode0_c_3), .Z(n10)) /* synthesis lut_function=(A+(B)) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam opcodea_7__I_0_i10_2_lut.init = 16'heeee;
    LUT4 i3_4_lut (.A(outCode0_c_4), .B(outCode0_c_6), .C(outCode0_c_5), 
         .D(outCode0_c_7), .Z(n2634)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam i3_4_lut.init = 16'hfffe;
    FD1S3IX outFlaga_166 (.D(\pand.auxa_N_239 ), .CK(clk0_c), .CD(n2833), 
            .Q(outFlaga_N_256)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=29, LSE_RLINE=29 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam outFlaga_166.GSR = "ENABLED";
    FD1P3IX \pand.auxa_164  (.D(n2933), .SP(en0_c), .CD(n2823), .CK(clk0_c), 
            .Q(\pand.auxa )) /* synthesis lse_init_val=0, LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=29, LSE_RLINE=29 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam \pand.auxa_164 .GSR = "ENABLED";
    FD1P3AX i96_171 (.D(outa_7__N_236), .SP(outa_7__N_234), .CK(clk0_c), 
            .Q(outa_3__N_225)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=29, LSE_RLINE=29 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(21[3] 39[10])
    defparam i96_171.GSR = "ENABLED";
    LUT4 i1_2_lut_rep_35 (.A(outCode0_c_0), .B(n2634), .Z(n2828)) /* synthesis lut_function=((B)+!A) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam i1_2_lut_rep_35.init = 16'hdddd;
    LUT4 i1_2_lut_rep_19_3_lut_4_lut (.A(outCode0_c_0), .B(n2634), .C(n10), 
         .D(outCode0_c_1), .Z(n2812)) /* synthesis lut_function=((B+(C+!(D)))+!A) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam i1_2_lut_rep_19_3_lut_4_lut.init = 16'hfdff;
    LUT4 i1_2_lut_rep_25_3_lut (.A(outCode0_c_0), .B(n2634), .C(outCode0_c_1), 
         .Z(n2818)) /* synthesis lut_function=((B+!(C))+!A) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/and00.vhdl(22[8:28])
    defparam i1_2_lut_rep_25_3_lut.init = 16'hdfdf;
    
endmodule
//
// Verilog Description of module xor00
//

module xor00 (outx_7__N_318, clk0_c, outFlagx_N_359, outx_7__N_338, 
            n10, n2818, en0_c, n2837, \pnota.auxnota , outnota_7__N_540, 
            n2812, n2933, srd, inA0_c_0, inB0_c_0, inA0_c_7, inB0_c_7, 
            inA0_c_6, inB0_c_6, inA0_c_5, inB0_c_5, inA0_c_4, inB0_c_4, 
            inA0_c_3, inB0_c_3, inA0_c_2, inB0_c_2, inA0_c_1, inB0_c_1, 
            outFlagx_N_358, n2833, outx_7__N_319);
    output [7:0]outx_7__N_318;
    input clk0_c;
    output outFlagx_N_359;
    input outx_7__N_338;
    input n10;
    input n2818;
    input en0_c;
    input n2837;
    input \pnota.auxnota ;
    output outnota_7__N_540;
    input n2812;
    input n2933;
    input [7:0]srd;
    input inA0_c_0;
    input inB0_c_0;
    input inA0_c_7;
    input inB0_c_7;
    input inA0_c_6;
    input inB0_c_6;
    input inA0_c_5;
    input inB0_c_5;
    input inA0_c_4;
    input inB0_c_4;
    input inA0_c_3;
    input inB0_c_3;
    input inA0_c_2;
    input inB0_c_2;
    input inA0_c_1;
    input inB0_c_1;
    output outFlagx_N_358;
    input n2833;
    output outx_7__N_319;
    
    wire clk0_c /* synthesis is_clock=1, SET_AS_NETWORK=clk0_c */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(9[4:8])
    
    wire outx_7__N_356, \pxor.auxxor , outx_7__N_336, \pxor.auxxor_N_341 , 
        outx_7__N_334, outx_7__N_344, outx_7__N_346, outx_7__N_348, 
        outx_7__N_350, outx_7__N_352, outx_7__N_354;
    
    FD1S3AX outx_i0 (.D(outx_7__N_356), .CK(clk0_c), .Q(outx_7__N_318[0])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=47, LSE_RLINE=47 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam outx_i0.GSR = "ENABLED";
    FD1S3AX i160_175 (.D(outx_7__N_338), .CK(clk0_c), .Q(outFlagx_N_359)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=47, LSE_RLINE=47 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam i160_175.GSR = "ENABLED";
    LUT4 outx_7__I_26_3_lut_4_lut (.A(n10), .B(n2818), .C(\pxor.auxxor ), 
         .D(en0_c), .Z(outx_7__N_336)) /* synthesis lut_function=(A+(B+!(C+!(D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(22[8:28])
    defparam outx_7__I_26_3_lut_4_lut.init = 16'hefee;
    LUT4 outnota_7__I_62_3_lut_4_lut (.A(n2837), .B(n2818), .C(\pnota.auxnota ), 
         .D(en0_c), .Z(outnota_7__N_540)) /* synthesis lut_function=(A+(B+!(C+!(D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(22[8:28])
    defparam outnota_7__I_62_3_lut_4_lut.init = 16'hefee;
    FD1P3IX \pxor.auxxor_164  (.D(n2933), .SP(en0_c), .CD(n2812), .CK(clk0_c), 
            .Q(\pxor.auxxor )) /* synthesis lse_init_val=0, LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=47, LSE_RLINE=47 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam \pxor.auxxor_164 .GSR = "ENABLED";
    LUT4 \pxor.auxxor_I_0_1_lut  (.A(\pxor.auxxor ), .Z(\pxor.auxxor_N_341 )) /* synthesis lut_function=(!(A)) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(24[10:22])
    defparam \pxor.auxxor_I_0_1_lut .init = 16'h5555;
    LUT4 outx_0__I_0_4_lut (.A(srd[0]), .B(inA0_c_0), .C(outx_7__N_336), 
         .D(inB0_c_0), .Z(outx_7__N_356)) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam outx_0__I_0_4_lut.init = 16'h3aca;
    LUT4 outx_7__I_0_4_lut (.A(srd[7]), .B(inA0_c_7), .C(outx_7__N_336), 
         .D(inB0_c_7), .Z(outx_7__N_334)) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam outx_7__I_0_4_lut.init = 16'h3aca;
    LUT4 outx_6__I_0_4_lut (.A(srd[6]), .B(inA0_c_6), .C(outx_7__N_336), 
         .D(inB0_c_6), .Z(outx_7__N_344)) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam outx_6__I_0_4_lut.init = 16'h3aca;
    LUT4 outx_5__I_0_4_lut (.A(srd[5]), .B(inA0_c_5), .C(outx_7__N_336), 
         .D(inB0_c_5), .Z(outx_7__N_346)) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam outx_5__I_0_4_lut.init = 16'h3aca;
    LUT4 outx_4__I_0_4_lut (.A(srd[4]), .B(inA0_c_4), .C(outx_7__N_336), 
         .D(inB0_c_4), .Z(outx_7__N_348)) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam outx_4__I_0_4_lut.init = 16'h3aca;
    LUT4 outx_3__I_0_4_lut (.A(srd[3]), .B(inA0_c_3), .C(outx_7__N_336), 
         .D(inB0_c_3), .Z(outx_7__N_350)) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam outx_3__I_0_4_lut.init = 16'h3aca;
    LUT4 outx_2__I_0_4_lut (.A(srd[2]), .B(inA0_c_2), .C(outx_7__N_336), 
         .D(inB0_c_2), .Z(outx_7__N_352)) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam outx_2__I_0_4_lut.init = 16'h3aca;
    LUT4 outx_1__I_0_4_lut (.A(srd[1]), .B(inA0_c_1), .C(outx_7__N_336), 
         .D(inB0_c_1), .Z(outx_7__N_354)) /* synthesis lut_function=(!(A (B (C (D))+!B !((D)+!C))+!A (B ((D)+!C)+!B !(C (D))))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam outx_1__I_0_4_lut.init = 16'h3aca;
    FD1S3IX outFlagx_166 (.D(\pxor.auxxor_N_341 ), .CK(clk0_c), .CD(n2833), 
            .Q(outFlagx_N_358)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=47, LSE_RLINE=47 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam outFlagx_166.GSR = "ENABLED";
    FD1P3AX i32_167 (.D(outx_7__N_338), .SP(outx_7__N_336), .CK(clk0_c), 
            .Q(outx_7__N_319)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=47, LSE_RLINE=47 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam i32_167.GSR = "ENABLED";
    FD1S3AX outx_i7 (.D(outx_7__N_334), .CK(clk0_c), .Q(outx_7__N_318[7])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=47, LSE_RLINE=47 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam outx_i7.GSR = "ENABLED";
    FD1S3AX outx_i6 (.D(outx_7__N_344), .CK(clk0_c), .Q(outx_7__N_318[6])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=47, LSE_RLINE=47 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam outx_i6.GSR = "ENABLED";
    FD1S3AX outx_i5 (.D(outx_7__N_346), .CK(clk0_c), .Q(outx_7__N_318[5])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=47, LSE_RLINE=47 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam outx_i5.GSR = "ENABLED";
    FD1S3AX outx_i4 (.D(outx_7__N_348), .CK(clk0_c), .Q(outx_7__N_318[4])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=47, LSE_RLINE=47 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam outx_i4.GSR = "ENABLED";
    FD1S3AX outx_i3 (.D(outx_7__N_350), .CK(clk0_c), .Q(outx_7__N_318[3])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=47, LSE_RLINE=47 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam outx_i3.GSR = "ENABLED";
    FD1S3AX outx_i2 (.D(outx_7__N_352), .CK(clk0_c), .Q(outx_7__N_318[2])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=47, LSE_RLINE=47 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam outx_i2.GSR = "ENABLED";
    FD1S3AX outx_i1 (.D(outx_7__N_354), .CK(clk0_c), .Q(outx_7__N_318[1])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=47, LSE_RLINE=47 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xor00.vhdl(21[3] 39[10])
    defparam outx_i1.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module nor00
//

module nor00 (srd, inA0_c_3, outno_7__N_438, inB0_c_3, outno_7__N_420, 
            clk0_c, outFlagno_N_461, outno_7__N_440, outFlagno_N_460, 
            n2833, \pnor.auxno , en0_c, n2821, n2933, inA0_c_4, 
            inB0_c_4, inA0_c_6, inB0_c_6, inA0_c_0, inB0_c_0, inA0_c_1, 
            inB0_c_1, inA0_c_2, inB0_c_2, inA0_c_7, inB0_c_7, outno_7__N_421, 
            inA0_c_5, inB0_c_5);
    input [7:0]srd;
    input inA0_c_3;
    input outno_7__N_438;
    input inB0_c_3;
    output [7:0]outno_7__N_420;
    input clk0_c;
    output outFlagno_N_461;
    input outno_7__N_440;
    output outFlagno_N_460;
    input n2833;
    output \pnor.auxno ;
    input en0_c;
    input n2821;
    input n2933;
    input inA0_c_4;
    input inB0_c_4;
    input inA0_c_6;
    input inB0_c_6;
    input inA0_c_0;
    input inB0_c_0;
    input inA0_c_1;
    input inB0_c_1;
    input inA0_c_2;
    input inB0_c_2;
    input inA0_c_7;
    input inB0_c_7;
    output outno_7__N_421;
    input inA0_c_5;
    input inB0_c_5;
    
    wire clk0_c /* synthesis is_clock=1, SET_AS_NETWORK=clk0_c */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(9[4:8])
    
    wire outno_7__N_452, outno_7__N_446, outno_7__N_448, outno_7__N_450, 
        outno_7__N_454, outno_7__N_458, outno_7__N_456, \pnor.auxno_N_443 , 
        outno_7__N_436;
    
    LUT4 outno_3__I_0_4_lut (.A(srd[3]), .B(inA0_c_3), .C(outno_7__N_438), 
         .D(inB0_c_3), .Z(outno_7__N_452)) /* synthesis lut_function=(!(A (B (C)+!B (C (D)))+!A (B+((D)+!C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam outno_3__I_0_4_lut.init = 16'h0a3a;
    FD1S3AX outno_i6 (.D(outno_7__N_446), .CK(clk0_c), .Q(outno_7__N_420[6])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=65, LSE_RLINE=65 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam outno_i6.GSR = "ENABLED";
    FD1S3AX outno_i5 (.D(outno_7__N_448), .CK(clk0_c), .Q(outno_7__N_420[5])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=65, LSE_RLINE=65 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam outno_i5.GSR = "ENABLED";
    FD1S3AX outno_i4 (.D(outno_7__N_450), .CK(clk0_c), .Q(outno_7__N_420[4])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=65, LSE_RLINE=65 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam outno_i4.GSR = "ENABLED";
    FD1S3AX outno_i3 (.D(outno_7__N_452), .CK(clk0_c), .Q(outno_7__N_420[3])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=65, LSE_RLINE=65 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam outno_i3.GSR = "ENABLED";
    FD1S3AX outno_i2 (.D(outno_7__N_454), .CK(clk0_c), .Q(outno_7__N_420[2])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=65, LSE_RLINE=65 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam outno_i2.GSR = "ENABLED";
    FD1S3AX outno_i0 (.D(outno_7__N_458), .CK(clk0_c), .Q(outno_7__N_420[0])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=65, LSE_RLINE=65 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam outno_i0.GSR = "ENABLED";
    FD1S3AX outno_i1 (.D(outno_7__N_456), .CK(clk0_c), .Q(outno_7__N_420[1])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=65, LSE_RLINE=65 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam outno_i1.GSR = "ENABLED";
    FD1S3AX i160_175 (.D(outno_7__N_440), .CK(clk0_c), .Q(outFlagno_N_461)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=65, LSE_RLINE=65 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam i160_175.GSR = "ENABLED";
    FD1S3IX outFlagno_166 (.D(\pnor.auxno_N_443 ), .CK(clk0_c), .CD(n2833), 
            .Q(outFlagno_N_460)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=65, LSE_RLINE=65 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam outFlagno_166.GSR = "ENABLED";
    FD1P3IX \pnor.auxno_164  (.D(n2933), .SP(en0_c), .CD(n2821), .CK(clk0_c), 
            .Q(\pnor.auxno )) /* synthesis lse_init_val=0, LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=65, LSE_RLINE=65 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam \pnor.auxno_164 .GSR = "ENABLED";
    LUT4 outno_4__I_0_4_lut (.A(srd[4]), .B(inA0_c_4), .C(outno_7__N_438), 
         .D(inB0_c_4), .Z(outno_7__N_450)) /* synthesis lut_function=(!(A (B (C)+!B (C (D)))+!A (B+((D)+!C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam outno_4__I_0_4_lut.init = 16'h0a3a;
    LUT4 \pnor.auxno_I_0_1_lut  (.A(\pnor.auxno ), .Z(\pnor.auxno_N_443 )) /* synthesis lut_function=(!(A)) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(24[10:21])
    defparam \pnor.auxno_I_0_1_lut .init = 16'h5555;
    LUT4 outno_6__I_0_4_lut (.A(srd[6]), .B(inA0_c_6), .C(outno_7__N_438), 
         .D(inB0_c_6), .Z(outno_7__N_446)) /* synthesis lut_function=(!(A (B (C)+!B (C (D)))+!A (B+((D)+!C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam outno_6__I_0_4_lut.init = 16'h0a3a;
    FD1S3AX outno_i7 (.D(outno_7__N_436), .CK(clk0_c), .Q(outno_7__N_420[7])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=65, LSE_RLINE=65 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam outno_i7.GSR = "ENABLED";
    LUT4 outno_0__I_0_4_lut (.A(srd[0]), .B(inA0_c_0), .C(outno_7__N_438), 
         .D(inB0_c_0), .Z(outno_7__N_458)) /* synthesis lut_function=(!(A (B (C)+!B (C (D)))+!A (B+((D)+!C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam outno_0__I_0_4_lut.init = 16'h0a3a;
    LUT4 outno_1__I_0_4_lut (.A(srd[1]), .B(inA0_c_1), .C(outno_7__N_438), 
         .D(inB0_c_1), .Z(outno_7__N_456)) /* synthesis lut_function=(!(A (B (C)+!B (C (D)))+!A (B+((D)+!C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam outno_1__I_0_4_lut.init = 16'h0a3a;
    LUT4 outno_2__I_0_4_lut (.A(srd[2]), .B(inA0_c_2), .C(outno_7__N_438), 
         .D(inB0_c_2), .Z(outno_7__N_454)) /* synthesis lut_function=(!(A (B (C)+!B (C (D)))+!A (B+((D)+!C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam outno_2__I_0_4_lut.init = 16'h0a3a;
    LUT4 outno_7__I_0_4_lut (.A(srd[7]), .B(inA0_c_7), .C(outno_7__N_438), 
         .D(inB0_c_7), .Z(outno_7__N_436)) /* synthesis lut_function=(!(A (B (C)+!B (C (D)))+!A (B+((D)+!C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam outno_7__I_0_4_lut.init = 16'h0a3a;
    FD1P3AX i32_167 (.D(outno_7__N_440), .SP(outno_7__N_438), .CK(clk0_c), 
            .Q(outno_7__N_421)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=13, LSE_LLINE=65, LSE_RLINE=65 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam i32_167.GSR = "ENABLED";
    LUT4 outno_5__I_0_4_lut (.A(srd[5]), .B(inA0_c_5), .C(outno_7__N_438), 
         .D(inB0_c_5), .Z(outno_7__N_448)) /* synthesis lut_function=(!(A (B (C)+!B (C (D)))+!A (B+((D)+!C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nor00.vhdl(21[3] 39[10])
    defparam outno_5__I_0_4_lut.init = 16'h0a3a;
    
endmodule
//
// Verilog Description of module nand00
//

module nand00 (outna_7__N_369, clk0_c, outFlagna_N_410, outna_7__N_389, 
            outCode0_c_2, outCode0_c_3, n2837, outCode0_c_1, n2829, 
            srd, inA0_c_7, outna_7__N_387, inB0_c_7, inA0_c_6, inB0_c_6, 
            inA0_c_5, inB0_c_5, inA0_c_4, inB0_c_4, inA0_c_3, inB0_c_3, 
            outFlagna_N_409, n2833, \pnand.auxna , en0_c, n2822, n2933, 
            inA0_c_2, inB0_c_2, inA0_c_1, inB0_c_1, inA0_c_0, inB0_c_0, 
            outna_7__N_370);
    output [7:0]outna_7__N_369;
    input clk0_c;
    output outFlagna_N_410;
    input outna_7__N_389;
    input outCode0_c_2;
    input outCode0_c_3;
    output n2837;
    input outCode0_c_1;
    output n2829;
    input [7:0]srd;
    input inA0_c_7;
    input outna_7__N_387;
    input inB0_c_7;
    input inA0_c_6;
    input inB0_c_6;
    input inA0_c_5;
    input inB0_c_5;
    input inA0_c_4;
    input inB0_c_4;
    input inA0_c_3;
    input inB0_c_3;
    output outFlagna_N_409;
    input n2833;
    output \pnand.auxna ;
    input en0_c;
    input n2822;
    input n2933;
    input inA0_c_2;
    input inB0_c_2;
    input inA0_c_1;
    input inB0_c_1;
    input inA0_c_0;
    input inB0_c_0;
    output outna_7__N_370;
    
    wire clk0_c /* synthesis is_clock=1, SET_AS_NETWORK=clk0_c */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(9[4:8])
    
    wire outna_7__N_407, outna_7__N_385, outna_7__N_395, outna_7__N_397, 
        outna_7__N_399, outna_7__N_401, \pnand.auxna_N_392 , outna_7__N_403, 
        outna_7__N_405;
    
    FD1S3AX outna_i0 (.D(outna_7__N_407), .CK(clk0_c), .Q(outna_7__N_369[0])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=56, LSE_RLINE=56 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam outna_i0.GSR = "ENABLED";
    FD1S3AX i160_175 (.D(outna_7__N_389), .CK(clk0_c), .Q(outFlagna_N_410)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=56, LSE_RLINE=56 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam i160_175.GSR = "ENABLED";
    LUT4 opcodena_7__I_0_i10_2_lut_rep_44 (.A(outCode0_c_2), .B(outCode0_c_3), 
         .Z(n2837)) /* synthesis lut_function=((B)+!A) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(22[8:29])
    defparam opcodena_7__I_0_i10_2_lut_rep_44.init = 16'hdddd;
    LUT4 i1_2_lut_rep_36_3_lut (.A(outCode0_c_2), .B(outCode0_c_3), .C(outCode0_c_1), 
         .Z(n2829)) /* synthesis lut_function=((B+(C))+!A) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(22[8:29])
    defparam i1_2_lut_rep_36_3_lut.init = 16'hfdfd;
    LUT4 outna_7__I_0_4_lut (.A(srd[7]), .B(inA0_c_7), .C(outna_7__N_387), 
         .D(inB0_c_7), .Z(outna_7__N_385)) /* synthesis lut_function=(!(A (B (C (D)))+!A (B ((D)+!C)+!B !(C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam outna_7__I_0_4_lut.init = 16'h3afa;
    LUT4 outna_6__I_0_4_lut (.A(srd[6]), .B(inA0_c_6), .C(outna_7__N_387), 
         .D(inB0_c_6), .Z(outna_7__N_395)) /* synthesis lut_function=(!(A (B (C (D)))+!A (B ((D)+!C)+!B !(C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam outna_6__I_0_4_lut.init = 16'h3afa;
    LUT4 outna_5__I_0_4_lut (.A(srd[5]), .B(inA0_c_5), .C(outna_7__N_387), 
         .D(inB0_c_5), .Z(outna_7__N_397)) /* synthesis lut_function=(!(A (B (C (D)))+!A (B ((D)+!C)+!B !(C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam outna_5__I_0_4_lut.init = 16'h3afa;
    LUT4 outna_4__I_0_4_lut (.A(srd[4]), .B(inA0_c_4), .C(outna_7__N_387), 
         .D(inB0_c_4), .Z(outna_7__N_399)) /* synthesis lut_function=(!(A (B (C (D)))+!A (B ((D)+!C)+!B !(C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam outna_4__I_0_4_lut.init = 16'h3afa;
    LUT4 outna_3__I_0_4_lut (.A(srd[3]), .B(inA0_c_3), .C(outna_7__N_387), 
         .D(inB0_c_3), .Z(outna_7__N_401)) /* synthesis lut_function=(!(A (B (C (D)))+!A (B ((D)+!C)+!B !(C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam outna_3__I_0_4_lut.init = 16'h3afa;
    FD1S3IX outFlagna_166 (.D(\pnand.auxna_N_392 ), .CK(clk0_c), .CD(n2833), 
            .Q(outFlagna_N_409)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=56, LSE_RLINE=56 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam outFlagna_166.GSR = "ENABLED";
    FD1P3IX \pnand.auxna_164  (.D(n2933), .SP(en0_c), .CD(n2822), .CK(clk0_c), 
            .Q(\pnand.auxna )) /* synthesis lse_init_val=0, LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=56, LSE_RLINE=56 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam \pnand.auxna_164 .GSR = "ENABLED";
    LUT4 outna_2__I_0_4_lut (.A(srd[2]), .B(inA0_c_2), .C(outna_7__N_387), 
         .D(inB0_c_2), .Z(outna_7__N_403)) /* synthesis lut_function=(!(A (B (C (D)))+!A (B ((D)+!C)+!B !(C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam outna_2__I_0_4_lut.init = 16'h3afa;
    LUT4 outna_1__I_0_4_lut (.A(srd[1]), .B(inA0_c_1), .C(outna_7__N_387), 
         .D(inB0_c_1), .Z(outna_7__N_405)) /* synthesis lut_function=(!(A (B (C (D)))+!A (B ((D)+!C)+!B !(C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam outna_1__I_0_4_lut.init = 16'h3afa;
    LUT4 outna_0__I_0_4_lut (.A(srd[0]), .B(inA0_c_0), .C(outna_7__N_387), 
         .D(inB0_c_0), .Z(outna_7__N_407)) /* synthesis lut_function=(!(A (B (C (D)))+!A (B ((D)+!C)+!B !(C)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam outna_0__I_0_4_lut.init = 16'h3afa;
    LUT4 \pnand.auxna_I_0_1_lut  (.A(\pnand.auxna ), .Z(\pnand.auxna_N_392 )) /* synthesis lut_function=(!(A)) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(24[10:21])
    defparam \pnand.auxna_I_0_1_lut .init = 16'h5555;
    FD1S3AX outna_i7 (.D(outna_7__N_385), .CK(clk0_c), .Q(outna_7__N_369[7])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=56, LSE_RLINE=56 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam outna_i7.GSR = "ENABLED";
    FD1S3AX outna_i6 (.D(outna_7__N_395), .CK(clk0_c), .Q(outna_7__N_369[6])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=56, LSE_RLINE=56 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam outna_i6.GSR = "ENABLED";
    FD1S3AX outna_i5 (.D(outna_7__N_397), .CK(clk0_c), .Q(outna_7__N_369[5])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=56, LSE_RLINE=56 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam outna_i5.GSR = "ENABLED";
    FD1S3AX outna_i4 (.D(outna_7__N_399), .CK(clk0_c), .Q(outna_7__N_369[4])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=56, LSE_RLINE=56 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam outna_i4.GSR = "ENABLED";
    FD1S3AX outna_i3 (.D(outna_7__N_401), .CK(clk0_c), .Q(outna_7__N_369[3])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=56, LSE_RLINE=56 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam outna_i3.GSR = "ENABLED";
    FD1S3AX outna_i2 (.D(outna_7__N_403), .CK(clk0_c), .Q(outna_7__N_369[2])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=56, LSE_RLINE=56 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam outna_i2.GSR = "ENABLED";
    FD1P3AX i32_167 (.D(outna_7__N_389), .SP(outna_7__N_387), .CK(clk0_c), 
            .Q(outna_7__N_370)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=56, LSE_RLINE=56 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam i32_167.GSR = "ENABLED";
    FD1S3AX outna_i1 (.D(outna_7__N_405), .CK(clk0_c), .Q(outna_7__N_369[1])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=56, LSE_RLINE=56 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/nand00.vhdl(21[3] 39[10])
    defparam outna_i1.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module osc00
//

module osc00 (GND_net, cdiv0_c_2, clk0_c, cdiv0_c_5, cdiv0_c_4, cdiv0_c_0, 
            cdiv0_c_3, cdiv0_c_1);
    input GND_net;
    input cdiv0_c_2;
    output clk0_c;
    input cdiv0_c_5;
    input cdiv0_c_4;
    input cdiv0_c_0;
    input cdiv0_c_3;
    input cdiv0_c_1;
    
    wire clk0_c /* synthesis is_clock=1, SET_AS_NETWORK=clk0_c */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(9[4:8])
    wire sclk /* synthesis SET_AS_NETWORK=\AL00/sclk, is_clock=1 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/01-osc00vhdl/osc00.vhdl(14[8:12])
    
    div00 O01 (.GND_net(GND_net), .cdiv0_c_2(cdiv0_c_2), .clk0_c(clk0_c), 
          .sclk(sclk), .cdiv0_c_5(cdiv0_c_5), .cdiv0_c_4(cdiv0_c_4), .cdiv0_c_0(cdiv0_c_0), 
          .cdiv0_c_3(cdiv0_c_3), .cdiv0_c_1(cdiv0_c_1));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/01-osc00vhdl/osc00.vhdl(18[7:12])
    oscint00 O00 (.GND_net(GND_net), .sclk(sclk));   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/01-osc00vhdl/osc00.vhdl(16[7:15])
    
endmodule
//
// Verilog Description of module div00
//

module div00 (GND_net, cdiv0_c_2, clk0_c, sclk, cdiv0_c_5, cdiv0_c_4, 
            cdiv0_c_0, cdiv0_c_3, cdiv0_c_1);
    input GND_net;
    input cdiv0_c_2;
    output clk0_c;
    input sclk;
    input cdiv0_c_5;
    input cdiv0_c_4;
    input cdiv0_c_0;
    input cdiv0_c_3;
    input cdiv0_c_1;
    
    wire clk0_c /* synthesis is_clock=1, SET_AS_NETWORK=clk0_c */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(9[4:8])
    wire sclk /* synthesis SET_AS_NETWORK=\AL00/sclk, is_clock=1 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/01-osc00vhdl/osc00.vhdl(14[8:12])
    
    wire n2408;
    wire [21:0]sdiv;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/01-osc00vhdl/div00.vhdl(16[9:13])
    wire [21:0]n93;
    
    wire n2409, n2404, n2405, n14, n2834, n2058, n8, n2807, 
        n2778, n2413, n2403, n2020, n2820, n2826, n2677, n2835, 
        n2809, sclk_enable_1, oscout_N_199, sclk_enable_23, n1443, 
        n2412, n2002, n2827, n2676, n2643, n22, n2825, n2819, 
        n2407, n2836, n2040, n2639, n1122, n2757, n2756, n2714, 
        n60, n2650, n2528, n1902, n2529, n40, n2755, n57, n21, 
        n32, n2062, n1962, n2816, n2678, n46, n54, n32_adj_604, 
        n67, n2647, n2648, n2699, n2811, n2808, oscout_N_207, 
        n2411, n2410, n2406, n69, n2641, n2100, n2435, n1996, 
        n2686, n4;
    
    CCU2D sdiv_129_add_4_13 (.A0(sdiv[11]), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(sdiv[12]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n2408), .COUT(n2409), .S0(n93[11]), .S1(n93[12]));   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129_add_4_13.INIT0 = 16'hfaaa;
    defparam sdiv_129_add_4_13.INIT1 = 16'hfaaa;
    defparam sdiv_129_add_4_13.INJECT1_0 = "NO";
    defparam sdiv_129_add_4_13.INJECT1_1 = "NO";
    CCU2D sdiv_129_add_4_5 (.A0(sdiv[3]), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(sdiv[4]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n2404), .COUT(n2405), .S0(n93[3]), .S1(n93[4]));   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129_add_4_5.INIT0 = 16'hfaaa;
    defparam sdiv_129_add_4_5.INIT1 = 16'hfaaa;
    defparam sdiv_129_add_4_5.INJECT1_0 = "NO";
    defparam sdiv_129_add_4_5.INJECT1_1 = "NO";
    LUT4 i1_4_lut (.A(sdiv[19]), .B(n14), .C(n2834), .D(n2058), .Z(n8)) /* synthesis lut_function=(A (B (C+(D)))+!A (B (C))) */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam i1_4_lut.init = 16'hc8c0;
    LUT4 n36_bdd_4_lut (.A(n2807), .B(cdiv0_c_2), .C(sdiv[19]), .D(sdiv[18]), 
         .Z(n2778)) /* synthesis lut_function=(A (B (C+(D))+!B (C))+!A (B (C)+!B (C (D)))) */ ;
    defparam n36_bdd_4_lut.init = 16'hf8e0;
    CCU2D sdiv_129_add_4_23 (.A0(sdiv[21]), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n2413), .S0(n93[21]));   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129_add_4_23.INIT0 = 16'hfaaa;
    defparam sdiv_129_add_4_23.INIT1 = 16'h0000;
    defparam sdiv_129_add_4_23.INJECT1_0 = "NO";
    defparam sdiv_129_add_4_23.INJECT1_1 = "NO";
    CCU2D sdiv_129_add_4_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(sdiv[0]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .COUT(n2403), .S1(n93[0]));   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129_add_4_1.INIT0 = 16'hF000;
    defparam sdiv_129_add_4_1.INIT1 = 16'h0555;
    defparam sdiv_129_add_4_1.INJECT1_0 = "NO";
    defparam sdiv_129_add_4_1.INJECT1_1 = "NO";
    LUT4 i1_3_lut_4_lut (.A(n2020), .B(n2820), .C(n2826), .D(sdiv[12]), 
         .Z(n2677)) /* synthesis lut_function=(A (C+(D))+!A (B (C+(D))+!B (C))) */ ;
    defparam i1_3_lut_4_lut.init = 16'hfef0;
    LUT4 i2_3_lut_rep_16_4_lut (.A(n2020), .B(n2820), .C(sdiv[12]), .D(n2835), 
         .Z(n2809)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i2_3_lut_rep_16_4_lut.init = 16'hfffe;
    FD1P3AX oscout_48 (.D(oscout_N_199), .SP(sclk_enable_1), .CK(sclk), 
            .Q(clk0_c)) /* synthesis LSE_LINE_FILE_ID=21, LSE_LCOL=7, LSE_RCOL=12, LSE_LLINE=18, LSE_RLINE=18 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/01-osc00vhdl/div00.vhdl(20[3] 97[10])
    defparam oscout_48.GSR = "ENABLED";
    CCU2D sdiv_129_add_4_3 (.A0(sdiv[1]), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(sdiv[2]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n2403), .COUT(n2404), .S0(n93[1]), .S1(n93[2]));   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129_add_4_3.INIT0 = 16'hfaaa;
    defparam sdiv_129_add_4_3.INIT1 = 16'hfaaa;
    defparam sdiv_129_add_4_3.INJECT1_0 = "NO";
    defparam sdiv_129_add_4_3.INJECT1_1 = "NO";
    FD1P3IX sdiv_129__i1 (.D(n93[1]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[1])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i1.GSR = "ENABLED";
    FD1P3IX sdiv_129__i2 (.D(n93[2]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[2])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i2.GSR = "ENABLED";
    FD1P3IX sdiv_129__i3 (.D(n93[3]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[3])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i3.GSR = "ENABLED";
    CCU2D sdiv_129_add_4_21 (.A0(sdiv[19]), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(sdiv[20]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n2412), .COUT(n2413), .S0(n93[19]), .S1(n93[20]));   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129_add_4_21.INIT0 = 16'hfaaa;
    defparam sdiv_129_add_4_21.INIT1 = 16'hfaaa;
    defparam sdiv_129_add_4_21.INJECT1_0 = "NO";
    defparam sdiv_129_add_4_21.INJECT1_1 = "NO";
    LUT4 i2_3_lut_4_lut (.A(sdiv[7]), .B(n2002), .C(n2827), .D(n2826), 
         .Z(n2676)) /* synthesis lut_function=(A (B+(C+(D)))+!A (C+(D))) */ ;
    defparam i2_3_lut_4_lut.init = 16'hfff8;
    FD1P3IX sdiv_129__i4 (.D(n93[4]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[4])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i4.GSR = "ENABLED";
    FD1P3IX sdiv_129__i5 (.D(n93[5]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[5])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i5.GSR = "ENABLED";
    LUT4 i40_4_lut (.A(cdiv0_c_5), .B(n2643), .C(cdiv0_c_4), .D(n22), 
         .Z(sclk_enable_1)) /* synthesis lut_function=(A (B (C))+!A (B (C+(D))+!B !(C+!(D)))) */ ;
    defparam i40_4_lut.init = 16'hc5c0;
    LUT4 i1378_2_lut_rep_41 (.A(sdiv[21]), .B(sdiv[20]), .Z(n2834)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i1378_2_lut_rep_41.init = 16'heeee;
    LUT4 i1_2_lut_rep_32_3_lut (.A(sdiv[21]), .B(sdiv[20]), .C(sdiv[19]), 
         .Z(n2825)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i1_2_lut_rep_32_3_lut.init = 16'hfefe;
    LUT4 i1_2_lut_rep_26_3_lut_4_lut (.A(sdiv[21]), .B(sdiv[20]), .C(sdiv[18]), 
         .D(sdiv[19]), .Z(n2819)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i1_2_lut_rep_26_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_2_lut_rep_42 (.A(sdiv[14]), .B(sdiv[13]), .Z(n2835)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i1_2_lut_rep_42.init = 16'heeee;
    LUT4 i1_2_lut_rep_33_3_lut (.A(sdiv[14]), .B(sdiv[13]), .C(sdiv[15]), 
         .Z(n2826)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i1_2_lut_rep_33_3_lut.init = 16'hfefe;
    CCU2D sdiv_129_add_4_11 (.A0(sdiv[9]), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(sdiv[10]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n2407), .COUT(n2408), .S0(n93[9]), .S1(n93[10]));   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129_add_4_11.INIT0 = 16'hfaaa;
    defparam sdiv_129_add_4_11.INIT1 = 16'hfaaa;
    defparam sdiv_129_add_4_11.INJECT1_0 = "NO";
    defparam sdiv_129_add_4_11.INJECT1_1 = "NO";
    FD1P3IX sdiv_129__i6 (.D(n93[6]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[6])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i6.GSR = "ENABLED";
    LUT4 i1_2_lut_rep_43 (.A(sdiv[15]), .B(sdiv[16]), .Z(n2836)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i1_2_lut_rep_43.init = 16'heeee;
    FD1P3IX sdiv_129__i7 (.D(n93[7]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[7])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i7.GSR = "ENABLED";
    LUT4 i2_3_lut_4_lut_adj_64 (.A(sdiv[15]), .B(sdiv[16]), .C(n2040), 
         .D(n2002), .Z(n2639)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i2_3_lut_4_lut_adj_64.init = 16'hfffe;
    LUT4 indiv_5__I_0_i58_4_lut (.A(n2677), .B(n2809), .C(cdiv0_c_0), 
         .D(sdiv[15]), .Z(n1122)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C))+!A (B (C (D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/01-osc00vhdl/div00.vhdl(21[4] 96[13])
    defparam indiv_5__I_0_i58_4_lut.init = 16'hca0a;
    LUT4 i324_2_lut_rep_14_3_lut_4_lut (.A(sdiv[15]), .B(sdiv[16]), .C(sdiv[17]), 
         .D(n2809), .Z(n2807)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i324_2_lut_rep_14_3_lut_4_lut.init = 16'hfffe;
    FD1P3IX sdiv_129__i8 (.D(n93[8]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[8])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i8.GSR = "ENABLED";
    FD1P3IX sdiv_129__i9 (.D(n93[9]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[9])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i9.GSR = "ENABLED";
    LUT4 i912_2_lut_4_lut (.A(clk0_c), .B(n2757), .C(n2756), .D(n2714), 
         .Z(oscout_N_199)) /* synthesis lut_function=(!(A (B (C+!(D))+!B (C (D)))+!A !(B (C+!(D))+!B (C (D))))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/01-osc00vhdl/div00.vhdl(21[4] 96[13])
    defparam i912_2_lut_4_lut.init = 16'h5a66;
    LUT4 i1_3_lut_4_lut_4_lut (.A(cdiv0_c_5), .B(cdiv0_c_3), .C(n60), 
         .D(cdiv0_c_2), .Z(n2650)) /* synthesis lut_function=(A (B (C (D)))) */ ;
    defparam i1_3_lut_4_lut_4_lut.init = 16'h8000;
    LUT4 i3_3_lut_4_lut (.A(sdiv[18]), .B(n2825), .C(n2528), .D(n1902), 
         .Z(n2529)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i3_3_lut_4_lut.init = 16'hfffe;
    LUT4 n40_bdd_4_lut_2234 (.A(n40), .B(sdiv[20]), .C(cdiv0_c_0), .D(sdiv[21]), 
         .Z(n2755)) /* synthesis lut_function=(A (B (C+(D))+!B (D))+!A (B (D)+!B (C (D)))) */ ;
    defparam n40_bdd_4_lut_2234.init = 16'hfe80;
    LUT4 i89_4_lut (.A(n57), .B(n2650), .C(cdiv0_c_4), .D(n21), .Z(n1443)) /* synthesis lut_function=(A (B (C+!(D))+!B !(C+(D)))+!A (B (C))) */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam i89_4_lut.init = 16'hc0ca;
    LUT4 i37_3_lut_4_lut (.A(cdiv0_c_5), .B(cdiv0_c_3), .C(cdiv0_c_4), 
         .D(n21), .Z(n32)) /* synthesis lut_function=(!(A (B (C+!(D))+!B !(C+(D)))+!A !(C+(D)))) */ ;
    defparam i37_3_lut_4_lut.init = 16'h7f70;
    LUT4 i1540_3_lut (.A(sdiv[15]), .B(n2002), .C(n2040), .Z(n2062)) /* synthesis lut_function=(A (B+(C))) */ ;
    defparam i1540_3_lut.init = 16'ha8a8;
    FD1P3IX sdiv_129__i10 (.D(n93[10]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[10])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i10.GSR = "ENABLED";
    LUT4 i1_3_lut (.A(cdiv0_c_5), .B(cdiv0_c_2), .C(cdiv0_c_0), .Z(n21)) /* synthesis lut_function=(A+!((C)+!B)) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/01-osc00vhdl/div00.vhdl(21[4] 96[13])
    defparam i1_3_lut.init = 16'haeae;
    FD1P3IX sdiv_129__i11 (.D(n93[11]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[11])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i11.GSR = "ENABLED";
    PFUMX i2209 (.BLUT(n2755), .ALUT(n2529), .C0(cdiv0_c_5), .Z(n2756));
    LUT4 i1_4_lut_4_lut (.A(cdiv0_c_0), .B(n1962), .C(n2816), .D(n2678), 
         .Z(n46)) /* synthesis lut_function=(!(A+!(B+(C+(D))))) */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam i1_4_lut_4_lut.init = 16'h5554;
    LUT4 i1_2_lut_rep_27 (.A(sdiv[7]), .B(n2002), .Z(n2820)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i1_2_lut_rep_27.init = 16'heeee;
    FD1P3IX sdiv_129__i12 (.D(n93[12]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[12])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i12.GSR = "ENABLED";
    LUT4 i2208_2_lut (.A(cdiv0_c_1), .B(cdiv0_c_0), .Z(n14)) /* synthesis lut_function=((B)+!A) */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam i2208_2_lut.init = 16'hdddd;
    LUT4 i1_4_lut_adj_65 (.A(cdiv0_c_0), .B(n54), .C(n32_adj_604), .D(cdiv0_c_3), 
         .Z(n67)) /* synthesis lut_function=(A (B (C+!(D))+!B (C (D)))) */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam i1_4_lut_adj_65.init = 16'ha088;
    LUT4 i3_4_lut (.A(cdiv0_c_3), .B(n14), .C(cdiv0_c_2), .D(n2647), 
         .Z(n2648)) /* synthesis lut_function=(!(A+((C+!(D))+!B))) */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam i3_4_lut.init = 16'h0400;
    LUT4 i2_3_lut_4_lut_adj_66 (.A(sdiv[7]), .B(n2002), .C(n1902), .D(n2678), 
         .Z(n2699)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i2_3_lut_4_lut_adj_66.init = 16'hfffe;
    LUT4 i1_2_lut_rep_18_3_lut (.A(sdiv[7]), .B(n2002), .C(n2020), .Z(n2811)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i1_2_lut_rep_18_3_lut.init = 16'hfefe;
    LUT4 i326_2_lut_3_lut_4_lut (.A(n2808), .B(sdiv[17]), .C(sdiv[19]), 
         .D(sdiv[18]), .Z(n40)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i326_2_lut_3_lut_4_lut.init = 16'hfffe;
    LUT4 n1427_bdd_3_lut_4_lut (.A(n2778), .B(n2834), .C(cdiv0_c_3), .D(oscout_N_207), 
         .Z(n2757)) /* synthesis lut_function=(A ((D)+!C)+!A (B ((D)+!C)+!B (C (D)))) */ ;
    defparam n1427_bdd_3_lut_4_lut.init = 16'hfe0e;
    LUT4 i1_2_lut_rep_15_4_lut (.A(n2835), .B(n2811), .C(sdiv[12]), .D(n2836), 
         .Z(n2808)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i1_2_lut_rep_15_4_lut.init = 16'hfffe;
    CCU2D sdiv_129_add_4_19 (.A0(sdiv[17]), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(sdiv[18]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n2411), .COUT(n2412), .S0(n93[17]), .S1(n93[18]));   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129_add_4_19.INIT0 = 16'hfaaa;
    defparam sdiv_129_add_4_19.INIT1 = 16'hfaaa;
    defparam sdiv_129_add_4_19.INJECT1_0 = "NO";
    defparam sdiv_129_add_4_19.INJECT1_1 = "NO";
    FD1P3IX sdiv_129__i13 (.D(n93[13]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[13])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i13.GSR = "ENABLED";
    PFUMX i87 (.BLUT(n2648), .ALUT(n67), .C0(cdiv0_c_1), .Z(n57));
    CCU2D sdiv_129_add_4_17 (.A0(sdiv[15]), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(sdiv[16]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n2410), .COUT(n2411), .S0(n93[15]), .S1(n93[16]));   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129_add_4_17.INIT0 = 16'hfaaa;
    defparam sdiv_129_add_4_17.INIT1 = 16'hfaaa;
    defparam sdiv_129_add_4_17.INJECT1_0 = "NO";
    defparam sdiv_129_add_4_17.INJECT1_1 = "NO";
    CCU2D sdiv_129_add_4_9 (.A0(sdiv[7]), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(sdiv[8]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n2406), .COUT(n2407), .S0(n93[7]), .S1(n93[8]));   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129_add_4_9.INIT0 = 16'hfaaa;
    defparam sdiv_129_add_4_9.INIT1 = 16'hfaaa;
    defparam sdiv_129_add_4_9.INJECT1_0 = "NO";
    defparam sdiv_129_add_4_9.INJECT1_1 = "NO";
    LUT4 i1_4_lut_adj_67 (.A(n1962), .B(cdiv0_c_0), .C(n2677), .D(n2062), 
         .Z(n69)) /* synthesis lut_function=(A+(B (C (D))+!B (C))) */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam i1_4_lut_adj_67.init = 16'hfaba;
    FD1P3IX sdiv_129__i14 (.D(n93[14]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[14])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i14.GSR = "ENABLED";
    FD1P3IX sdiv_129__i15 (.D(n93[15]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[15])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i15.GSR = "ENABLED";
    FD1P3IX sdiv_129__i0 (.D(n93[0]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[0])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i0.GSR = "ENABLED";
    LUT4 i1_3_lut_adj_68 (.A(n2641), .B(cdiv0_c_0), .C(cdiv0_c_1), .Z(n2643)) /* synthesis lut_function=(A ((C)+!B)) */ ;
    defparam i1_3_lut_adj_68.init = 16'ha2a2;
    LUT4 i2205_4_lut (.A(cdiv0_c_5), .B(cdiv0_c_3), .C(cdiv0_c_2), .D(cdiv0_c_1), 
         .Z(n2714)) /* synthesis lut_function=(A+!(B+(C+(D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/01-osc00vhdl/div00.vhdl(21[4] 96[13])
    defparam i2205_4_lut.init = 16'haaab;
    LUT4 i1_4_lut_adj_69 (.A(sdiv[21]), .B(cdiv0_c_0), .C(n2100), .D(n2435), 
         .Z(n2647)) /* synthesis lut_function=(A (B+(D))+!A (B (C))) */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam i1_4_lut_adj_69.init = 16'heac8;
    LUT4 i1578_4_lut (.A(sdiv[20]), .B(n2699), .C(sdiv[19]), .D(sdiv[18]), 
         .Z(n2100)) /* synthesis lut_function=(A (B+(C+(D)))) */ ;
    defparam i1578_4_lut.init = 16'haaa8;
    LUT4 i2_3_lut (.A(sdiv[19]), .B(sdiv[20]), .C(n2058), .Z(n2435)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i2_3_lut.init = 16'hfefe;
    FD1P3IX sdiv_129__i16 (.D(n93[16]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[16])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i16.GSR = "ENABLED";
    LUT4 i2_3_lut_adj_70 (.A(n2639), .B(sdiv[18]), .C(sdiv[17]), .Z(n2058)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i2_3_lut_adj_70.init = 16'hfefe;
    LUT4 i1480_4_lut (.A(n1996), .B(sdiv[0]), .C(sdiv[6]), .D(sdiv[5]), 
         .Z(n2002)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i1480_4_lut.init = 16'hfffe;
    LUT4 i3_4_lut_adj_71 (.A(sdiv[4]), .B(sdiv[3]), .C(sdiv[1]), .D(sdiv[2]), 
         .Z(n1996)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i3_4_lut_adj_71.init = 16'hfffe;
    LUT4 i3_4_lut_adj_72 (.A(sdiv[8]), .B(sdiv[9]), .C(sdiv[11]), .D(sdiv[10]), 
         .Z(n2020)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i3_4_lut_adj_72.init = 16'hfffe;
    FD1P3IX sdiv_129__i17 (.D(n93[17]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[17])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i17.GSR = "ENABLED";
    LUT4 i1380_2_lut (.A(sdiv[17]), .B(sdiv[16]), .Z(n1902)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i1380_2_lut.init = 16'heeee;
    LUT4 i1_3_lut_4_lut_adj_73 (.A(sdiv[19]), .B(n2834), .C(n2699), .D(sdiv[18]), 
         .Z(n2686)) /* synthesis lut_function=(A+(B+(C (D)))) */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam i1_3_lut_4_lut_adj_73.init = 16'hfeee;
    LUT4 i1_2_lut_3_lut_4_lut (.A(sdiv[19]), .B(n2834), .C(n1902), .D(sdiv[18]), 
         .Z(n1962)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam i1_2_lut_3_lut_4_lut.init = 16'hfffe;
    LUT4 i1_4_lut_adj_74 (.A(cdiv0_c_3), .B(cdiv0_c_0), .C(cdiv0_c_2), 
         .D(cdiv0_c_1), .Z(n22)) /* synthesis lut_function=(A (B (C (D)))+!A (B ((D)+!C)+!B !(C+(D)))) */ ;
    defparam i1_4_lut_adj_74.init = 16'hc405;
    LUT4 i2_3_lut_adj_75 (.A(cdiv0_c_5), .B(cdiv0_c_3), .C(cdiv0_c_2), 
         .Z(n2641)) /* synthesis lut_function=(A (B (C))) */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam i2_3_lut_adj_75.init = 16'h8080;
    PFUMX i86 (.BLUT(n8), .ALUT(n2686), .C0(cdiv0_c_2), .Z(n54));
    LUT4 i1_3_lut_4_lut_adj_76 (.A(sdiv[15]), .B(n2835), .C(sdiv[12]), 
         .D(n2020), .Z(n2678)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i1_3_lut_4_lut_adj_76.init = 16'hfffe;
    LUT4 i1_2_lut_rep_34 (.A(sdiv[12]), .B(n2020), .Z(n2827)) /* synthesis lut_function=(A+(B)) */ ;
    defparam i1_2_lut_rep_34.init = 16'heeee;
    PFUMX i88 (.BLUT(n46), .ALUT(n69), .C0(cdiv0_c_1), .Z(n60));
    LUT4 i2_3_lut_4_lut_adj_77 (.A(sdiv[12]), .B(n2020), .C(sdiv[7]), 
         .D(n2835), .Z(n2040)) /* synthesis lut_function=(A+(B+(C+(D)))) */ ;
    defparam i2_3_lut_4_lut_adj_77.init = 16'hfffe;
    FD1P3IX sdiv_129__i18 (.D(n93[18]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[18])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i18.GSR = "ENABLED";
    FD1P3IX sdiv_129__i19 (.D(n93[19]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[19])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i19.GSR = "ENABLED";
    LUT4 i1_4_lut_adj_78 (.A(cdiv0_c_2), .B(sdiv[17]), .C(n2819), .D(n2639), 
         .Z(n32_adj_604)) /* synthesis lut_function=(A (B (C+(D))+!B (C))) */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam i1_4_lut_adj_78.init = 16'ha8a0;
    FD1P3IX sdiv_129__i20 (.D(n93[20]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[20])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i20.GSR = "ENABLED";
    LUT4 i1484_2_lut_rep_23 (.A(sdiv[7]), .B(n2002), .Z(n2816)) /* synthesis lut_function=(A (B)) */ ;
    defparam i1484_2_lut_rep_23.init = 16'h8888;
    LUT4 i2204_4_lut (.A(cdiv0_c_2), .B(n4), .C(cdiv0_c_1), .D(cdiv0_c_0), 
         .Z(sclk_enable_23)) /* synthesis lut_function=(!(A (B+!(C+!(D)))+!A (B))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/01-osc00vhdl/div00.vhdl(21[4] 96[13])
    defparam i2204_4_lut.init = 16'h3133;
    CCU2D sdiv_129_add_4_15 (.A0(sdiv[13]), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(sdiv[14]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n2409), .COUT(n2410), .S0(n93[13]), .S1(n93[14]));   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129_add_4_15.INIT0 = 16'hfaaa;
    defparam sdiv_129_add_4_15.INIT1 = 16'hfaaa;
    defparam sdiv_129_add_4_15.INJECT1_0 = "NO";
    defparam sdiv_129_add_4_15.INJECT1_1 = "NO";
    LUT4 i1_4_lut_adj_79 (.A(cdiv0_c_2), .B(n32), .C(cdiv0_c_3), .D(n14), 
         .Z(n4)) /* synthesis lut_function=(A (B)+!A (B+(C+!(D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/01-osc00vhdl/div00.vhdl(21[4] 96[13])
    defparam i1_4_lut_adj_79.init = 16'hdcdd;
    LUT4 i1_3_lut_4_lut_adj_80 (.A(n2809), .B(n2836), .C(sdiv[17]), .D(n2819), 
         .Z(oscout_N_207)) /* synthesis lut_function=(A (C+(D))+!A (B (C+(D))+!B (D))) */ ;
    defparam i1_3_lut_4_lut_adj_80.init = 16'hffe0;
    PFUMX i1997 (.BLUT(n2676), .ALUT(n1122), .C0(cdiv0_c_1), .Z(n2528));
    FD1P3IX sdiv_129__i21 (.D(n93[21]), .SP(sclk_enable_23), .CD(n1443), 
            .CK(sclk), .Q(sdiv[21])) /* synthesis syn_use_carry_chain=1 */ ;   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129__i21.GSR = "ENABLED";
    CCU2D sdiv_129_add_4_7 (.A0(sdiv[5]), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(sdiv[6]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n2405), .COUT(n2406), .S0(n93[5]), .S1(n93[6]));   // C:/lscc/diamond/3.14/ispfpga/vhdl_packages/syn_arit.vhd(928[41:65])
    defparam sdiv_129_add_4_7.INIT0 = 16'hfaaa;
    defparam sdiv_129_add_4_7.INIT1 = 16'hfaaa;
    defparam sdiv_129_add_4_7.INJECT1_0 = "NO";
    defparam sdiv_129_add_4_7.INJECT1_1 = "NO";
    
endmodule
//
// Verilog Description of module oscint00
//

module oscint00 (GND_net, sclk);
    input GND_net;
    output sclk;
    
    wire sclk /* synthesis SET_AS_NETWORK=\AL00/sclk, is_clock=1 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/01-osc00vhdl/osc00.vhdl(14[8:12])
    
    OSCH OSCInst0 (.STDBY(GND_net), .OSC(sclk)) /* synthesis NOM_FREQ="2.08", syn_instantiated=1, LSE_LINE_FILE_ID=21, LSE_LCOL=7, LSE_RCOL=15, LSE_LLINE=16, LSE_RLINE=16 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/01-osc00vhdl/osc00.vhdl(16[7:15])
    defparam OSCInst0.NOM_FREQ = "2.08";
    
endmodule
//
// Verilog Description of module xnor00
//

module xnor00 (outnx_7__N_471, clk0_c, outFlagnx_N_512, outnx_7__N_491, 
            srd, inA0_c_7, outnx_7__N_489, inB0_c_7, inA0_c_6, inB0_c_6, 
            inA0_c_5, inB0_c_5, inA0_c_4, inB0_c_4, inA0_c_3, inB0_c_3, 
            inA0_c_2, inB0_c_2, inA0_c_1, inB0_c_1, outFlagnx_N_511, 
            n2833, \pxnor.auxnx , en0_c, n2814, n2933, inA0_c_0, 
            inB0_c_0, outnx_7__N_472);
    output [7:0]outnx_7__N_471;
    input clk0_c;
    output outFlagnx_N_512;
    input outnx_7__N_491;
    input [7:0]srd;
    input inA0_c_7;
    input outnx_7__N_489;
    input inB0_c_7;
    input inA0_c_6;
    input inB0_c_6;
    input inA0_c_5;
    input inB0_c_5;
    input inA0_c_4;
    input inB0_c_4;
    input inA0_c_3;
    input inB0_c_3;
    input inA0_c_2;
    input inB0_c_2;
    input inA0_c_1;
    input inB0_c_1;
    output outFlagnx_N_511;
    input n2833;
    output \pxnor.auxnx ;
    input en0_c;
    input n2814;
    input n2933;
    input inA0_c_0;
    input inB0_c_0;
    output outnx_7__N_472;
    
    wire clk0_c /* synthesis is_clock=1, SET_AS_NETWORK=clk0_c */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(9[4:8])
    
    wire outnx_7__N_509, outnx_7__N_487, outnx_7__N_497, outnx_7__N_499, 
        outnx_7__N_501, outnx_7__N_503, outnx_7__N_505, outnx_7__N_507, 
        \pxnor.auxnx_N_494 ;
    
    FD1S3AX outnx_i0 (.D(outnx_7__N_509), .CK(clk0_c), .Q(outnx_7__N_471[0])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=73, LSE_RLINE=73 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam outnx_i0.GSR = "ENABLED";
    FD1S3AX i160_175 (.D(outnx_7__N_491), .CK(clk0_c), .Q(outFlagnx_N_512)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=73, LSE_RLINE=73 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam i160_175.GSR = "ENABLED";
    LUT4 outnx_7__I_0_4_lut (.A(srd[7]), .B(inA0_c_7), .C(outnx_7__N_489), 
         .D(inB0_c_7), .Z(outnx_7__N_487)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C (D)))+!A (B (C (D))+!B !((D)+!C))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam outnx_7__I_0_4_lut.init = 16'hca3a;
    LUT4 outnx_6__I_0_4_lut (.A(srd[6]), .B(inA0_c_6), .C(outnx_7__N_489), 
         .D(inB0_c_6), .Z(outnx_7__N_497)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C (D)))+!A (B (C (D))+!B !((D)+!C))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam outnx_6__I_0_4_lut.init = 16'hca3a;
    LUT4 outnx_5__I_0_4_lut (.A(srd[5]), .B(inA0_c_5), .C(outnx_7__N_489), 
         .D(inB0_c_5), .Z(outnx_7__N_499)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C (D)))+!A (B (C (D))+!B !((D)+!C))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam outnx_5__I_0_4_lut.init = 16'hca3a;
    LUT4 outnx_4__I_0_4_lut (.A(srd[4]), .B(inA0_c_4), .C(outnx_7__N_489), 
         .D(inB0_c_4), .Z(outnx_7__N_501)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C (D)))+!A (B (C (D))+!B !((D)+!C))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam outnx_4__I_0_4_lut.init = 16'hca3a;
    LUT4 outnx_3__I_0_4_lut (.A(srd[3]), .B(inA0_c_3), .C(outnx_7__N_489), 
         .D(inB0_c_3), .Z(outnx_7__N_503)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C (D)))+!A (B (C (D))+!B !((D)+!C))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam outnx_3__I_0_4_lut.init = 16'hca3a;
    LUT4 outnx_2__I_0_4_lut (.A(srd[2]), .B(inA0_c_2), .C(outnx_7__N_489), 
         .D(inB0_c_2), .Z(outnx_7__N_505)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C (D)))+!A (B (C (D))+!B !((D)+!C))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam outnx_2__I_0_4_lut.init = 16'hca3a;
    LUT4 outnx_1__I_0_4_lut (.A(srd[1]), .B(inA0_c_1), .C(outnx_7__N_489), 
         .D(inB0_c_1), .Z(outnx_7__N_507)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C (D)))+!A (B (C (D))+!B !((D)+!C))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam outnx_1__I_0_4_lut.init = 16'hca3a;
    FD1S3IX outFlagnx_166 (.D(\pxnor.auxnx_N_494 ), .CK(clk0_c), .CD(n2833), 
            .Q(outFlagnx_N_511)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=73, LSE_RLINE=73 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam outFlagnx_166.GSR = "ENABLED";
    FD1P3IX \pxnor.auxnx_164  (.D(n2933), .SP(en0_c), .CD(n2814), .CK(clk0_c), 
            .Q(\pxnor.auxnx )) /* synthesis lse_init_val=0, LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=73, LSE_RLINE=73 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam \pxnor.auxnx_164 .GSR = "ENABLED";
    LUT4 \pxnor.auxnx_I_0_1_lut  (.A(\pxnor.auxnx ), .Z(\pxnor.auxnx_N_494 )) /* synthesis lut_function=(!(A)) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(24[10:21])
    defparam \pxnor.auxnx_I_0_1_lut .init = 16'h5555;
    FD1S3AX outnx_i7 (.D(outnx_7__N_487), .CK(clk0_c), .Q(outnx_7__N_471[7])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=73, LSE_RLINE=73 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam outnx_i7.GSR = "ENABLED";
    FD1S3AX outnx_i6 (.D(outnx_7__N_497), .CK(clk0_c), .Q(outnx_7__N_471[6])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=73, LSE_RLINE=73 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam outnx_i6.GSR = "ENABLED";
    FD1S3AX outnx_i5 (.D(outnx_7__N_499), .CK(clk0_c), .Q(outnx_7__N_471[5])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=73, LSE_RLINE=73 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam outnx_i5.GSR = "ENABLED";
    FD1S3AX outnx_i4 (.D(outnx_7__N_501), .CK(clk0_c), .Q(outnx_7__N_471[4])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=73, LSE_RLINE=73 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam outnx_i4.GSR = "ENABLED";
    FD1S3AX outnx_i3 (.D(outnx_7__N_503), .CK(clk0_c), .Q(outnx_7__N_471[3])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=73, LSE_RLINE=73 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam outnx_i3.GSR = "ENABLED";
    FD1S3AX outnx_i2 (.D(outnx_7__N_505), .CK(clk0_c), .Q(outnx_7__N_471[2])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=73, LSE_RLINE=73 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam outnx_i2.GSR = "ENABLED";
    FD1S3AX outnx_i1 (.D(outnx_7__N_507), .CK(clk0_c), .Q(outnx_7__N_471[1])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=73, LSE_RLINE=73 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam outnx_i1.GSR = "ENABLED";
    LUT4 outnx_0__I_0_4_lut (.A(srd[0]), .B(inA0_c_0), .C(outnx_7__N_489), 
         .D(inB0_c_0), .Z(outnx_7__N_509)) /* synthesis lut_function=(A (B ((D)+!C)+!B !(C (D)))+!A (B (C (D))+!B !((D)+!C))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam outnx_0__I_0_4_lut.init = 16'hca3a;
    FD1P3AX i32_167 (.D(outnx_7__N_491), .SP(outnx_7__N_489), .CK(clk0_c), 
            .Q(outnx_7__N_472)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=14, LSE_LLINE=73, LSE_RLINE=73 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/xnor00.vhdl(21[3] 39[10])
    defparam i32_167.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module or00
//

module or00 (outo_7__N_267, clk0_c, outFlago_N_308, outo_7__N_287, n2837, 
            n2824, \pxnor.auxnx , en0_c, outnx_7__N_489, srd, inA0_c_7, 
            inB0_c_7, inA0_c_0, inB0_c_0, inA0_c_6, inB0_c_6, inA0_c_5, 
            inB0_c_5, inA0_c_4, inB0_c_4, inA0_c_3, inB0_c_3, n2832, 
            n2829, \pnand.auxna , outna_7__N_387, inA0_c_2, inB0_c_2, 
            inA0_c_1, inB0_c_1, n10, outFlago_N_307, n2833, n2815, 
            n2933, outo_7__N_268);
    output [7:0]outo_7__N_267;
    input clk0_c;
    output outFlago_N_308;
    input outo_7__N_287;
    input n2837;
    input n2824;
    input \pxnor.auxnx ;
    input en0_c;
    output outnx_7__N_489;
    input [7:0]srd;
    input inA0_c_7;
    input inB0_c_7;
    input inA0_c_0;
    input inB0_c_0;
    input inA0_c_6;
    input inB0_c_6;
    input inA0_c_5;
    input inB0_c_5;
    input inA0_c_4;
    input inB0_c_4;
    input inA0_c_3;
    input inB0_c_3;
    input n2832;
    input n2829;
    input \pnand.auxna ;
    output outna_7__N_387;
    input inA0_c_2;
    input inB0_c_2;
    input inA0_c_1;
    input inB0_c_1;
    input n10;
    output outFlago_N_307;
    input n2833;
    input n2815;
    input n2933;
    output outo_7__N_268;
    
    wire clk0_c /* synthesis is_clock=1, SET_AS_NETWORK=clk0_c */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/alubl00.vhdl(9[4:8])
    
    wire outo_7__N_305, outo_7__N_283, outo_7__N_293, outo_7__N_295, 
        outo_7__N_297, outo_7__N_299, outo_7__N_301, outo_7__N_303, 
        \por.auxo , \por.auxo_N_290 , outo_7__N_285;
    
    FD1S3AX outo_i0 (.D(outo_7__N_305), .CK(clk0_c), .Q(outo_7__N_267[0])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=12, LSE_LLINE=38, LSE_RLINE=38 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam outo_i0.GSR = "ENABLED";
    FD1S3AX i160_175 (.D(outo_7__N_287), .CK(clk0_c), .Q(outFlago_N_308)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=12, LSE_LLINE=38, LSE_RLINE=38 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam i160_175.GSR = "ENABLED";
    FD1S3AX outo_i7 (.D(outo_7__N_283), .CK(clk0_c), .Q(outo_7__N_267[7])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=12, LSE_LLINE=38, LSE_RLINE=38 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam outo_i7.GSR = "ENABLED";
    FD1S3AX outo_i6 (.D(outo_7__N_293), .CK(clk0_c), .Q(outo_7__N_267[6])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=12, LSE_LLINE=38, LSE_RLINE=38 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam outo_i6.GSR = "ENABLED";
    FD1S3AX outo_i5 (.D(outo_7__N_295), .CK(clk0_c), .Q(outo_7__N_267[5])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=12, LSE_LLINE=38, LSE_RLINE=38 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam outo_i5.GSR = "ENABLED";
    FD1S3AX outo_i4 (.D(outo_7__N_297), .CK(clk0_c), .Q(outo_7__N_267[4])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=12, LSE_LLINE=38, LSE_RLINE=38 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam outo_i4.GSR = "ENABLED";
    FD1S3AX outo_i3 (.D(outo_7__N_299), .CK(clk0_c), .Q(outo_7__N_267[3])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=12, LSE_LLINE=38, LSE_RLINE=38 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam outo_i3.GSR = "ENABLED";
    FD1S3AX outo_i2 (.D(outo_7__N_301), .CK(clk0_c), .Q(outo_7__N_267[2])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=12, LSE_LLINE=38, LSE_RLINE=38 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam outo_i2.GSR = "ENABLED";
    FD1S3AX outo_i1 (.D(outo_7__N_303), .CK(clk0_c), .Q(outo_7__N_267[1])) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=12, LSE_LLINE=38, LSE_RLINE=38 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam outo_i1.GSR = "ENABLED";
    LUT4 outnx_7__I_53_3_lut_4_lut (.A(n2837), .B(n2824), .C(\pxnor.auxnx ), 
         .D(en0_c), .Z(outnx_7__N_489)) /* synthesis lut_function=(A+(B+!(C+!(D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(22[8:28])
    defparam outnx_7__I_53_3_lut_4_lut.init = 16'hefee;
    LUT4 \por.auxo_I_0_1_lut  (.A(\por.auxo ), .Z(\por.auxo_N_290 )) /* synthesis lut_function=(!(A)) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(24[10:20])
    defparam \por.auxo_I_0_1_lut .init = 16'h5555;
    LUT4 outo_7__I_0_4_lut (.A(srd[7]), .B(inA0_c_7), .C(outo_7__N_285), 
         .D(inB0_c_7), .Z(outo_7__N_283)) /* synthesis lut_function=(A (B+((D)+!C))+!A (B (C)+!B (C (D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam outo_7__I_0_4_lut.init = 16'hfaca;
    LUT4 outo_0__I_0_4_lut (.A(srd[0]), .B(inA0_c_0), .C(outo_7__N_285), 
         .D(inB0_c_0), .Z(outo_7__N_305)) /* synthesis lut_function=(A (B+((D)+!C))+!A (B (C)+!B (C (D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam outo_0__I_0_4_lut.init = 16'hfaca;
    LUT4 outo_6__I_0_4_lut (.A(srd[6]), .B(inA0_c_6), .C(outo_7__N_285), 
         .D(inB0_c_6), .Z(outo_7__N_293)) /* synthesis lut_function=(A (B+((D)+!C))+!A (B (C)+!B (C (D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam outo_6__I_0_4_lut.init = 16'hfaca;
    LUT4 outo_5__I_0_4_lut (.A(srd[5]), .B(inA0_c_5), .C(outo_7__N_285), 
         .D(inB0_c_5), .Z(outo_7__N_295)) /* synthesis lut_function=(A (B+((D)+!C))+!A (B (C)+!B (C (D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam outo_5__I_0_4_lut.init = 16'hfaca;
    LUT4 outo_4__I_0_4_lut (.A(srd[4]), .B(inA0_c_4), .C(outo_7__N_285), 
         .D(inB0_c_4), .Z(outo_7__N_297)) /* synthesis lut_function=(A (B+((D)+!C))+!A (B (C)+!B (C (D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam outo_4__I_0_4_lut.init = 16'hfaca;
    LUT4 outo_3__I_0_4_lut (.A(srd[3]), .B(inA0_c_3), .C(outo_7__N_285), 
         .D(inB0_c_3), .Z(outo_7__N_299)) /* synthesis lut_function=(A (B+((D)+!C))+!A (B (C)+!B (C (D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam outo_3__I_0_4_lut.init = 16'hfaca;
    LUT4 outna_7__I_35_3_lut_4_lut (.A(n2832), .B(n2829), .C(\pnand.auxna ), 
         .D(en0_c), .Z(outna_7__N_387)) /* synthesis lut_function=(A+(B+!(C+!(D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(22[8:28])
    defparam outna_7__I_35_3_lut_4_lut.init = 16'hefee;
    LUT4 outo_2__I_0_4_lut (.A(srd[2]), .B(inA0_c_2), .C(outo_7__N_285), 
         .D(inB0_c_2), .Z(outo_7__N_301)) /* synthesis lut_function=(A (B+((D)+!C))+!A (B (C)+!B (C (D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam outo_2__I_0_4_lut.init = 16'hfaca;
    LUT4 outo_1__I_0_4_lut (.A(srd[1]), .B(inA0_c_1), .C(outo_7__N_285), 
         .D(inB0_c_1), .Z(outo_7__N_303)) /* synthesis lut_function=(A (B+((D)+!C))+!A (B (C)+!B (C (D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam outo_1__I_0_4_lut.init = 16'hfaca;
    LUT4 outo_7__I_17_3_lut_4_lut (.A(n10), .B(n2824), .C(\por.auxo ), 
         .D(en0_c), .Z(outo_7__N_285)) /* synthesis lut_function=(A+(B+!(C+!(D)))) */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(22[8:28])
    defparam outo_7__I_17_3_lut_4_lut.init = 16'hefee;
    FD1S3IX outFlago_166 (.D(\por.auxo_N_290 ), .CK(clk0_c), .CD(n2833), 
            .Q(outFlago_N_307)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=12, LSE_LLINE=38, LSE_RLINE=38 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam outFlago_166.GSR = "ENABLED";
    FD1P3IX \por.auxo_164  (.D(n2933), .SP(en0_c), .CD(n2815), .CK(clk0_c), 
            .Q(\por.auxo )) /* synthesis lse_init_val=0, LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=12, LSE_LLINE=38, LSE_RLINE=38 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam \por.auxo_164 .GSR = "ENABLED";
    FD1P3AX i32_167 (.D(outo_7__N_287), .SP(outo_7__N_285), .CK(clk0_c), 
            .Q(outo_7__N_268)) /* synthesis LSE_LINE_FILE_ID=35, LSE_LCOL=8, LSE_RCOL=12, LSE_LLINE=38, LSE_RLINE=38 */ ;   // c:/users/areli guevara/onedrive/documentos/escuela/arquitectura de computadoras/practicas/17-aluloica00/or00.vhdl(21[3] 39[10])
    defparam i32_167.GSR = "ENABLED";
    
endmodule
//
// Verilog Description of module TSALL
// module not written out since it is a black-box. 
//

//
// Verilog Description of module PUR
// module not written out since it is a black-box. 
//

