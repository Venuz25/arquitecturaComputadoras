library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;
use packageBLA00.all;

entity aluBL00 is
	port(
		 clk0: inout std_logic;
		 cdiv0: in std_logic_vector(5 downto 0);
		 re0, en0, rw0: in std_logic;
		 inA0, inB0: in std_logic_vector(7 downto 0);
		 out0: out std_logic_vector(7 downto 0); ---Resultados
		 outCode0: inout std_logic_vector(7 downto 0);---Salida de la RAM
		 Address0: inout std_logic_vector(3 downto 0);
		 outFlagL0: inout std_logic;
		 outFlag0: inout std_logic); --- sale del acumulador
end aluBL00;

architecture aluBL0 of aluBL00 is
signal srd: std_logic_vector(7 downto 0);
signal sData: std_logic_vector(7 downto 0);
begin
sData <= "00000000";
	
	AL00: osc00 port map(oscout0 => clk0,
						 cdiv => cdiv0);
	
	AL01: and00 port map(clka => clk0,
						 opcodea => outCode0,
						 inAa => inA0,
						 inBa => inB0,
						 inFlaga => en0,
						 outa => srd,
						 outFlaga => outFlagL0);
	
	
	AL02: or00 port map(clko => clk0,
						 opcodeo => outCode0,
						 inAo => inA0,
						 inBo => inB0,
						 inFlago => en0,
						 outo => srd,
						 outFlago => outFlagL0);
	
	
	AL03: xor00 port map(clkx => clk0,
						 opcodex => outCode0,
						 inAx => inA0,
						 inBx => inB0,
						 inFlagx => en0,
						 outx => srd,
						 outFlagx => outFlagL0);
	
	
	AL04: nand00 port map(clkna => clk0,
						 opcodena => outCode0,
						 inAna => inA0,
						 inBna => inB0,
						 inFlagna => en0,
						 outna => srd,
						 outFlagna => outFlagL0);
	
	
	AL05: nor00 port map(clkno => clk0,
						 opcodeno => outCode0,
						 inAno => inA0,
						 inBno => inB0,
						 inFlagno => en0,
						 outno => srd,
						 outFlagno => outFlagL0);
	
	AL06: xnor00 port map(clknx => clk0,
						 opcodenx => outCode0,
						 inAnx => inA0,
						 inBnx => inB0,
						 inFlagnx => en0,
						 outnx => srd,
						 outFlagnx => outFlagL0);
	
	
	AL07: notA00 port map(clknota => clk0,
						 opcodenota => outCode0,
						 inAnota => inA0,
						 inBnota => inB0,
						 inFlagnota => en0,
						 outnota => srd,
						 outFlagnota => outFlagL0);
	
	AL08: pc00 port map(clkpc => clk0,
						 repc => re0,
						 enpc => en0,
						 rwpc => rw0,
						 inFlagpc => outFlag0,
						 outpc => Address0);
	
	AL09: ram_EBR_00 port map(Clock => clk0,
							  ClockEn => en0,
							  Reset => re0,
							  WE => rw0,
							  Address => Address0,
							  Data => sData,
							  Q => outCode0);
							  
	AL10: acLogic00 port map(clkac => clk0,
							  inFlagac => outFlagL0,
							  enac => en0,
							  inDataac => srd,
							  outac => out0,
							  outFlagac => outFlag0);
end aluBL0;