library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity xnor00 is
	port(
		 clknx: in std_logic;
		 opcodenx: in std_logic_vector(7 downto 0);
		 inAnx, inBnx: std_logic_vector(7 downto 0);
		 inFlagnx: in std_logic;
		 outnx: out std_logic_vector(7 downto 0);
		 outFlagnx: out std_logic);
end xnor00;

architecture xnor0 of xnor00 is
begin
	pxnor: process(clknx)
	variable auxnx: bit:='0';
	begin
		if(clknx'event and clknx = '1') then
			if (opcodenx = "00000110") then
				if (inFlagnx = '1') then
					if (auxnx = '0') then
						auxnx:='1';
						outnx <= inAnx xnor inBnx;
						outFlagnx <= '1';
					else 
						outFlagnx <= '0';
					end if;
				elsif (inFlagnx = '0') then
					outFlagnx <= '0';
				end if;
			else
				outnx <= (others => 'Z');
				outFlagnx <= 'Z';
				auxnx:='0';
			end if;
		end if;
	end process pxnor;
end xnor0;