library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity and00 is
	port(
		 clka: in std_logic;
		 opcodea: in std_logic_vector(7 downto 0);
		 inAa, inBa: std_logic_vector(7 downto 0);
		 inFlaga: in std_logic; --- enable exterior
		 outa: out std_logic_vector(7 downto 0);
		 outFlaga: out std_logic);
end and00;

architecture and0 of and00 is
begin
	pand: process(clka)
	variable auxa: bit:='0';
	begin
		if(clka'event and clka = '1') then
			if (opcodea = "00000001") then
				if (inFlaga = '1') then
					if (auxa = '0') then
						auxa:='1';
						outa <= inAa and inBa;
						outFlaga <= '1';
					else 
						outFlaga <= '0';
					end if;
				elsif (inFlaga = '0') then
					outFlaga <= '0';
				end if;
			else
				outa <= (others => 'Z');
				outFlaga <= 'Z';
				auxa:='0';
			end if;
		end if;
	end process pand;
end and0;