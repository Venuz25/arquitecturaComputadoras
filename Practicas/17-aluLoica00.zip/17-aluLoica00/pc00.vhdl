library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
library lattice;
use lattice.all;

entity pc00 is
	port(
		 clkpc: in std_logic;
		 repc, enpc, rwpc: in std_logic;
		 inFlagpc: in std_logic;
		 outpc: inout std_logic_vector(3 downto 0));
end pc00;

architecture pc0 of pc00 is
signal scontrolpc: std_logic_vector(3 downto 0);
begin
scontrolpc <= (inFlagpc)&(repc)&(enpc)&(rwpc);
	ppc: process(clkpc)
	variable auxpc: bit:='0';
	begin
		if (clkpc'event and clkpc = '1') then
			case scontrolpc is
				when "0000" =>
					outpc <= "0000";
					auxpc:='0';
------------------------------------------------------------
				when "1010" =>
					if(outpc < "0111") then
						if(auxpc = '0') then
							outpc <= outpc;
							auxpc:='1';
						elsif (auxpc = '1') then
							outpc <= outpc + '1';
							auxpc:='1';
						end if;
					end if;
--------------------------------------------------------------
				when "1011" =>
					outpc <= outpc;
					auxpc:='0';
				when "0111" =>
					outpc <= "0000";
					auxpc:='0';
				when "1110" =>
					outpc <= "0000";
					auxpc:='0';
				when others => null;
			end case;
		end if;
	end process ppc;
end pc0;