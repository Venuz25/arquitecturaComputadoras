library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity nor00 is
	port(
		 clkno: in std_logic;
		 opcodeno: in std_logic_vector(7 downto 0);
		 inAno, inBno: std_logic_vector(7 downto 0);
		 inFlagno: in std_logic;
		 outno: out std_logic_vector(7 downto 0);
		 outFlagno: out std_logic);
end nor00;

architecture nor0 of nor00 is
begin
	pnor: process(clkno)
	variable auxno: bit:='0';
	begin
		if(clkno'event and clkno = '1') then
			if (opcodeno = "00000101") then
				if (inFlagno = '1') then
					if (auxno = '0') then
						auxno:='1';
						outno <= inAno nor inBno;
						outFlagno <= '1';
					else 
						outFlagno <= '0';
					end if;
				elsif (inFlagno = '0') then
					outFlagno <= '0';
				end if;
			else
				outno <= (others => 'Z');
				outFlagno <= 'Z';
				auxno:='0';
			end if;
		end if;
	end process pnor;
end nor0;