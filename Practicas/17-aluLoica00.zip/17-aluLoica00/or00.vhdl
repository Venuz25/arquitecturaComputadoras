library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity or00 is
	port(
		 clko: in std_logic;
		 opcodeo: in std_logic_vector(7 downto 0);
		 inAo, inBo: std_logic_vector(7 downto 0);
		 inFlago: in std_logic;
		 outo: out std_logic_vector(7 downto 0);
		 outFlago: out std_logic);
end or00;

architecture or0 of or00 is
begin
	por: process(clko)
	variable auxo: bit:='0';
	begin
		if(clko'event and clko = '1') then
			if (opcodeo = "00000010") then
				if (inFlago = '1') then
					if (auxo = '0') then
						auxo:='1';
						outo <= inAo or inBo;
						outFlago <= '1';
					else 
						outFlago <= '0';
					end if;
				elsif (inFlago = '0') then
					outFlago <= '0';
				end if;
			else
				outo <= (others => 'Z');
				outFlago <= 'Z';
				auxo:='0';
			end if;
		end if;
	end process por;
end or0;