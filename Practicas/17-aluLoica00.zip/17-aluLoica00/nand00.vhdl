library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity nand00 is
	port(
		 clkna: in std_logic;
		 opcodena: in std_logic_vector(7 downto 0);
		 inAna, inBna: std_logic_vector(7 downto 0);
		 inFlagna: in std_logic;
		 outna: out std_logic_vector(7 downto 0);
		 outFlagna: out std_logic);
end nand00;

architecture nand0 of nand00 is
begin
	pnand: process(clkna)
	variable auxna: bit:='0';
	begin
		if(clkna'event and clkna = '1') then
			if (opcodena = "00000100") then
				if (inFlagna = '1') then
					if (auxna = '0') then
						auxna:='1';
						outna <= inAna nand inBna;
						outFlagna <= '1';
					else 
						outFlagna <= '0';
					end if;
				elsif (inFlagna = '0') then
					outFlagna <= '0';
				end if;
			else
				outna <= (others => 'Z');
				outFlagna <= 'Z';
				auxna:='0';
			end if;
		end if;
	end process pnand;
end nand0;