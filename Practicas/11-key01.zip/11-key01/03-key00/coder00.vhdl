library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
library lattice;
use lattice.all;

entity coder00 is
    port(
        clkc: in std_logic;
        intcontc: in std_logic_vector(3 downto 0);
        inkeyc: in std_logic_vector(3 downto 0);
        outcoderc: out std_logic_vector(6 downto 0) -- va hacia los displays
    );
end coder00;

architecture coder0 of coder00 is
begin
    pcoder: process(clkc)
        variable aux0, aux1, aux2, aux3: bit := '0';
        variable sum: std_logic_vector(2 downto 0) := "000";
        variable flg: bit := '0';
        variable last_output: std_logic_vector(6 downto 0) := "0000000";
    begin
        if (clkc'event and clkc = '1') then
            case intcontc is
                -- Primer caso
                when "1000" =>
                    case inkeyc is
                        when "0000" =>
                            aux0 := '0';
                            sum := sum + '1';
                        when "0001" =>
                            if (aux0 = '0' and aux1 = '0' and aux2 = '0' and aux3 = '0' and flg = '1') then
                                aux0 := '1';
                                last_output := "1110111"; -- A
                            end if;
                        when "0010" =>
                            if (aux0 = '0' and aux1 = '0' and aux2 = '0' and aux3 = '0' and flg = '1') then
                                aux0 := '1';
                                last_output := "1111001"; -- 3
                            end if;
                        when "0100" =>
                            if (aux0 = '0' and aux1 = '0' and aux2 = '0' and aux3 = '0' and flg = '1') then
                                aux0 := '1';
                                last_output := "1101101"; -- 2
                            end if;
                        when "1000" =>
                            if (aux0 = '0' and aux1 = '0' and aux2 = '0' and aux3 = '0' and flg = '1') then
                                aux0 := '1';
                                last_output := "0110000"; -- 1
                            end if;
                        when others => null;
                    end case;

                -- Segundo caso
                when "0100" =>
                    case inkeyc is
                        when "0000" =>
                            aux1 := '0';
                            sum := sum + '1';
                        when "0001" =>
                            if (aux0 = '0' and aux1 = '0' and aux2 = '0' and aux3 = '0' and flg = '1') then
                                aux1 := '1';
                                last_output := "0011111"; -- B
                            end if;
                        when "0010" =>
                            if (aux0 = '0' and aux1 = '0' and aux2 = '0' and aux3 = '0' and flg = '1') then
                                aux1 := '1';
                                last_output := "1011111"; -- 6
                            end if;
                        when "0100" =>
                            if (aux0 = '0' and aux1 = '0' and aux2 = '0' and aux3 = '0' and flg = '1') then
                                aux1 := '1';
                                last_output := "1011011"; -- 5
                            end if;
                        when "1000" =>
                            if (aux0 = '0' and aux1 = '0' and aux2 = '0' and aux3 = '0' and flg = '1') then
                                aux1 := '1';
                                last_output := "0110011"; -- 4
                            end if;
                        when others => null;
                    end case;

                -- Tercer caso
                when "0010" =>
                    case inkeyc is
                        when "0000" =>
                            aux2 := '0';
                            sum := sum + '1';
                        when "0001" =>
                            if (aux0 = '0' and aux1 = '0' and aux2 = '0' and aux3 = '0' and flg = '1') then
                                aux2 := '1';
                                last_output := "1001110"; -- C
                            end if;
                        when "0010" =>
                            if (aux0 = '0' and aux1 = '0' and aux2 = '0' and aux3 = '0' and flg = '1') then
                                aux2 := '1';
                                last_output := "1111011"; -- 9
                            end if;
                        when "0100" =>
                            if (aux0 = '0' and aux1 = '0' and aux2 = '0' and aux3 = '0' and flg = '1') then
                                aux2 := '1';
                                last_output := "1111111"; -- 8
                            end if;
                        when "1000" =>
                            if (aux0 = '0' and aux1 = '0' and aux2 = '0' and aux3 = '0' and flg = '1') then
                                aux2 := '1';
                                last_output := "1110000"; -- 7
                            end if;
                        when others => null;
                    end case;

                -- Cuarto caso
                when "0001" =>
                    case inkeyc is
                        when "0000" =>
                            aux3 := '0';
                            sum := sum + '1';
                        when "0001" =>
                            if (aux0 = '0' and aux1 = '0' and aux2 = '0' and aux3 = '0' and flg = '1') then
                                aux3 := '1';
                                last_output := "0111101"; -- -
                            end if;
                        when "0010" =>
                            if (aux0 = '0' and aux1 = '0' and aux2 = '0' and aux3 = '0' and flg = '1') then
                                aux3 := '1';
                                last_output := "0011101"; -- +
                            end if;
                        when "0100" =>
                            if (aux0 = '0' and aux1 = '0' and aux2 = '0' and aux3 = '0' and flg = '1') then
                                aux3 := '1';
                                last_output := "1111110"; -- 0
                            end if;
                        when "1000" =>
                            if (aux0 = '0' and aux1 = '0' and aux2 = '0' and aux3 = '0' and flg = '1') then
                                aux3 := '1';
                                last_output := "1100011"; -- *
                            end if;
                        when others => null;
                    end case;

                -- Ning�n bot�n
                if (sum = "100") then
                    flg := '1';
                elsif (sum = "011" or sum = "010") then
                    flg := '0';
                end if;
                sum := "000";

                when others => null;
            end case;

            -- Mostrar el �ltimo valor guardado
            outcoderc <= last_output;
        end if;
    end process pcoder;
end coder0;
