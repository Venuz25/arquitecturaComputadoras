library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;use packageshiftMux00.all;

entity shiftMux00 is
	port(
		clk0: inout std_logic;
		cdiv0: in std_logic_vector(5 downto 0);
		en0: in std_logic;
		sl0: in std_logic_vector(7 downto 0);
		incsrl0: in std_logic_vector(3 downto 0);
		in0: in std_logic_vector(7 downto 0);
		out0: out std_logic_vector(7 downto 0));
end shiftMux00;

architecture shiftMux0 of shiftMux00 is
begin

	S00: osc00 port map(oscout0 => clk0,
						cdiv => cdiv0);
	
	S01: shiftMux port map(clksrl => clk0,
						   ensrl => en0,
						   sl => sl0,
						   incsrl => incsrl0,
						   insrl => in0,
						   outsrl => out0);
						   
end shiftMux0;