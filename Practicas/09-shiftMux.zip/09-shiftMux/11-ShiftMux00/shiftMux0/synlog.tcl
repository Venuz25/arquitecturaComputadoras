run_tcl -fg shiftMux00_shiftMux0_synplify.tcl
