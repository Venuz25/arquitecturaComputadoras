library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
library lattice;
use lattice.all;

entity shiftMux is
	port(
		 clksrl: in std_logic;
		 ensrl: in std_logic;
		 sl: in std_logic_vector(7 downto 0);
		 incsrl: in std_logic_vector(3 downto 0);
		 insrl: in std_logic_vector(7 downto 0);
		 outsrl: out std_logic_vector(7 downto 0));
end shiftMux;

architecture shift of shiftMux is
signal sshift: std_logic_vector(7 downto 0);
signal scontrol: std_logic_vector(3 downto 0);
begin
pshift: process(clksrl)
	begin
		if (clksrl'event and clksrl = '1') then
			case ensrl is
				when '0' =>
					sshift <= insrl;
					scontrol <= "0000";
				when '1' =>
					case sl is
						when "00000001" => -------------------- Shift R-L
							sshift(0) <= '0';
							sshift(7 downto 1) <= sshift(6 downto 0);
						when "00000010" => -------------------- Shift L-R
							sshift(7) <= '0';
							sshift(6 downto 0) <= sshift(7 downto 1);
						when "00000100" => -------------------- Rotacion R-L
							sshift(0) <= sshift(7);
							sshift(7 downto 1) <= sshift(6 downto 0);
						when "00001000" => -------------------- Rotacion L-R
							sshift(7) <= sshift(0);
							sshift(6 downto 0) <= sshift(7 downto 1);
						when "00010000" => -------------------- Controlado R-L
							if (scontrol < incsrl) then
								scontrol <= scontrol + '1';
								sshift(0) <= '0';
								sshift(7 downto 1) <= sshift(6 downto 0);
							end if;
						when "00100000" => -------------------- Controlado L-R
							if (scontrol < incsrl) then
								scontrol <= scontrol + '1';
								sshift(7) <= '0';
								sshift(6 downto 0) <= sshift(7 downto 1);
							end if;
						when "01000000" => -------------------- Controlado Rotacion R-L
							if (scontrol < incsrl) then
								scontrol <= scontrol + '1';
								sshift(0) <= sshift(7);
								sshift(7 downto 1) <= sshift(6 downto 0);
							end if;
						when "10000000" => -------------------- Controlado Rotacion L-R
							if (scontrol < incsrl) then
								scontrol <= scontrol + '1';
								sshift(7) <= sshift(0);
								sshift(6 downto 0) <= sshift(7 downto 1);
							end if;
						when others => null;
					end case;
					outsrl <= sshift;
				when others => null;
			end case;
		end if;
	end process pshift;
end shift;