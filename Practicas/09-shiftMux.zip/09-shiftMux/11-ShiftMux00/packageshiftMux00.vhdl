library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

package packageshiftMux00 is

	component osc00
		port(
		 cdiv: in std_logic_vector(5 downto 0);
		 oscout0: inout std_logic);
	end component;
	
	component shiftMux
		port(
		 clksrl: in std_logic;
		 ensrl: in std_logic;
		 sl: in std_logic_vector(7 downto 0);
		 incsrl: in std_logic_vector(3 downto 0);
		 insrl: in std_logic_vector(7 downto 0);
		 outsrl: out std_logic_vector(7 downto 0));
	end component;
	
end packageshiftMux00;