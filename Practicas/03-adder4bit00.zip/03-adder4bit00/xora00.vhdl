library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;

entity xora00 is
	port(
		Ax: in std_logic;
		Bx: in std_logic;
		Yx: out std_logic
	);
end xora00;

architecture xora0 of xora00 is
begin
	Yx <= Ax xor Bx;
end xora0;