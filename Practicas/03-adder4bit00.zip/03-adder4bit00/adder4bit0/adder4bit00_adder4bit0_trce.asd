[ActiveSupport TRCE]
; Setup Analysis
Other_0 = 14.823 ns (0.000 ns);
Other_1 = 3.728 ns (0.000 ns);
Failed = 0 (Total 2);
Clock_ports = 0;
Clock_nets = 0;
