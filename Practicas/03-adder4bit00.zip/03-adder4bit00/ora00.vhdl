library ieee;
use ieee.std_logic_1164.all;
library lattice;
use lattice.all;


entity ora00 is 
	port(
		Ao: in std_logic;
		Bo: in std_logic;
		Yo: out std_logic);
end ora00;

architecture ora0 of ora00 is 
begin
	Yo <= Ao or Bo;

end ora0;